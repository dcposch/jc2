# TD6 AWS handoff — 2026-08-24

Requirements: Python 3.14 (or compatible Python 3), `python-flint`, enough RAM
to avoid swapping, and the extracted directory layout rooted at `jc2/`.
All runs are deterministic exact arithmetic; no network access is used after
dependencies are installed.

Run from the directory containing `jc2`.

## Priority 1: portable eps^2 freeze replay

```sh
python3 jc2/cases/td6_c1_c3_first_ideal_eps2_20260824/replay.py \
  > jc2/cases/td6_c1_c3_first_ideal_eps2_20260824/replay.stdout \
  2> jc2/cases/td6_c1_c3_first_ideal_eps2_20260824/replay.stderr
```

Expected terminal marker:

```text
second-order reduction/source replay PASS
```

The final JSON must report transport rank 3470/3602, first rank 38/132,
base `-k/50`, zero eps and eps^2 remainders, 28 original rows/1489 slots,
nonzero raw eps^2, nonzero varying-pivot counts, and a nonzero frozen-first-
echelon eps^2 negative control.

## Priority 2: generic ascending and B-local two-center identities

These two commands may run on separate instances.

```sh
python3 jc2/cases/td6_c1_c3_two_center_cover_20260824/replay.py \
  > jc2/cases/td6_c1_c3_two_center_cover_20260824/generic.stdout \
  2> jc2/cases/td6_c1_c3_two_center_cover_20260824/generic.stderr

python3 jc2/cases/td6_c1_c3_two_center_cover_20260824/replay.py \
  --b-local-pivots \
  > jc2/cases/td6_c1_c3_two_center_cover_20260824/b-local.stdout \
  2> jc2/cases/td6_c1_c3_two_center_cover_20260824/b-local.stderr
```

Both must end in `TD6-C1-C3-MPOLY-P12-GENERIC PASS` and reduce the genuine
2,893-term P12 to `-k/50` with full original-row source replay.  The B-local
run additionally executes the denominator-resultant assertions and must emit
`B_local_denominator_unit_off_UH=true`.  Charged exact values are:

```text
B = 4*C^2*U^2 + 24*C*U^4 - 4*C*U + 20*U^6 - 20*U^3 + 1
H = C - 3*U^2
T = 4*C^2*U^2 + 28*C*U^4 - 4*C*U + 24*U^6 - 24*U^3 + 1
ascending multiplier denominator = (1/4)*B*U^2*H^2
ascending termwise clear         = (1/4)*B*U^3*H^3
B-local multiplier denominator   = (1/4)*U^2*T
B-local termwise clear           = (1/4)*U^3*H*T
Res_C(B,T) = 64*U^10
B(C,0) = 1
```

## Priority 3: raw exceptional strata

These three commands are independent and may run on separate instances.

```sh
python3 jc2/cases/td6_c1_c3_two_center_cover_20260824/replay.py \
  --stratum=u-zero \
  > jc2/cases/td6_c1_c3_two_center_cover_20260824/u-zero.stdout \
  2> jc2/cases/td6_c1_c3_two_center_cover_20260824/u-zero.stderr

python3 jc2/cases/td6_c1_c3_two_center_cover_20260824/replay.py \
  --stratum=h-zero \
  > jc2/cases/td6_c1_c3_two_center_cover_20260824/h-zero.stdout \
  2> jc2/cases/td6_c1_c3_two_center_cover_20260824/h-zero.stderr

python3 jc2/cases/td6_c1_c3_two_center_cover_20260824/replay.py \
  --stratum=intersection \
  > jc2/cases/td6_c1_c3_two_center_cover_20260824/intersection.stdout \
  2> jc2/cases/td6_c1_c3_two_center_cover_20260824/intersection.stderr
```

Each run must rebuild transport and the original first-band ideal after
specialization.  If that affine first band is consistent, it must continue
through the genuine P12 and the original-row source relation.  If it is
inconsistent (as the first intersection attempt indicated), the replay must
instead end with `TD6-C1-C3-FIRST-BAND-INCONSISTENT-STRATUM PASS` and emit an
exact nonzero left-null residual lifted back to the original first rows; P12
is then correctly skipped because the stratum is already empty.  Do not infer
a two-center kill unless all recursive pivot factors exposed by `u-zero` and
`h-zero` are either covered by the other chart or rebuilt exactly, including
their intersection.

For an inconsistent first band, the V6 replay prints every exact source-row
coefficient, rechecks the original-row identity, clears all coordinates of
the residual, and reports their common numerator gcd.  Its conservative
certificate chart includes every nonconstant transport pivot event, every
first-row source denominator, and every certificate/residual denominator.
`whole_stratum_empty=true` is emitted only when both the cleared residual gcd
and that complete chart denominator are units.  Otherwise the PASS marker
kills only the printed localization and every factor of the chart denominator
remains a mandatory raw rebuild.

## Priority 4: exact `H=B=0` quotient witness

Run only on the AWS host, after preserving the ordinary `h-zero` output:

```sh
python3 jc2/cases/td6_c1_c3_two_center_cover_20260824/replay.py \
  --stratum=h-zero --sparse-pivots \
  > jc2/cases/td6_c1_c3_two_center_cover_20260824/h-b-quotient.stdout \
  2> jc2/cases/td6_c1_c3_two_center_cover_20260824/h-b-quotient.stderr
```

This is a fresh raw rebuild on `H=0`, not a specialization of the generic
`1/H` identity.  It must replay the genuine P12 through all original source
rows.  It then audits every transport/raw/first/relation/termwise denominator
against

```text
P(U)=B(3U^2,U)=128U^6-32U^3+1.
```

Only if each gcd with `P` is a unit does it emit an exact termwise-denominator
Bezout identity, reduce every source multiplier in `Q[U]/(P)`, replay the
specialized original-row identity, execute the omit-all-relations negative
control, and end in both `TD6-C1-C3-H-B-QUOTIENT PASS` and the ordinary P12
PASS marker.  A nonunit gcd is a failed cover and requires another raw chart;
it must not be read as a family kill.

## Quarantine

No command licenses a neighbourhood theorem, SP-2 kill, or JC2 conclusion.
The eps^2 and two-center packages retain separate custody.

## Priority 5: raw finite quotient after a failed localized cover

V6 established that both tested `H=0` source relations have a genuine `P`
denominator, so the localized identities do not cover `H=B=0`.  V7 therefore
contains a separate raw quotient producer.  Run it only on AWS:

```sh
python3 jc2/cases/td6_c1_c3_two_center_cover_20260824/h_b_raw_quotient.py \
  > jc2/cases/td6_c1_c3_two_center_cover_20260824/h-b-raw-quotient.stdout \
  2> jc2/cases/td6_c1_c3_two_center_cover_20260824/h-b-raw-quotient.stderr
```

The producer first certifies that
`P=128U^6-32U^3+1` is irreducible and squarefree over `Q`, constructs exact
`K=Q[U]/(P)`, and then rebuilds the entire transport at center
`(3u^2,1,u)`.  It does not specialize any generic echelon or relation.  Every
nonzero quotient pivot is inverted with an exact Bezout check.  It then
rebuilds the first affine band.  An inconsistent first band is accepted only
with an exact original-row witness whose residual has an explicitly checked
inverse.  Otherwise it computes genuine P12, reports the full quotient
remainder without assuming rank 38, lifts it to the original rows, and runs a
negative control.  `H_B_stratum_empty=true` is emitted only for a unit first-
band residual or a constant-unit P12 remainder.  A nonconstant remainder is
an open successor, not a kill.
