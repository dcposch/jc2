# TD6 AWS handoff — 2026-08-24

Requirements: Python 3.14 (or compatible Python 3), `python-flint`, enough RAM
to avoid swapping, and the extracted directory layout rooted at `jc2/`.
All runs are deterministic exact arithmetic; no network access is used after
dependencies are installed.

Run from the directory containing `jc2`.

## Priority 1: portable eps^2 freeze replay

```sh
python3 jc2/cases/td6_c1_c3_first_ideal_eps2_20260824/replay.py \
  > jc2/cases/td6_c1_c3_first_ideal_eps2_20260824/replay.stdout \
  2> jc2/cases/td6_c1_c3_first_ideal_eps2_20260824/replay.stderr
```

Expected terminal marker:

```text
second-order reduction/source replay PASS
```

The final JSON must report transport rank 3470/3602, first rank 38/132,
base `-k/50`, zero eps and eps^2 remainders, 28 original rows/1489 slots,
nonzero raw eps^2, nonzero varying-pivot counts, and a nonzero frozen-first-
echelon eps^2 negative control.

## Priority 2: generic ascending and B-local two-center identities

These two commands may run on separate instances.

```sh
python3 jc2/cases/td6_c1_c3_two_center_cover_20260824/replay.py \
  > jc2/cases/td6_c1_c3_two_center_cover_20260824/generic.stdout \
  2> jc2/cases/td6_c1_c3_two_center_cover_20260824/generic.stderr

python3 jc2/cases/td6_c1_c3_two_center_cover_20260824/replay.py \
  --b-local-pivots \
  > jc2/cases/td6_c1_c3_two_center_cover_20260824/b-local.stdout \
  2> jc2/cases/td6_c1_c3_two_center_cover_20260824/b-local.stderr
```

Both must end in `TD6-C1-C3-MPOLY-P12-GENERIC PASS` and reduce the genuine
2,893-term P12 to `-k/50` with full original-row source replay.  The B-local
run additionally executes the denominator-resultant assertions and must emit
`B_local_denominator_unit_off_UH=true`.  Charged exact values are:

```text
B = 4*C^2*U^2 + 24*C*U^4 - 4*C*U + 20*U^6 - 20*U^3 + 1
H = C - 3*U^2
T = 4*C^2*U^2 + 28*C*U^4 - 4*C*U + 24*U^6 - 24*U^3 + 1
ascending multiplier denominator = (1/4)*B*U^2*H^2
ascending termwise clear         = (1/4)*B*U^3*H^3
B-local multiplier denominator   = (1/4)*U^2*T
B-local termwise clear           = (1/4)*U^3*H*T
Res_C(B,T) = 64*U^10
B(C,0) = 1
```

## Priority 3: raw exceptional strata

These three commands are independent and may run on separate instances.

```sh
python3 jc2/cases/td6_c1_c3_two_center_cover_20260824/replay.py \
  --stratum=u-zero \
  > jc2/cases/td6_c1_c3_two_center_cover_20260824/u-zero.stdout \
  2> jc2/cases/td6_c1_c3_two_center_cover_20260824/u-zero.stderr

python3 jc2/cases/td6_c1_c3_two_center_cover_20260824/replay.py \
  --stratum=h-zero \
  > jc2/cases/td6_c1_c3_two_center_cover_20260824/h-zero.stdout \
  2> jc2/cases/td6_c1_c3_two_center_cover_20260824/h-zero.stderr

python3 jc2/cases/td6_c1_c3_two_center_cover_20260824/replay.py \
  --stratum=intersection \
  > jc2/cases/td6_c1_c3_two_center_cover_20260824/intersection.stdout \
  2> jc2/cases/td6_c1_c3_two_center_cover_20260824/intersection.stderr
```

Each run must rebuild transport, the original first-band ideal, the genuine
P12, and the original-row source relation after specialization.  Do not infer
a two-center kill unless all recursive pivot factors exposed by `u-zero` and
`h-zero` are either covered by the other chart or rebuilt exactly, including
their intersection.

## Quarantine

No command licenses a neighbourhood theorem, SP-2 kill, or JC2 conclusion.
The eps^2 and two-center packages retain separate custody.
