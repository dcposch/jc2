# V68 exact route ledger for the B3 chart boundary factors

Run `python3 route_replay.py` on AWS after checking `SOURCE.sha256`.

The replay proves exact normalized/raw-center routing for the V66 factors
`t=0`, `w=0`, and `t=2`, then hash-pins and marker-checks the frozen direct
source certificates on `U0=0`, `V0=C0+U0^2=0`, and
`V0=C0+5U0^2=0`.  It includes wrong-coefficient, missing-branch, and
source-marker omission controls.

This route lemma plus those source theorems covers the three chart-boundary
factors only.  It does not cover the finite factors `2t-1` or
`t^2-4t+2`, does not by itself promote a whole-B3 theorem, and makes no
whole-A3, TD6, SP-2, landing, or JC2 claim.
