#!/usr/bin/env python3
"""Exact route ledger for the B3 chart factors t=0, w=0, and t=2.

This is deliberately small: it proves the algebraic routing and hash-pins
the already frozen direct-source U=0 and V=0 line certificates.  It does not
replace either source theorem or infer a whole-B3 statement by itself.
"""

from fractions import Fraction
from hashlib import sha256
from pathlib import Path


HERE = Path(__file__).resolve().parent
EXPECTED = {
    "evidence/u_zero/MANIFEST.sha256":
        "0ae3c4602e09279c9213f48ce0d0bb4c98e243129b46b47e96e428aaad8291b0",
    "evidence/u_zero/FREEZE.sha256":
        "1c860097b265b7a7baffb8b5121859c3a9b3e14c88871029ff5ad2a6fb12cc69",
    "evidence/u_zero/report.md":
        "4e19a56bbaeb56e46c25ff3342c3b3a927be46a0d31a2641899a889cedbae635",
    "evidence/u_zero/n13-u-zero.stdout":
        "94e2267d62b162f44abaf32d36405440dd213e1efb4f446cc281ace08b47d0da",
    "evidence/rational_lines/MANIFEST.sha256":
        "be876b0a58b73394ed1d98e254045eae4c8035607c636b8707db541909cb5513",
    "evidence/rational_lines/FREEZE.sha256":
        "f93d1f4636275c1962ebc08c5b79ab94931a3f3cf9a2ce9169d6591af6cc2c76",
    "evidence/rational_lines/report.md":
        "0101a2f249e914af6e413bb2a9d8d7dd9ac46ffc1282fc31c67e7fe271b84b58",
    "evidence/rational_lines/v46.stdout":
        "01fa0f2ef212f1280f7b1cc4530da867df331b0892053c44f3edf89e1bbf6706",
    "evidence/rational_lines/v45-v-cplus5-zero.stdout":
        "0be0c4093c27d21778853908afc90a3021831cb75a926a60981cffa4e166e8e2",
}


def clean(poly):
    return {monomial: Fraction(value) for monomial, value in poly.items() if value}


def add(left, right, scale=1):
    result = dict(left)
    for monomial, value in right.items():
        result[monomial] = result.get(monomial, Fraction()) + scale*value
    return clean(result)


def mul(left, right):
    result = {}
    for lm, lv in left.items():
        for rm, rv in right.items():
            monomial = tuple(a+b for a, b in zip(lm, rm))
            result[monomial] = result.get(monomial, Fraction()) + lv*rv
    return clean(result)


def scale(poly, value):
    return clean({monomial: value*coefficient for monomial, coefficient in poly.items()})


def power(poly, exponent, dimension):
    result = {(0,)*dimension: Fraction(1)}
    for _ in range(exponent):
        result = mul(result, poly)
    return result


def substitute_second(poly, value):
    result = {}
    for (x_degree, t_degree), coefficient in poly.items():
        key = (x_degree,)
        result[key] = result.get(key, Fraction()) + coefficient*value**t_degree
    return clean(result)


for relative, expected in EXPECTED.items():
    got = sha256((HERE / relative).read_bytes()).hexdigest()
    assert got == expected, (relative, got, expected)

# Normalized conic b(x,y)=0 and the complete line pencil y=t(x+5).
one2 = {(0, 0): Fraction(1)}
x = {(1, 0): Fraction(1)}
t = {(0, 1): Fraction(1)}
x5 = add(x, scale(one2, 5))
y = mul(t, x5)
b = add(scale(power(x, 2, 2), 4), scale(mul(x, y), -4))
b = add(b, scale(x, 24))
b = add(b, power(y, 2, 2))
b = add(b, scale(y, -20))
b = add(b, scale(one2, 20))
tminus2 = add(t, scale(one2, -2))
second = add(mul(power(tminus2, 2, 2), x), scale(power(t, 2, 2), 5))
second = add(second, scale(t, -20))
second = add(second, scale(one2, 4))
assert b == mul(x5, second)
assert substitute_second(b, 0) == {(0,): Fraction(20), (1,): Fraction(24), (2,): Fraction(4)}
assert substitute_second(b, 2) == {(0,): Fraction(-80), (1,): Fraction(-16)}

# Raw-center factorization on V0=0.
one3 = {(0, 0, 0): Fraction(1)}
C0 = {(1, 0, 0): Fraction(1)}
V0 = {(0, 1, 0): Fraction(1)}
U0 = {(0, 0, 1): Fraction(1)}
raw_v_zero = add(scale(mul(power(C0, 2, 3), power(U0, 2, 3)), 4),
                   scale(mul(C0, power(U0, 4, 3)), 24))
raw_v_zero = add(raw_v_zero, scale(power(U0, 6, 3), 20))
cplus1 = add(C0, power(U0, 2, 3))
cplus5 = add(C0, scale(power(U0, 2, 3), 5))
raw_factor = scale(mul(power(U0, 2, 3), mul(cplus1, cplus5)), 4)
assert raw_v_zero == raw_factor

# Omission/wrong-coefficient controls for the route algebra.
wrong_raw = add(add(scale(mul(power(C0, 2, 3), power(U0, 2, 3)), 4),
                    scale(mul(C0, power(U0, 4, 3)), 24)),
                scale(power(U0, 6, 3), 19))
assert wrong_raw != raw_factor
assert raw_v_zero != scale(mul(power(U0, 2, 3), cplus1), 4)
assert raw_v_zero != scale(mul(power(U0, 2, 3), cplus5), 4)
assert substitute_second(b, 2) != {(0,): Fraction(-64), (1,): Fraction(-16)}


def require(text, markers):
    return all(marker in text for marker in markers)


u_zero = (HERE / "evidence/u_zero/n13-u-zero.stdout").read_text()
cplus1_out = (HERE / "evidence/rational_lines/v46.stdout").read_text()
cplus5_out = (HERE / "evidence/rational_lines/v45-v-cplus5-zero.stdout").read_text()
u_markers = (
    "source_center=U=0 over Q(C,V)",
    "first_compatibility_gcd_degree=0",
    "first_compatibility_certificate_denominator=(1)",
    "first_compatibility_original_row_replay=true",
    "TD6-A3-Q2-N13-RAW-FIRST PASS",
)
cplus1_markers = (
    "source_center=V=C+U^2=0 over Q(U)",
    "direct_qprime_omission_negative_control=true",
    "first_full_beta_P12_compatibility_gcd_degree=0",
    "first_full_beta_P12_compatibility_original_row_replay=true",
    "TD6-A3-Q2-CPLUS1-FIRST-UNIT-INCOMPATIBILITY-CANONICAL PASS",
)
cplus5_markers = (
    "source_center=V=C+5U^2=0 over Q(U)",
    "direct_qprime_omission_negative_control=true",
    "P12_N13_polynomial_unit_identity_exact=true",
    "P12_without_N13_negative_control=true",
    "combined_unit_residual_is_minus_k_over_50=true",
    "TD6-A3-Q2-FULL-P12-N13-UNIT-RATIONAL-RAW-CANONICAL PASS",
)
assert require(u_zero, u_markers)
assert require(cplus1_out, cplus1_markers)
assert require(cplus5_out, cplus5_markers)
assert not require(u_zero.replace("first_compatibility_original_row_replay=true", ""), u_markers)
assert not require(cplus1_out.replace("direct_qprime_omission_negative_control=true", ""), cplus1_markers)
assert not require(cplus5_out.replace("P12_without_N13_negative_control=true", ""), cplus5_markers)

print("normalized_line_pencil_factorization_exact=true")
print("t_zero_route=x_minus1_or_x_minus5=true")
print("t_two_route=x_minus5_only=true")
print("w_zero_on_DU_routes_to_V_zero=true")
print("B3_at_V_zero=4*U^2*(C+U^2)*(C+5U^2)")
print("U_zero_direct_source_dependency_verified=true")
print("Cplus1_direct_source_dependency_verified=true")
print("Cplus5_direct_source_dependency_verified=true")
print("route_wrong_coefficient_negative_control=true")
print("route_missing_branch_negative_controls=true")
print("source_marker_omission_controls=true")
print("route_target_union=U0_zero_union_(V0_zero_C0_plus_U0sq_zero)_union_(V0_zero_C0_plus5U0sq_zero)")
print("whole_B3_killed=false")
print("TD6-A3-Q2-B3-BOUNDARY-ROUTES-V68 PASS")
