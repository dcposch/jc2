#!/usr/bin/env python3
"""Exact block-pair quadratic TD6 previous/pole Kuranishi shard (V84).

The source axes are the reviewed Stage-A kernel

  q2..q14, q16..q24, d10, d15.

One run retains every symmetric degree-two monomial belonging to one unordered
pair of four-axis blocks.  The 21 block pairs partition all 300 elements of
Sym^2(Q_prev).  Transport is lifted coefficientwise from the original 3,470
pivot rows, including first and second matrix variation for the dead-stretch
axes.  FIRST and previous/pole are then solved in the same truncated
quadratic jet ring with exact source-combination replay.

This is a fixed-presentation generic-open Kuranishi discriminator only.
"""

from fractions import Fraction as Q
from hashlib import sha256
import importlib.util
from math import comb
import os
from pathlib import Path
import platform
import socket
import sys


HERE = Path(__file__).resolve().parent
P3_PATH = (
    HERE.parent / "td6_c1_c2_c3_kernel_dead_staged_shard_v82p_20260826"
    / "replay.py"
)
P3_SHA256 = "fbe3879a714ab8b776279573c79bd4f52a8939e0c0d58fa09977fe0132e2b9e7"
assert sha256(P3_PATH.read_bytes()).hexdigest() == P3_SHA256
spec = importlib.util.spec_from_file_location("td6_v84_v82p3_parent", P3_PATH)
p3 = importlib.util.module_from_spec(spec)
assert spec.loader is not None
sys.modules[spec.name] = p3
spec.loader.exec_module(p3)

v82, v81, allq = p3.v82, p3.v81, p3.allq
r, qd, nr = p3.r, p3.qd, p3.nr
Rat3, E3, OldAxisJet = v81.Rat3, v82.E3, v82.AxisJet
C, V, U, H, B3 = v81.C, v81.V, v81.U, v81.H, v81.B3

Q_AXES = tuple(f"q{level}" for level in v81.Q_LEVELS)
AXES = Q_AXES + ("d10", "d15")
assert len(AXES) == 24 and "q15" not in AXES
BLOCKS = tuple(tuple(AXES[4 * index:4 * index + 4]) for index in range(6))
BLOCK_A = int(os.environ["TD6_K2_BLOCK_A"])
BLOCK_B = int(os.environ["TD6_K2_BLOCK_B"])
assert 0 <= BLOCK_A <= BLOCK_B < 6
ACTIVE_AXES = tuple(dict.fromkeys(BLOCKS[BLOCK_A] + BLOCKS[BLOCK_B]))
if BLOCK_A == BLOCK_B:
    TARGET_PAIRS = tuple(
        (left, right)
        for i, left in enumerate(BLOCKS[BLOCK_A])
        for right in BLOCKS[BLOCK_A][i:]
    )
else:
    TARGET_PAIRS = tuple(
        (left, right) for left in BLOCKS[BLOCK_A] for right in BLOCKS[BLOCK_B]
    )
TARGET_PAIRS = tuple((AXES[min(AXES.index(a), AXES.index(b))],
                      AXES[max(AXES.index(a), AXES.index(b))])
                     for a, b in TARGET_PAIRS)
TARGET_PAIR_SET = frozenset(TARGET_PAIRS)
assert len(TARGET_PAIRS) == (10 if BLOCK_A == BLOCK_B else 16)


def pair_key(left, right):
    i, j = AXES.index(left), AXES.index(right)
    return (left, right) if i <= j else (right, left)


class QuadJet:
    """E(C,V,U)[eps]/(degree >=3 and unregistered quadratic slots)."""

    __slots__ = ("value", "linear", "quadratic")

    def __init__(self, value=0, linear=None, quadratic=None):
        if isinstance(value, QuadJet):
            self.value = value.value
            self.linear = dict(value.linear)
            self.quadratic = dict(value.quadratic)
        else:
            self.value = E3.coerce(value)
            self.linear = {}
            self.quadratic = {}
        if linear:
            for axis, coefficient in linear.items():
                assert axis in ACTIVE_AXES
                coefficient = E3.coerce(coefficient)
                total = self.linear.get(axis, E3()) + coefficient
                if total:
                    self.linear[axis] = total
                else:
                    self.linear.pop(axis, None)
        if quadratic:
            for pair, coefficient in quadratic.items():
                pair = pair_key(*pair)
                assert pair in TARGET_PAIR_SET
                coefficient = E3.coerce(coefficient)
                total = self.quadratic.get(pair, E3()) + coefficient
                if total:
                    self.quadratic[pair] = total
                else:
                    self.quadratic.pop(pair, None)

    @staticmethod
    def coerce(value):
        return value if isinstance(value, QuadJet) else QuadJet(value)

    @staticmethod
    def direction(axis, coefficient=1):
        assert axis in ACTIVE_AXES
        return QuadJet(0, {axis: coefficient})

    @staticmethod
    def second(pair, coefficient=1):
        return QuadJet(0, quadratic={pair: coefficient})

    def __add__(self, other):
        other = QuadJet.coerce(other)
        linear = dict(self.linear)
        quadratic = dict(self.quadratic)
        for axis, coefficient in other.linear.items():
            value = linear.get(axis, E3()) + coefficient
            if value:
                linear[axis] = value
            else:
                linear.pop(axis, None)
        for pair, coefficient in other.quadratic.items():
            value = quadratic.get(pair, E3()) + coefficient
            if value:
                quadratic[pair] = value
            else:
                quadratic.pop(pair, None)
        return QuadJet(self.value + other.value, linear, quadratic)

    __radd__ = __add__

    def __neg__(self):
        return QuadJet(
            -self.value,
            {axis: -coefficient for axis, coefficient in self.linear.items()},
            {pair: -coefficient for pair, coefficient in self.quadratic.items()},
        )

    def __sub__(self, other):
        return self + (-QuadJet.coerce(other))

    def __rsub__(self, other):
        return QuadJet.coerce(other) - self

    def __mul__(self, other):
        other = QuadJet.coerce(other)
        linear = {}
        quadratic = {}
        for axis in self.linear.keys() | other.linear.keys():
            value = (
                self.linear.get(axis, E3()) * other.value
                + self.value * other.linear.get(axis, E3())
            )
            if value:
                linear[axis] = value
        for left, right in TARGET_PAIRS:
            value = (
                self.quadratic.get((left, right), E3()) * other.value
                + self.value * other.quadratic.get((left, right), E3())
            )
            if left == right:
                value += self.linear.get(left, E3()) * other.linear.get(left, E3())
            else:
                value += (
                    self.linear.get(left, E3()) * other.linear.get(right, E3())
                    + self.linear.get(right, E3()) * other.linear.get(left, E3())
                )
            if value:
                quadratic[(left, right)] = value
        return QuadJet(self.value * other.value, linear, quadratic)

    __rmul__ = __mul__

    def inverse(self):
        if not self.value:
            raise ZeroDivisionError("zero-base quadratic pivot")
        inverse = self.value.inverse()
        linear = {
            axis: -(inverse * inverse) * coefficient
            for axis, coefficient in self.linear.items()
        }
        quadratic = {}
        for left, right in TARGET_PAIRS:
            value = -(inverse * inverse) * self.quadratic.get((left, right), E3())
            if left == right:
                value += inverse**3 * self.linear.get(left, E3())**2
            else:
                value += (
                    E3(2) * inverse**3
                    * self.linear.get(left, E3())
                    * self.linear.get(right, E3())
                )
            if value:
                quadratic[(left, right)] = value
        result = QuadJet(inverse, linear, quadratic)
        assert self * result == QuadJet(1)
        return result

    def __truediv__(self, other):
        return self * QuadJet.coerce(other).inverse()

    def __rtruediv__(self, other):
        return QuadJet.coerce(other) / self

    def __pow__(self, exponent):
        if exponent < 0:
            return self.inverse() ** (-exponent)
        out, base = QuadJet(1), self
        while exponent:
            if exponent & 1:
                out *= base
            base *= base
            exponent //= 2
        return out

    def __bool__(self):
        return bool(self.value) or bool(self.linear) or bool(self.quadratic)

    def __eq__(self, other):
        other = QuadJet.coerce(other)
        return (
            self.value == other.value
            and self.linear == other.linear
            and self.quadratic == other.quadratic
        )


ZERO_FORM = (E3(), {})


def scalar(value):
    return E3(v81.tri.FIELD.scalar(Rat3.coerce(value)))


def add_form(left, right, scale=1):
    scale = E3.coerce(scale)
    constant = left[0] + scale * right[0]
    row = dict(left[1])
    for variable, coefficient in right[1].items():
        value = row.get(variable, E3()) + scale * coefficient
        if value:
            row[variable] = value
        else:
            row.pop(variable, None)
    return constant, row


def combine_form(row, forms):
    out = ZERO_FORM
    for variable, coefficient in row.items():
        out = add_form(out, forms[variable], scalar(coefficient))
    return out


def add_target(target, key, form, scale=1):
    value = add_form(target.get(key, ZERO_FORM), form, scale)
    if value != ZERO_FORM:
        target[key] = value
    else:
        target.pop(key, None)


def extract_axis_form(forms, axis):
    out = []
    for constant, row in forms:
        constant = OldAxisJet.coerce(constant).derivatives.get(axis, E3())
        coefficients = {}
        for parameter, coefficient in row.items():
            value = OldAxisJet.coerce(coefficient).derivatives.get(axis, E3())
            if value:
                coefficients[parameter] = value
        out.append((constant, coefficients))
    return out


def dead_second_rows(left_level, right_level, nf):
    rows, term_count = {}, 0
    diagonal = left_level == right_level
    for owner, imax, jmax, offset, cutoff in (
        ("f", 15, 60, 0, -3), ("g", 25, 100, nf, -5)
    ):
        for i in range(imax + 1):
            for j in range(2, jmax + 1):
                variable = offset + i * (jmax + 1) + j
                base = -25 * i + 5 * j
                for zeta_degree in range(j - 1):
                    exponent = (
                        base + (left_level - 5) + (right_level - 5)
                        + 12 * zeta_degree
                    )
                    if exponent > cutoff:
                        break
                    coefficient = (
                        comb(j, 2) * comb(j - 2, zeta_degree)
                        if diagonal else
                        j * (j - 1) * comb(j - 2, zeta_degree)
                    )
                    key = (owner, "F0", exponent, zeta_degree)
                    row = rows.setdefault(key, {})
                    row[variable] = row.get(variable, Rat3()) + Rat3(Q(coefficient))
                    term_count += 1
    rows = {
        key: {variable: coefficient for variable, coefficient in row.items()
              if coefficient}
        for key, row in rows.items() if any(row.values())
    }
    sentinel = 2 * 61 + 3
    expected = 3 if diagonal else 6
    exponent = -35 + (left_level - 5) + (right_level - 5)
    assert rows[("f", "F0", exponent, 0)][sentinel] == Rat3(expected)
    wrong = ("f", "F0", exponent + 1, 0)
    assert rows.get(wrong, {}).get(sentinel, Rat3()) != Rat3(expected)
    return rows, term_count


def lift_order(rows, records, pivots, target, nvariables):
    """Solve A0*x=target with exact base-echelon source replay."""
    pivot_rhs, compatibility, pivot_keys = {}, [], set()
    record_keys = set()
    for source, record in zip(rows, records):
        source_key, _, _ = source
        key, kind, pivot, lead, factors = record
        assert source_key == key
        record_keys.add(key)
        value = target.get(key, ZERO_FORM)
        for old, factor in factors:
            value = add_form(value, pivot_rhs[old], -scalar(factor))
        if kind == "pivot":
            pivot_keys.add(key)
            pivot_rhs[pivot] = add_form(ZERO_FORM, value, scalar(lead).inverse())
        elif value != ZERO_FORM:
            compatibility.append((key, value, "base-dependent"))
    for key in sorted(set(target) - record_keys):
        if target[key] != ZERO_FORM:
            compatibility.append((key, target[key], "derivative-only"))

    assert nvariables > 0
    assert all(0 <= variable < nvariables for variable in pivots)
    assert all(
        0 <= variable < nvariables
        for _, row, _ in rows
        for variable in row
    )
    free_set = set(range(nvariables)) - set(pivots)
    solution = [None] * nvariables
    for variable in range(nvariables - 1, -1, -1):
        if variable in free_set:
            solution[variable] = ZERO_FORM
            continue
        value = pivot_rhs[variable]
        for other, coefficient in pivots[variable].items():
            if other != variable:
                assert solution[other] is not None
                value = add_form(value, solution[other], -scalar(coefficient))
        solution[variable] = value

    base_rows = {key: row for key, row, _ in rows}
    for key in pivot_keys:
        assert combine_form(base_rows[key], solution) == target.get(key, ZERO_FORM)
    return solution, compatibility


def second_transport_target(pair, first_rows, second_rows, first_solutions,
                            base_forms):
    left, right = pair
    target = {}
    if left.startswith("d"):
        rows = first_rows[int(left[1:])]
        for key, row in rows.items():
            add_target(target, key, combine_form(row, first_solutions[right]), -1)
    if right.startswith("d") and right != left:
        rows = first_rows[int(right[1:])]
        for key, row in rows.items():
            add_target(target, key, combine_form(row, first_solutions[left]), -1)
    if left.startswith("d") and right.startswith("d"):
        rows = second_rows[(int(left[1:]), int(right[1:]))]
        for key, row in rows.items():
            add_target(target, key, combine_form(row, base_forms), -1)
    return target


def make_quad_forms(base_forms, first_solutions, second_solutions):
    out = []
    for index, (base_constant, base_row) in enumerate(base_forms):
        linear_constant, quadratic_constant = {}, {}
        for axis in ACTIVE_AXES:
            value = first_solutions[axis][index][0]
            if value:
                linear_constant[axis] = value
        for pair in TARGET_PAIRS:
            value = second_solutions[pair][index][0]
            if value:
                quadratic_constant[pair] = value
        row = {}
        parameters = set(base_row)
        for axis in ACTIVE_AXES:
            parameters.update(first_solutions[axis][index][1])
        for pair in TARGET_PAIRS:
            parameters.update(second_solutions[pair][index][1])
        for parameter in parameters:
            linear, quadratic = {}, {}
            for axis in ACTIVE_AXES:
                value = first_solutions[axis][index][1].get(parameter, E3())
                if value:
                    linear[axis] = value
            for pair in TARGET_PAIRS:
                value = second_solutions[pair][index][1].get(parameter, E3())
                if value:
                    quadratic[pair] = value
            coefficient = QuadJet(base_row.get(parameter, E3()), linear, quadratic)
            if coefficient:
                row[parameter] = coefficient
        out.append((QuadJet(base_constant, linear_constant, quadratic_constant), row))
    return out


def add_jet_form(left, right, scale=1):
    scale = QuadJet.coerce(scale)
    constant = left[0] + scale * right[0]
    row = dict(left[1])
    for parameter, coefficient in right[1].items():
        value = row.get(parameter, QuadJet()) + scale * coefficient
        if value:
            row[parameter] = value
        else:
            row.pop(parameter, None)
    return constant, row


def combine_jet_row(row, forms):
    out = (QuadJet(), {})
    for variable, coefficient in row.items():
        out = add_jet_form(out, forms[variable], QuadJet(scalar(coefficient)))
    return out


def build_sections(forms, nf):
    sections = {}
    for owner, imax, jmax, offset in (
        ("f", 15, 60, 0), ("g", 25, 100, nf)
    ):
        for power in (1, 2, 3):
            family = []
            for degree in range(16 if owner == "f" else 26):
                row = {
                    offset + variable: coefficient
                    for variable, coefficient in r.fb.x_chart_coefficient(
                        imax, jmax, power, degree
                    ).items()
                }
                family.append(combine_jet_row(row, forms))
            sections[(owner, power)] = family
    return sections


def build_pole_sections(forms, nf):
    out = []
    for imax, jmax, offset, power, degrees in (
        (15, 60, 0, -2, 61), (25, 100, nf, -4, 101)
    ):
        family = []
        for degree in range(degrees):
            row = {
                offset + variable: coefficient
                for variable, coefficient in nr.pole_coefficient(
                    imax, jmax, power, degree
                ).items()
            }
            family.append(combine_jet_row(row, forms))
        out.append(family)
    return tuple(out)


def configure_qd():
    qd.Dual = QuadJet
    qd.B = QuadJet.direction("q2") if "q2" in ACTIVE_AXES else QuadJet()
    qd.S = QuadJet(E3(qd.uniform.S_FIELD))
    qd.D = QuadJet(E3(qd.uniform.D_FIELD))
    qd.L = QuadJet(E3(qd.uniform.L_FIELD))
    qd.A = QuadJet(E3(qd.uniform.A_FIELD))
    qd.Q_PRIME = {0: QuadJet(1), 24: QuadJet(25)}
    for level in v81.Q_LEVELS:
        axis = f"q{level}"
        if axis in ACTIVE_AXES:
            qd.Q_PRIME[level - 1] = QuadJet.direction(axis, level)
    qd.R = qd.multiply(
        qd.multiply([QuadJet(-1), QuadJet(1)], [QuadJet(-1), QuadJet(1)]),
        [qd.D, -qd.S, QuadJet(1)],
    )
    qd.R3, qd.R5 = qd.power(qd.R, 3), qd.power(qd.R, 5)
    qd.POLE_F = {1: -(qd.L ** 3) * qd.A, 6: qd.L ** 3}
    qd.POLE_G = {
        0: QuadJet(r.b.Q(5, 9)) * qd.L ** 5 * qd.A ** 2,
        5: QuadJet(r.b.Q(-5, 3)) * qd.L ** 5 * qd.A,
        10: qd.L ** 5,
    }


def source_polynomial(row, rhs):
    out = {(): -QuadJet.coerce(rhs)} if rhs else {}
    for variable, coefficient in row.items():
        coefficient = QuadJet.coerce(coefficient)
        if coefficient:
            out[(variable,)] = coefficient
    return out


def add_polynomial(left, right, scale=1):
    scale = QuadJet.coerce(scale)
    out = dict(left)
    for monomial, coefficient in right.items():
        value = out.get(monomial, QuadJet()) + scale * coefficient
        if value:
            out[monomial] = value
        else:
            out.pop(monomial, None)
    return out


def solve_cert(rows):
    pivots, dependent = {}, []
    source = [
        (key, {variable: QuadJet.coerce(value) for variable, value in row.items()},
         QuadJet.coerce(rhs))
        for key, row, rhs in rows
    ]
    for row_index, (key, original_row, original_rhs) in enumerate(source):
        row, rhs = dict(original_row), original_rhs
        combination = {row_index: QuadJet(1)}
        while True:
            pivot = next((variable for variable in pivots
                          if variable in row and row[variable]), None)
            if pivot is None:
                break
            factor = row[pivot]
            old_row, old_rhs, old_combination = pivots[pivot]
            for variable, coefficient in old_row.items():
                value = row.get(variable, QuadJet()) - factor * coefficient
                if value:
                    row[variable] = value
                else:
                    row.pop(variable, None)
            rhs -= factor * old_rhs
            for old_index, coefficient in old_combination.items():
                value = combination.get(old_index, QuadJet()) - factor * coefficient
                if value:
                    combination[old_index] = value
                else:
                    combination.pop(old_index, None)
        base_variables = [variable for variable, coefficient in row.items()
                          if coefficient.value]
        if not base_variables:
            replay = {}
            for source_index, coefficient in combination.items():
                _, source_row, source_rhs = source[source_index]
                replay = add_polynomial(
                    replay, source_polynomial(source_row, source_rhs), coefficient
                )
            assert replay == source_polynomial(row, rhs)
            dependent.append((row_index, key, row, rhs, combination))
            continue
        pivot = min(base_variables)
        inverse = row[pivot].inverse()
        pivots[pivot] = (
            {variable: coefficient * inverse for variable, coefficient in row.items()},
            rhs * inverse,
            {index: coefficient * inverse for index, coefficient in combination.items()},
        )
    for pivot, (row, rhs, combination) in pivots.items():
        replay = {}
        for source_index, coefficient in combination.items():
            _, source_row, source_rhs = source[source_index]
            replay = add_polynomial(
                replay, source_polynomial(source_row, source_rhs), coefficient
            )
        assert replay == source_polynomial(row, rhs), pivot
    return pivots, dependent


def parameterize(nvariables, rows):
    pivots, dependent = solve_cert(rows)
    free = [variable for variable in range(nvariables) if variable not in pivots]
    parameter_of = {variable: index for index, variable in enumerate(free)}
    forms = [None] * nvariables
    for variable in range(nvariables - 1, -1, -1):
        if variable in parameter_of:
            forms[variable] = (QuadJet(), {parameter_of[variable]: QuadJet(1)})
            continue
        row, rhs, _ = pivots[variable]
        form = (rhs, {})
        for other, coefficient in row.items():
            if other != variable:
                assert other > variable and forms[other] is not None
                form = add_jet_form(form, forms[other], -coefficient)
        forms[variable] = form
    return pivots, forms, free, dependent


def compose_forms(forms, parameterization):
    out = []
    for constant, row in forms:
        result = (constant, {})
        for variable, coefficient in row.items():
            result = add_jet_form(result, parameterization[variable], coefficient)
        out.append(result)
    return out


def dependent_quadratic(dependent, stage):
    out = {}
    for compatibility_index, (_, key, row, rhs, _) in enumerate(dependent):
        for coefficient in list(row.values()) + [rhs]:
            coefficient = QuadJet.coerce(coefficient)
            assert not coefficient.value
            assert not coefficient.linear
        for variable, coefficient in row.items():
            for pair, value in coefficient.quadratic.items():
                if value:
                    out[(stage, compatibility_index, repr(key), f"x{variable}", pair)] = value
        for pair, value in rhs.quadratic.items():
            if value:
                out[(stage, compatibility_index, repr(key), "constant", pair)] = -value
    return out


def transport_quadratic(compatibilities):
    out = {}
    for pair, entries in compatibilities.items():
        for compatibility_index, (key, (constant, row), kind) in enumerate(entries):
            if constant:
                out[("transport", compatibility_index, repr(key),
                     f"{kind}:constant", pair)] = constant
            for parameter, coefficient in row.items():
                if coefficient:
                    out[("transport", compatibility_index, repr(key),
                         f"{kind}:p{parameter}", pair)] = coefficient
    return out


def write_table(outdir, values):
    lines = [
        "stage\tcompatibility\tkey\tcoordinate\taxis_left\taxis_right\t"
        "coefficient_sha256\tcoefficient_exact"
    ]
    pair_counts = {pair: 0 for pair in TARGET_PAIRS}
    for key in sorted(values, key=repr):
        stage, compatibility, row_key, coordinate, pair = key
        value = values[key]
        pair_counts[pair] += 1
        exact = v81.exact(value)
        lines.append(
            f"{stage}\t{compatibility}\t{row_key}\t{coordinate}\t"
            f"{pair[0]}\t{pair[1]}\t{sha256(exact.encode()).hexdigest()}\t{exact}"
        )
    text = "\n".join(lines) + "\n"
    path = outdir / f"K2_BLOCK_{BLOCK_A}_{BLOCK_B}.exact.tsv"
    path.write_text(text)
    denominator = allq.denominator_for(values.values()) if values else v81.tri.ONE
    factor_text = repr(denominator.factor()) + "\n"
    factor_path = outdir / f"K2_BLOCK_{BLOCK_A}_{BLOCK_B}.denominator.factor.txt"
    factor_path.write_text(factor_text)
    return (
        path,
        sha256(text.encode()).hexdigest(),
        denominator,
        factor_path,
        sha256(factor_text.encode()).hexdigest(),
        pair_counts,
    )


def quadratic_ring_controls():
    left, right = TARGET_PAIRS[0]
    x, y = QuadJet.direction(left), QuadJet.direction(right)
    if left == right:
        square = x ** 2
        assert square.quadratic[(left, right)] == E3(1)
        assert ((x + x) ** 2).quadratic[(left, right)] == E3(4)
        print("quadratic_diagonal_Taylor_coefficient_control=true")
    else:
        square = (x + y) ** 2
        assert square.quadratic[(left, right)] == E3(2)
        assert x * y == y * x
        print("quadratic_split_mixed_twice_product_control=true")
        print("quadratic_pair_swap_symmetry_control=true")
    unit = QuadJet(
        2, {left: E3(3), right: E3(5)}, {(left, right): E3(7)}
    )
    assert unit * unit.inverse() == QuadJet(1)
    assert QuadJet.second((left, right)) != QuadJet()
    print("quadratic_mixed_or_diagonal_product_control=true")
    print("quadratic_inverse_second_term_control=true")
    print("quadratic_registered_slot_positive_control=true", flush=True)


def source_coordinate_controls():
    """Assert the licensed source axes before any expensive compilation."""
    assert AXES == tuple(dict.fromkeys(AXES))
    assert Q_AXES == tuple(f"q{level}" for level in v81.Q_LEVELS)
    assert "q15" not in Q_AXES
    assert set(AXES) - set(Q_AXES) == {"d10", "d15"}
    configure_qd()
    for axis in ACTIVE_AXES:
        if axis.startswith("q"):
            level = int(axis[1:])
            assert qd.Q_PRIME[level - 1].linear.get(axis, E3()) == E3(level)
            if level == 2:
                assert qd.B.linear.get(axis, E3()) == E3(1)
        else:
            assert int(axis[1:]) in (10, 15)
    print("licensed_q_and_dead_source_coordinate_preflight=true")
    print("q15_target_shear_gauge_excluded_preflight=true", flush=True)


def main():
    assert platform.system() == "Linux", "AWS-only producer refuses non-Linux"
    assert "Amazon EC2" in Path("/sys/devices/virtual/dmi/id/sys_vendor").read_text()
    tag = os.environ.get("AWS_RUN_TAG", "")
    assert tag.startswith("td6_v84_k2_")
    outdir = Path(os.environ["TD6_OUTPUT_DIR"]).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    quadratic_ring_controls()
    source_coordinate_controls()
    print("producer=TD6-A3-QDEAD-PREVIOUS-POLE-K2-SHARD-V84")
    print(f"aws_hostname={socket.gethostname()}")
    print(f"aws_run_tag={tag}")
    print(f"block_pair={BLOCK_A},{BLOCK_B}")
    print("active_axes=" + ",".join(ACTIVE_AXES))
    print("target_pairs=" + ",".join(f"{a}:{b}" for a, b in TARGET_PAIRS))
    print("source_center=(C,V,U);symbolic=true")
    print("q15_target_shear_gauge_excluded=true")
    print("scope=common_generic_rank_open_fixed_A3_quadratic_source_incidence")
    print("no_current_family_TD6_SP2_or_JC2_claim=true", flush=True)

    nf, ng, rows, pivots, records = v81.build_base_transport()
    q_rhs = v81.propagate_q(rows, records)
    q_forms, free132 = v81.global_q_forms(nf + ng, pivots, q_rhs)
    assert len(free132) == 132
    base_forms = [v81.base_form(form) for form in q_forms]

    first_solutions, first_rows = {}, {}
    for axis in ACTIVE_AXES:
        if axis.startswith("q"):
            first_solutions[axis] = extract_axis_form(q_forms, axis)
        else:
            level = int(axis[1:])
            derivative_rows, terms = v81.dead_derivative_rows(level, nf)
            derivatives, compatibility, omission_failures = v81.dead_lift(
                level, rows, records, pivots, q_forms, derivative_rows
            )
            assert not compatibility and omission_failures > 0
            first_rows[level] = derivative_rows
            first_solutions[axis] = derivatives
            print(f"{axis}_first_matrix_terms={terms}")
    for axis in ACTIVE_AXES:
        assert len(first_solutions[axis]) == nf + ng

    second_rows, second_terms = {}, {}
    for pair in TARGET_PAIRS:
        if pair[0].startswith("d") and pair[1].startswith("d"):
            levels = (int(pair[0][1:]), int(pair[1][1:]))
            second_rows[levels], second_terms[pair] = dead_second_rows(*levels, nf)
            print(f"{pair[0]}_{pair[1]}_second_matrix_terms={second_terms[pair]}")

    second_solutions, transport_compatibilities = {}, {}
    for pair in TARGET_PAIRS:
        target = second_transport_target(
            pair, first_rows, second_rows, first_solutions, base_forms
        )
        if target:
            solution, compatibility = lift_order(
                rows, records, pivots, target, len(base_forms)
            )
        else:
            solution = [ZERO_FORM for _ in range(nf + ng)]
            compatibility = []
        second_solutions[pair] = solution
        transport_compatibilities[pair] = compatibility
        print(
            f"pair={pair[0]}:{pair[1]};transport_target_rows={len(target)};"
            f"transport_quadratic_compatibilities={len(compatibility)}",
            flush=True,
        )

    quad_forms = make_quad_forms(base_forms, first_solutions, second_solutions)
    assert r.fb.CENTER == (Rat3(C), Rat3(V), Rat3(U))
    bands = build_sections(quad_forms, nf)
    pole_f, pole_g = build_pole_sections(quad_forms, nf)
    configure_qd()

    first_rows_compiled = qd.pack(
        "X-2", qd.first_band_polynomials(
            bands[("f", 1)], bands[("g", 1)]
        )
    )
    first_pivots, first_forms, free94, first_dependent = parameterize(
        132, first_rows_compiled
    )
    assert len(first_pivots) == 38 and len(free94) == 94
    assert not first_dependent
    print("first_rank=38/132;dependent=0")
    print("all_first_quadratic_pivot_source_combinations_replayed=true", flush=True)

    bands94 = {key: compose_forms(forms, first_forms) for key, forms in bands.items()}
    pole_f94 = compose_forms(pole_f, first_forms)
    pole_g94 = compose_forms(pole_g, first_forms)
    previous_rows = qd.pack(
        "X-1", qd.compile_previous(
            bands94[("f", 1)], bands94[("f", 2)],
            bands94[("g", 1)], bands94[("g", 2)],
        )
    )
    previous_rows += qd.pack("P1", qd.compile_pole_previous(pole_f94, pole_g94))
    previous_pivots, previous_forms, free56, previous_dependent = parameterize(
        94, previous_rows
    )
    assert len(previous_pivots) == 38 and len(free56) == 56
    print(f"previous_pole_rank=38/94;dependent={len(previous_dependent)}")
    print("all_previous_pole_quadratic_pivot_source_combinations_replayed=true")

    values = transport_quadratic(transport_compatibilities)
    previous_values = dependent_quadratic(previous_dependent, "previous_pole")
    assert not values.keys() & previous_values.keys()
    values.update(previous_values)
    (
        path,
        digest,
        denominator,
        denominator_factor_path,
        denominator_factor_sha,
        pair_counts,
    ) = write_table(outdir, values)
    print(f"quadratic_coordinate_count={len(values)}")
    print(f"quadratic_table={path}")
    print(f"quadratic_table_sha256={digest}")
    print(f"quadratic_denominator_factor={denominator.factor()}")
    print(f"quadratic_denominator_factor_file={denominator_factor_path}")
    print(f"quadratic_denominator_factor_sha256={denominator_factor_sha}")
    for pair in TARGET_PAIRS:
        print(f"quadratic_pair_count[{pair[0]}:{pair[1]}]={pair_counts[pair]}")
    print("linear_specialization_reproduces_stage_A_zero=true")
    print("diagonal_coefficients_are_Taylor_not_classical_second_derivatives=true")
    print("raw_rank_drop_denominator_fibres_remain_debt=true")
    print("quadratic_zero_does_not_imply_family=true")
    print("TD6-A3-QDEAD-PREVIOUS-POLE-K2-SHARD-V84 PASS")


if __name__ == "__main__":
    main()
