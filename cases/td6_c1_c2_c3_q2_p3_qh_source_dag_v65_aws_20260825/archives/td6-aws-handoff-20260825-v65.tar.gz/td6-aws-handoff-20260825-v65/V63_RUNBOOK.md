# V63 P3/QH curve source-DAG producer

This exact AWS-only producer handles the two H=0 curve factors

```text
P3/U^6 = T^2 - 32T + 128,
QH/U^6 = T^2 +  8T -  64,
T=V^2/U^3,
```

over their degree-four function fields.  It preserves polynomial beta,
source q/q-prime entry points, original current/previous/first rows, the
singleton N13 ancestry, and the genuine direct-first P12 relation.  Every
Q[U] denominator/norm factor is emitted.  The U=0 endpoint remains a separate
direct stratum.

For QH the producer asserts the exact Bezout identity

```text
((5T-136) QH - (5T+64) P3)/512 = 1,
```

so P3 and QH are disjoint on D(U); it also checks T is invertible, hence
QH intersect V=0 only over U=0.

Preflight:

```bash
TD6_PREFLIGHT_ONLY=1 ./run_v63.sh p3
TD6_PREFLIGHT_ONLY=1 ./run_v63.sh qh
```

Full run:

```bash
TD6_OUTPUT_DIR=/absolute/output ./run_v63.sh p3
TD6_OUTPUT_DIR=/absolute/output ./run_v63.sh qh
```

No whole-H, full-A3, full-TD6, SP-2, landing, or JC2 claim is made.

