# V65 repaired P3/QH curve source DAG

V65 preserves V63's exact function-field source calculation and separates
the true N13 previous-edge list from the lift-cache union.  The first
quadratic row remains an independent positive control unless the live edge
list itself includes it.  V65 adds a true previous-edge omission, correctly
names the singleton current-row omission, moves the arbitrary-degree marker
after its replay, records `k` as a frozen residue-field unit, and strengthens
the live genuine-P12 negative marker.

```bash
TD6_PREFLIGHT_ONLY=1 ./run_v65.sh p3
TD6_PREFLIGHT_ONLY=1 ./run_v65.sh qh
TD6_OUTPUT_DIR=/absolute/output ./run_v65.sh p3
TD6_OUTPUT_DIR=/absolute/output ./run_v65.sh qh
TD6_OUTPUT_DIR=/absolute/output ./run_v65.sh p3 omit-direct-qprime
```

Every curve/source denominator remains charged.  No component endpoint,
whole-H, full-A3, TD6, SP-2, or JC2 conclusion is inferred inside the run.
