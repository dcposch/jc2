#!/usr/bin/env bash
set -euo pipefail

component="${1:-}"
case "$component" in
  p3|qh) ;;
  *) echo "usage: $0 {p3|qh}" >&2; exit 64 ;;
esac

root_dir="$(cd "$(dirname "$0")" && pwd)"
cd "$root_dir"
python_bin="${TD6_PYTHON:-/home/ubuntu/venvs/td6/bin/python}"
export PYTHONHASHSEED=0

if [[ "${TD6_PREFLIGHT_ONLY:-0}" != 1 ]]; then
  : "${TD6_OUTPUT_DIR:?set TD6_OUTPUT_DIR}"
fi

exec "$python_bin" \
  jc2/cases/td6_c1_c2_c3_q2_curve_source_dag_v63_20260825/replay.py \
  --component="$component"
