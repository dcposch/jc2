# V81C preregistration — generic-center dead-column shards

For each selected `d_m`, independently rebuild the symbolic-center rank-3470
base transport, solve `A x'_m = -A'_m x_0`, replay all 3,470 differentiated
original pivot rows, retain derivative-only rows, emit the exact generic
compatibility table, and reproduce the frozen V80B point-table SHA after
`(C,V,U)=(1,1,1)`.

Each shard is single-axis evidence only.  It neither recomputes the 22 q
transport columns nor proves a joint dead kernel.  Joint conclusions require
the full V81B single-ring producer or a separately reviewed exact union
assembler.  No first/previous/current, Fitting/Kuranishi, family, TD6, SP-2,
or JC2 claim is licensed.
