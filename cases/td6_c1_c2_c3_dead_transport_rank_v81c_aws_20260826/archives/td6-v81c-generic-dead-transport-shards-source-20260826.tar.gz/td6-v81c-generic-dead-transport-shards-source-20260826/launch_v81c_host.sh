#!/usr/bin/env bash
set -euo pipefail

if [[ "$(uname -s)" != Linux ]]; then
  echo "REFUSED: V81C launcher is AWS/Linux only" >&2
  exit 97
fi
if [[ $# -ne 2 ]]; then
  echo "usage: $0 RUN_ROOT HOST_LABEL" >&2
  exit 2
fi

run_root=$1
host_label=$2
source_dir=$(pwd -P)
mkdir -p "$run_root"

for level in {6..16}; do
  lane="$run_root/d$level"
  tag="td6_v81c_${host_label}_d${level}_20260826T0225Z"
  mkdir -p "$lane/evidence"
  printf 'host=%s\ntag=%s\ndead_level=%s\ncap_kib=8388608\ntimeout_seconds=14400\n' \
    "$(hostname)" "$tag" "$level" > "$lane/launch.meta"
  nohup bash -c '
    set +e
    lane=$1
    source_dir=$2
    tag=$3
    level=$4
    ulimit -v 8388608
    cd "$source_dir" || exit 120
    export AWS_RUN_TAG="$tag"
    export TD6_DEAD_LEVEL="$level"
    export TD6_OUTPUT_DIR="$lane/evidence"
    /usr/bin/time -v timeout 14400 bash run_v81c.sh
    rc=$?
    printf "%s\n" "$rc" > "$lane/rc"
    exit "$rc"
  ' _ "$lane" "$source_dir" "$tag" "$level" \
    > "$lane/stdout" 2> "$lane/stderr" < /dev/null &
  printf '%s\n' "$!" > "$lane/pid"
done

for level in {6..16}; do
  printf 'd%s\t%s\n' "$level" "$(cat "$run_root/d$level/pid")"
done
