# TD6 V81C generic dead-column shard source bundle

AWS-only exact generic-center one-dead-axis accelerator.  Run with registered
`AWS_RUN_TAG=td6_v81c_*`, `TD6_DEAD_LEVEL=6..16`, and `TD6_OUTPUT_DIR`
through `run_v81c.sh`.

The selected V80B point result is used only through its pinned specialization
table hash.  V81C is a single-axis transport certificate; it is not a joint
kernel and does not replace the full one-ring V81B run.

The V81A errata remain in the source closure as negative custody.  Only V81C
shard launches through the pinned TD6 AWS virtual environment are consumable.
