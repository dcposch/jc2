# TD6 V82S2 d10/d15 first-stage shard source bundle

AWS-only corrected exact generic-center first-stage shards for the two transport-kernel
dead axes.  Run with a registered `AWS_RUN_TAG=td6_v82s_*`,
`TD6_DEAD_LEVEL=10|15`, and `TD6_OUTPUT_DIR` through `run_v82s.sh`.

Each shard imports the hash-pinned V82/V81 source compilers, independently
rebuilds transport for one of d10,d15, and advances that column to the first
X-band equations.  Their exact row-key union is a later gate.  Previous,
pole, current, and nonlinear Kuranishi work remain separate.

`V81A_DEPLOYMENT_ERRATUM.md` and `V81A_MATH_HARNESS_ERRATUM.md` record the two
pre-result V81A failures.  Only V82S launches through the pinned TD6 AWS
virtual environment are mathematically consumable for this shard successor.
V82S2 corrects only V82S's empty-table constant-constructor reporter defect;
the complete algebra is rerun and an explicit empty-table control is retained.
