# V82S2 reporter erratum

The immutable V82S dual-host runs reached an empty first-conormal coordinate
dictionary for both d10 and d15, then returned rc 1 while serializing the
denominator of that empty table.  The source called the polynomial-ring
context object as `CTX(1)`; python-flint requires `CTX.constant(1)`, already
exported by the pinned trivariate module as `ONE`.

V82S2 changes only that empty-table constant constructor and asserts
`ONE == CTX.constant(1)`.  It reruns the complete transport, raw-column,
omission, first-parameterization, source-replay, and table pipeline on two AWS
hosts.  The older V82S output is reporter-negative evidence only.
