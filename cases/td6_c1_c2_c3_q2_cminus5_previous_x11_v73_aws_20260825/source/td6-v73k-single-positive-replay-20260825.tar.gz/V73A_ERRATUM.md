# V73A reporter/source-index erratum

The first dual main and q-prime-control runs stopped after proving the exact
`('X-1',11)` residual and its D(U)-unit factor support, but before any
original-source identity was claimed. The failed assertion required the raw
previous-row key list to equal the packed echelon-row key list. This is false
because `source_records` deliberately retains zero source rows while
`qd.pack` omits them.

V73B replaces only that false positional assertion with the reviewed
key-index discipline: raw keys are unique; every packed key must occur in the
raw key map; reduced dependency multipliers and raw-source multipliers use
separate vectors indexed in their own row sets. No rank, residual, pivot,
factor, or mathematical expectation was changed. V73A is reporter-failure
evidence only and licenses no source theorem.
