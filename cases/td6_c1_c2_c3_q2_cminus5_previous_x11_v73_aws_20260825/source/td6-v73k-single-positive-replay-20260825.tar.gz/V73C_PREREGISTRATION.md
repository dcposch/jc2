# V73C aggregate source-lift preregistration

V73C is an independent fast representation of the same V73 source theorem.
After the exact previous-stage left-null relation for `('X-1',11)` is
computed, it forms the weighted sum of the corresponding raw previous/pole
source rows and divides that one aggregate polynomial through the original
first-stage pivots.  It must replay the resulting combination directly
against the original previous/pole and first rows with target `-residual`,
normalize by the exact inverse to target `-1`, emit all coordinate and leaf
denominators, and retain omission, plus-one, wrong-row, and direct-qprime
controls.  No edgewise-lift claim is made.  V73B remains live as the stronger
edgewise representation check.  Scope and fail-closed rules are unchanged.
