# TD6 V72 preregistration: `V=0,C=-5U^2,D(U)` source-DAG repair

## Fixed target

Run the reviewed V65/V67 staged source-DAG construction on the exact raw
line `V=0,C=-5U^2` over `Q(U)`, retaining polynomial beta in
`q_beta=t+beta*t^2+t^25` and the direct source term
`q_beta'=1+2 beta t+25 t^24`.

The hash-pinned parent mode `b3half` is used only as a `Q(U)` field adapter.
The producer rebuilds and asserts the raw center `(-5U^2,0,U)` and raw B3
identity itself.  It must carry the singleton current N13 row through every
actual previous/pole and first original row, separately replay genuine P12
through original first rows, and emit all leaf/stage/chart denominators.

## Pass gate

- exact source/import preflight and raw-center/B3 assertions;
- transport/first/previous/current staged ranks accepted only at the hard
  assertions inherited from the reviewed V67 source-DAG implementation;
- exactly one N13 compatibility, equal to `(k/25)beta`;
- exact current-to-previous-to-first original-source DAG, with omitted
  current and previous-edge controls failing as required;
- genuine P12 direct-first replay and combined residual `-k/50`;
- complete denominator factor ledger, with no unrecorded factor;
- direct-qprime omission must change N13 and return only the explicit
  omission-control PASS token;
- byte/expression agreement of independent Box02 and Box03 theorem runs.

Any rank change, extra compatibility, extra denominator factor, failed DAG
edge, or assertion failure is a fail-closed new stratum/result, never patched
into an expected PASS.

## Execution boundary and scope

`run_v72.sh` refuses Darwin/non-Linux, requires an explicit registered AWS
tag, and requires the caller-provided expected hostname to equal `hostname`.
Heavy execution is AWS-only under per-run memory and time caps.

Even a PASS proves only the fixed normalized A3 q2-beta line
`V=0,C=-5U^2,D(U)`, for all beta.  The origin is the separate reviewed V70
leaf.  No whole B3, whole A3, other TD6 modulus, TD6, SP-2, landing,
counterexample, or JC2 inference is licensed inside this producer.
