#!/usr/bin/env bash
set -euo pipefail

platform=$(uname -s)
if [[ "$platform" != "Linux" ]]; then
  echo "REFUSE: V73 heavy replay is AWS/Linux-only; platform=$platform" >&2
  exit 90
fi

: "${TD6_AWS_RUN_TAG:?REFUSE: registered TD6_AWS_RUN_TAG is required}"
: "${TD6_AWS_EXPECTED_HOST:?REFUSE: TD6_AWS_EXPECTED_HOST is required}"
case "${PYTHONOPTIMIZE:-}" in
  ""|0) ;;
  *) echo "REFUSE: assert-based V73 gate requires PYTHONOPTIMIZE=0" >&2; exit 94 ;;
esac
actual_host=$(hostname)
if [[ "$actual_host" != "$TD6_AWS_EXPECTED_HOST" ]]; then
  echo "REFUSE: hostname mismatch actual=$actual_host expected=$TD6_AWS_EXPECTED_HOST" >&2
  exit 91
fi
case "$TD6_AWS_RUN_TAG" in
  td6_v73_cminus5_x11_*) ;;
  *)
    echo "REFUSE: unregistered V73 tag $TD6_AWS_RUN_TAG" >&2
    exit 92
    ;;
esac

printf 'aws_platform=%s\naws_hostname=%s\naws_run_tag=%s\n' \
  "$platform" "$actual_host" "$TD6_AWS_RUN_TAG"
sha256sum -c V73_SOURCE.sha256
sha256sum -c V67_SOURCE.sha256

mode=${1:-main}
case "$mode" in
  preflight)
    export TD6_PREFLIGHT_ONLY=1
    extra=()
    ;;
  main)
    extra=()
    ;;
  omit-direct-qprime)
    extra=(--omit-direct-qprime)
    ;;
  *)
    echo "REFUSE: unknown V73 mode $mode" >&2
    exit 93
    ;;
esac

export PYTHONHASHSEED=0
exec "${TD6_PYTHON:-python3}" \
  jc2/cases/td6_c1_c2_c3_q2_cminus5_previous_x11_v73_20260825/replay.py \
  --component=b3half "${extra[@]}"
