#!/usr/bin/env bash
set -u

test "$(uname -s)" = Linux || { echo "REFUSE: AWS Linux required" >&2; exit 97; }
test "$#" -eq 3 || { echo "usage: run_v80_one.sh LEVEL RUN_DIR TAG" >&2; exit 96; }

level="$1"
run_dir="$2"
tag="$3"
payload_root="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$run_dir/evidence"
cd "$payload_root"

export PATH="/home/ubuntu/venvs/td6/bin:$PATH"
export TD6_REGISTERED_AWS_TAG="$tag"
export TD6_DEAD_LEVEL="$level"
export TD6_OUTPUT_DIR="$run_dir/evidence"

set +e
/usr/bin/time -v timeout 14400 bash -c \
  'ulimit -v 12582912; exec bash ./run_v80_shard.sh'
rc="$?"
set -e
printf '%s\n' "$rc" > "$run_dir/rc"
exit "$rc"
