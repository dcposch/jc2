#!/usr/bin/env bash
set -euo pipefail

test "$(uname -s)" = Linux || { echo "REFUSE: AWS Linux required" >&2; exit 97; }
test -n "${TD6_REGISTERED_AWS_TAG:-}" || { echo "REFUSE: tag required" >&2; exit 98; }
test -n "${TD6_DEAD_LEVEL:-}" || { echo "REFUSE: dead level required" >&2; exit 99; }
case "$TD6_DEAD_LEVEL" in 6|7|8|9|10|11|12|13|14|15|16) ;; *) exit 100 ;; esac
test -n "${TD6_OUTPUT_DIR:-}" || { echo "REFUSE: output dir required" >&2; exit 101; }

printf 'aws_platform=%s\n' "$(uname -s)"
printf 'aws_hostname=%s\n' "$(hostname)"
printf 'aws_run_tag=%s\n' "$TD6_REGISTERED_AWS_TAG"
sha256sum -c SOURCE.sha256
python3 jc2/cases/td6_c1_c2_c3_dead_stretch_transport_v80b_20260826/replay_shard.py
