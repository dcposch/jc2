#!/usr/bin/env bash
set -euo pipefail

test "$(uname -s)" = Linux || { echo "REFUSE: AWS Linux required" >&2; exit 97; }
test -n "${TD6_V80_HOST_TAG:-}" || { echo "REFUSE: host tag required" >&2; exit 98; }
test -n "${TD6_V80_RUN_ROOT:-}" || { echo "REFUSE: run root required" >&2; exit 99; }

payload_root="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$TD6_V80_RUN_ROOT"
printf 'host=%s\nhost_tag=%s\nrun_root=%s\n' \
  "$(hostname)" "$TD6_V80_HOST_TAG" "$TD6_V80_RUN_ROOT"

for level in 6 7 8 9 10 11 12 13 14 15 16; do
  shard_dir="$TD6_V80_RUN_ROOT/d$level"
  mkdir -p "$shard_dir"
  shard_tag="${TD6_V80_HOST_TAG}_d${level}"
  nohup "$payload_root/run_v80_one.sh" "$level" "$shard_dir" "$shard_tag" \
    > "$shard_dir/stdout" 2> "$shard_dir/stderr" < /dev/null &
  pid="$!"
  printf '%s\n' "$pid" > "$shard_dir/pid"
  printf 'level=d%s pid=%s tag=%s stdout=%s stderr=%s\n' \
    "$level" "$pid" "$shard_tag" "$shard_dir/stdout" "$shard_dir/stderr"
done
