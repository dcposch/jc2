# TD6 V82P4 d10/d15 current-adjoint shard source bundle

AWS-only exact generic-center successors for the two transport-kernel dead
axes.  Each lane independently reconstructs transport, FIRST, previous, and
pole source identities, fails closed unless every pre-current conormal
vanishes, and then emits the exact current dependent-row adjoint column with
denominator and original-row replay.

Run through `run_v82p4.sh` with registered `AWS_RUN_TAG=td6_v82p4_*`,
`TD6_DEAD_LEVEL=10|15`, and a fresh `TD6_OUTPUT_DIR`.  The package inherits
the hash-pinned V82S2/V82/V81/V78 source closure.  Its conclusions are
localized square-zero current-adjoint scheduling statements only.  The base
current system is already inconsistent, so no tangent-space, family,
neighborhood, TD6, SP-2, or JC2 inference is licensed.

V82P2 reruns the complete V82P algebra with the inherited empty-table
serializer repaired to use the pinned trivariate ring's `ONE`.  A separate
header-only empty-table positive control executes before the mathematical
pipeline.  Original V82P runs remain immutable controls and are not consumed
if they reach the inherited reporter defect.

V82P and V82P2 instead exposed an earlier typed-composition defect: they sent
33-axis `AxisJet` affine scales into the q-only `EJet` composer.  V82P3 pins
the corrected V82S2 source and composes all first-to-previous/pole forms with
the `AxisJet` affine operation.  A small nontrivial square-zero preflight and
full pre/post type assertions execute before the expensive stage.  V82P and
V82P2 remain failed-harness controls; neither supplies previous/pole math.

V82P4 keeps the corrected `AxisJet` composition boundary, requires the V82P3
previous/pole conormal to be exactly zero inside its own replay, and advances
the same source column to `X0`.  The emitted current table includes the
varying-echelon (`lambda-prime`) contribution.  A nonzero derivative is not a
family obstruction because it is evaluated at an already inconsistent base.
