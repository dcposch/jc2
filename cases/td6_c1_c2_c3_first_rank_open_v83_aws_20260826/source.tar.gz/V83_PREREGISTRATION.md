# V83 preregistration

- Target: one exact rank-38 principal open for the packed symbolic-center
  FIRST map, certified by the ordered product of its 38 source-replayed pivot
  leads.
- Coefficient field: `E(C,V,U)`; centers remain symbolic throughout.
- Required outputs: all 38 row keys/pivot columns/leads, reduced selected-minor
  numerator and denominator, denominator of the full packed FIRST matrix,
  exact factorizations/radicals, and a deduplicated raw-fibre debt ledger.
- Licensed comparison divisors: only `U`, `C-3U^2`, and `B3`.  No prior
  `D(U*H*B3)` rank-open assumption is allowed.
- Controls: source-combination replay for every pivot; exact constant `E`-unit
  separation; omitted-pivot, plus-one, and rank-37 controls.
- Execution: byte-identical source on r6d and Box03, Amazon EC2 Linux only,
  16 GiB address-space cap and four-hour timeout per host.
- Promotion gate: dual rc0, exact mathematical stdout/table agreement, source
  closure, immutable custody, and hostile different-model review.
- Firewall: rank-open only; no rank-drop fibre, nonlinear family, TD6, SP2, or
  JC2 claim.  K2 is not launched here.

