# TD6 V83 generic FIRST rank-open certificate

This source package rebuilds the symbolic-center transport and packed FIRST
matrix over `E(C,V,U)`, extracts the 38 source-replayed Gaussian pivot leads,
and records their exact product as a certified selected `38x38` minor (up to
an explicitly printed constant `E`-unit).

The output defines the rank-open principal polynomial from the reduced minor
numerator and the denominator needed to define the complete packed FIRST
matrix.  Its factor ledger compares components only with the licensed chart
divisors `U`, `H=C-3U^2`, and `B3`.  Every other component is emitted to
`RAW_FIBRE_SUCCESSORS.tsv`; the runner never equates the result with
`D(U*H*B3)`.

Run only on a registered Amazon EC2 Linux host through `run_v83.sh`.  The
calculation is first-order and fixed-source-presentation only.  It gives no
nonlinear family, full TD6, SP2, or JC2 conclusion.  K2 remains barred until
the separate previous/pole Stage A fixes `Q_prev`.

