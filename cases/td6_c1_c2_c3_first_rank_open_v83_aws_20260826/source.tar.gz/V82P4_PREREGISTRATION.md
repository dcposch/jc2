# TD6 V82P4 current-adjoint preregistration

Date: 2026-08-26

Axes: independently `d10` and `d15` over the generic symbolic center
`E(C,V,U)`, with fixed source-typed A3/F1 data and base `q=t+t^25`.

Gate sequence:

1. reconstruct and source-replay the 3,470-row transport echelon;
2. require selected-axis transport conormal zero and a nonzero omission
   control;
3. require FIRST rank `38/132`, selected-axis FIRST conormal zero, and the
   original-row replay;
4. require previous/pole rank `38/94`, selected-axis conormal zero, unit
   denominator, and typed `AxisJet` composition;
5. only then compile the current rows, source-replay every pivot and dependent
   row, retain the varying-echelon derivative, and emit the complete selected-
   axis current adjoint table plus the `('X0',12)` dependent RHS value and
   derivative.

Fail closed on any preceding nonzero conormal, source/type/hash failure,
unexpected rank, missing base current inconsistency, missing P12 row, foreign
derivative key, disallowed denominator factor, or nonzero process exit.

Interpretation is fixed before execution: the base current system is already
inconsistent.  The current derivative is an adjoint sensitivity/scheduling
object only, not the tangent space of a solution and not a first-order family
kill.  No nonlinear neighborhood, full TD6, SP-2, or JC2 conclusion is
licensed.
