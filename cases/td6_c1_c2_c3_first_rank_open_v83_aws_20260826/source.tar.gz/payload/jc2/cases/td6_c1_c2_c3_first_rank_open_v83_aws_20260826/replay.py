#!/usr/bin/env python3
"""Exact generic-center TD6 FIRST rank-open certificate (V83).

This producer rebuilds the reviewed symbolic-center transport and packed
FIRST matrix over E(C,V,U), extracts the 38 Gaussian pivot leads, and records
their exact product.  The product is a certified selected 38x38 minor because
the source-replayed elimination uses only unit-lower row additions before
each unnormalised lead is recorded.  No claim is made outside the explicit
principal open printed by this program.

Every factor not belonging to the licensed chart radical U*(C-3U^2)*B3 is
emitted as raw-fibre debt.  In particular this producer never assumes that
the rank-38 open is D(U*(C-3U^2)*B3).
"""

from hashlib import sha256
import importlib.util
import os
from pathlib import Path
import platform
import socket
import sys


HERE = Path(__file__).resolve().parent
V82_PATH = (
    HERE.parent / "td6_c1_c2_c3_q_dead_joint_first_fitting_v82_20260826"
    / "replay.py"
)
V82_SHA256 = "537219eb8d4c4439697b537542600cc1f95851e8eda2175a9fee3bbde7c508e5"
assert sha256(V82_PATH.read_bytes()).hexdigest() == V82_SHA256
spec = importlib.util.spec_from_file_location("td6_v83_v82_parent", V82_PATH)
v82 = importlib.util.module_from_spec(spec)
assert spec.loader is not None
sys.modules[spec.name] = v82
spec.loader.exec_module(v82)

v81, r, tri, allq = v82.v81, v82.r, v82.tri, v82.allq
Rat3, E3, AxisJet = v82.Rat3, v82.E3, v82.AxisJet
C, V, U, B3 = v82.C, v82.V, v82.U, v82.B3
H = C - 3 * U**2
ONE = tri.ONE


def monic(polynomial):
    if not polynomial:
        return polynomial
    return polynomial / polynomial.leading_coefficient()


def factor_records(polynomial):
    if not polynomial or polynomial.total_degree() == 0:
        return []
    _, factors = polynomial.factor()
    return [(monic(factor), multiplicity) for factor, multiplicity in factors]


def radical(polynomial):
    out = ONE
    for factor, _ in factor_records(polynomial):
        out *= factor
    return monic(out)


def scalar_coordinates(value):
    value = E3.coerce(value).value
    return tuple(
        coordinate
        for kvalue in value.coefficients
        for coordinate in kvalue.coordinates
    )


def scalar_rat3(value):
    coordinates = scalar_coordinates(value)
    nonzero = [(index, coordinate) for index, coordinate in enumerate(coordinates)
               if coordinate]
    assert len(nonzero) == 1, (
        "FIRST pivot is not a constant E-unit times one Rat3 scalar",
        len(nonzero),
    )
    return nonzero[0]


def constant_e_unit(value):
    assert value
    for coordinate in scalar_coordinates(value):
        if coordinate:
            assert coordinate.numerator.total_degree() == 0
            assert coordinate.denominator.total_degree() == 0
    return True


def polynomial_sha(polynomial):
    return sha256(str(monic(polynomial)).encode()).hexdigest()


def factor_text(polynomial):
    return str(polynomial.factor())


def factor_class(factor, licensed):
    key = str(monic(factor))
    return licensed.get(key, "extra")


def all_first_values(first_rows):
    for _, row, rhs in first_rows:
        yield AxisJet.coerce(rhs).value
        for coefficient in row.values():
            yield AxisJet.coerce(coefficient).value


def selected_first_values(first_rows, selected_rows, selected_columns):
    for row_index in selected_rows:
        _, row, _ = first_rows[row_index]
        for column in selected_columns:
            yield AxisJet.coerce(row.get(column, AxisJet())).value


def write_pivot_ledger(path, records):
    lines = [
        "pivot_index\trow_index\trow_key\tpivot_column\t"
        "e_basis_coordinate\tlead_exact_sha256\trat_num\trat_den\t"
        "rat_num_factor\trat_den_factor"
    ]
    for pivot_index, record in enumerate(records):
        row_index, key, pivot, lead, coordinate_index, scalar = record
        exact = v81.exact(lead.value)
        lines.append(
            "\t".join((
                str(pivot_index), str(row_index), repr(key), str(pivot),
                str(coordinate_index), sha256(exact.encode()).hexdigest(),
                str(scalar.numerator), str(scalar.denominator),
                factor_text(scalar.numerator), factor_text(scalar.denominator),
            ))
        )
    text = "\n".join(lines) + "\n"
    path.write_text(text)
    return sha256(text.encode()).hexdigest()


def write_factor_ledger(path, named_polynomials, licensed):
    lines = [
        "source\trole\tmultiplicity\tclassification\tfactor_sha256\tfactor"
    ]
    debts = {}
    for source, role, polynomial in named_polynomials:
        for factor, multiplicity in factor_records(polynomial):
            classification = factor_class(factor, licensed)
            digest = polynomial_sha(factor)
            lines.append(
                f"{source}\t{role}\t{multiplicity}\t{classification}\t"
                f"{digest}\t{factor}"
            )
            if classification == "extra":
                debts.setdefault(digest, {"factor": factor, "roles": set()})[
                    "roles"
                ].add(f"{source}:{role}")
    text = "\n".join(lines) + "\n"
    path.write_text(text)
    return sha256(text.encode()).hexdigest(), debts


def write_debt_ledger(path, debts):
    lines = ["factor_sha256\troles\traw_fibre\tstatus"]
    for digest, debt in sorted(debts.items()):
        lines.append(
            f"{digest}\t{','.join(sorted(debt['roles']))}\t"
            f"V({debt['factor']})\tREQUIRES_ORIGINAL_SOURCE_REBUILD"
        )
    text = "\n".join(lines) + "\n"
    path.write_text(text)
    return sha256(text.encode()).hexdigest()


def main():
    assert platform.system() == "Linux", "AWS-only producer refuses non-Linux"
    assert "Amazon EC2" in Path("/sys/devices/virtual/dmi/id/sys_vendor").read_text()
    tag = os.environ.get("AWS_RUN_TAG", "")
    assert tag.startswith("td6_v83_first_rank_open_")
    outdir = Path(os.environ["TD6_OUTPUT_DIR"]).resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    print("producer=TD6-A3-FIRST-RANK-OPEN-V83")
    print(f"aws_hostname={socket.gethostname()}")
    print(f"aws_run_tag={tag}")
    print("coefficient_field=E(C,V,U)")
    print("source_center=(C,V,U);symbolic=true")
    print("licensed_chart_factors=U,C-3U^2,B3")
    print("assumed_rank_open_D_U_H_B3=false")
    print("quadratic_or_family_claim=false", flush=True)

    # Rebuild the reviewed symbolic-center transport and the base packed FIRST
    # presentation.  Square-zero columns are retained as ancestry controls but
    # only base values enter the rank-open certificate.
    nf, ng, rows, pivots, records = v81.build_base_transport()
    q_rhs = v81.propagate_q(rows, records)
    q_forms, free = v81.global_q_forms(nf + ng, pivots, q_rhs)
    assert len(free) == 132
    bands = v82.build_sections(q_forms, nf)
    v82.configure_qd()
    first_rows = v82.qd.pack(
        "X-2", v82.qd.first_band_polynomials(
            bands[("f", 1)], bands[("g", 1)]
        )
    )
    first_pivots, _, free94, first_factors, first_dependent = v82.parameterize(
        132, first_rows
    )
    assert len(first_pivots) == 38
    assert len(free94) == 94
    assert len(first_factors) == 38
    assert len(first_dependent) == 0
    print("packed_first_rank=38/132")
    print("packed_first_dependent_count=0")
    print("all_first_pivot_source_combinations_replayed=true", flush=True)

    selected_rows = []
    selected_columns = []
    pivot_records = []
    rational_minor = Rat3(1)
    actual_minor = E3(1)
    algebraic_unit = E3(1)
    for row_index, key, pivot, lead in first_factors:
        coordinate_index, scalar = scalar_rat3(lead.value)
        unit = lead.value / v81.scalar(scalar)
        assert constant_e_unit(unit)
        selected_rows.append(row_index)
        selected_columns.append(pivot)
        pivot_records.append(
            (row_index, key, pivot, lead, coordinate_index, scalar)
        )
        rational_minor *= scalar
        actual_minor *= lead.value
        algebraic_unit *= unit
    assert len(set(selected_rows)) == 38
    assert len(set(selected_columns)) == 38
    assert constant_e_unit(algebraic_unit)
    assert actual_minor == algebraic_unit * v81.scalar(rational_minor)

    # The selected row/column order is the pivot-introduction order.  Each
    # elimination step is a unit-lower row addition; hence the determinant of
    # this original 38x38 submatrix equals the recorded product of pivot leads.
    print("selected_minor_size=38x38")
    print("selected_minor_rows=" + ",".join(map(str, selected_rows)))
    print("selected_minor_columns=" + ",".join(map(str, selected_columns)))
    print("selected_minor_equals_pivot_product_by_unit_lower_elimination=true")
    print("selected_minor_E_unit_exact=" + v81.exact(algebraic_unit))
    print("selected_minor_E_unit_sha256=" + sha256(
        v81.exact(algebraic_unit).encode()
    ).hexdigest())

    pivot_path = outdir / "FIRST_PIVOT_LEDGER.tsv"
    pivot_sha = write_pivot_ledger(pivot_path, pivot_records)

    selected_denominator = allq.denominator_for(
        selected_first_values(first_rows, selected_rows, selected_columns)
    )
    full_denominator = allq.denominator_for(all_first_values(first_rows))
    assert selected_denominator and full_denominator
    assert not full_denominator % selected_denominator

    raw_numerator = rational_minor.numerator
    raw_denominator = rational_minor.denominator
    numerator = monic(raw_numerator)
    denominator = monic(raw_denominator)
    selected_denominator = monic(selected_denominator)
    full_denominator = monic(full_denominator)
    principal_open = monic(numerator * full_denominator)

    # Reduction and exact radical assertions.
    assert raw_numerator.gcd(raw_denominator).total_degree() == 0
    assert rational_minor == Rat3(raw_numerator, raw_denominator)
    licensed_product = monic(U * H * B3)
    licensed_factors = {
        str(factor): name
        for name, polynomial in (("U", U), ("H", H), ("B3", B3))
        for factor, _ in factor_records(polynomial)
    }
    assert licensed_factors

    named = (
        ("selected_minor", "zero", numerator),
        ("selected_minor", "pole", denominator),
        ("selected_entries", "pole", selected_denominator),
        ("full_first_matrix", "pole", full_denominator),
        ("rank38_principal_open", "inverted", principal_open),
    )
    factor_path = outdir / "FIRST_RANK_OPEN_FACTORS.tsv"
    factor_sha, debts = write_factor_ledger(
        factor_path, named, licensed_factors
    )
    debt_path = outdir / "RAW_FIBRE_SUCCESSORS.tsv"
    debt_sha = write_debt_ledger(debt_path, debts)

    # Negative controls catch silent replacement/omission of a pivot lead.
    nontrivial = next(
        scalar for *_, scalar in pivot_records
        if scalar != Rat3(1)
    )
    wrong_product = rational_minor / nontrivial
    assert wrong_product != rational_minor
    assert rational_minor + Rat3(1) != rational_minor
    assert len(selected_rows[:-1]) == 37

    print(f"first_pivot_ledger={pivot_path.name}")
    print(f"first_pivot_ledger_sha256={pivot_sha}")
    print("selected_minor_rational_sha256=" + sha256(
        repr((str(raw_numerator), str(raw_denominator))).encode()
    ).hexdigest())
    print(f"selected_minor_numerator=({numerator})")
    print(f"selected_minor_denominator=({denominator})")
    print(f"selected_minor_numerator_factor={numerator.factor()}")
    print(f"selected_minor_denominator_factor={denominator.factor()}")
    print(f"selected_entry_denominator_factor={selected_denominator.factor()}")
    print(f"full_first_matrix_denominator_factor={full_denominator.factor()}")
    print(f"licensed_chart_radical=({radical(licensed_product)})")
    print(f"rank38_principal_open_polynomial=({principal_open})")
    print(f"rank38_principal_open_radical=({radical(principal_open)})")
    print(f"rank38_principal_open_factor={principal_open.factor()}")
    print(f"rank38_factor_ledger={factor_path.name}")
    print(f"rank38_factor_ledger_sha256={factor_sha}")
    print(f"raw_fibre_successor_count={len(debts)}")
    print(f"raw_fibre_successor_ledger={debt_path.name}")
    print(f"raw_fibre_successor_ledger_sha256={debt_sha}")
    print("pivot_omission_negative_control=true")
    print("plus_one_negative_control=true")
    print("rank37_row_omission_control=true")
    print("principal_open_is_not_promoted_to_D_U_H_B3=true")
    print("rank_drop_fibres_require_raw_source_rebuild=true")
    print("K2_launched=false;awaiting_stage_A_Q_prev=true")
    print("TD6-A3-FIRST-RANK-OPEN-V83 PASS")


if __name__ == "__main__":
    main()
