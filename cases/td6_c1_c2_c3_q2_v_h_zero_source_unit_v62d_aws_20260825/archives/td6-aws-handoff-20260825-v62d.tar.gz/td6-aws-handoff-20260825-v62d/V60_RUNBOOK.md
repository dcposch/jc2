# TD6 V60 edge-only proof-DAG source-glue replay

V60 removes two redundant algebraic expansions from V57/V58 without weakening the
proof DAG.  Only current rows in the staged N13 left-null support are lifted
through current -> previous/pole -> first original rows.  Genuine P12 is an
original current row whose reviewed V43/V44 certificate reduces it directly
through the first rows, so V59 reproduces that exact first-stage source
relation rather than forcing P12 through the irrelevant previous stage.

V60 also keeps the current -> reduced-previous and reduced-previous ->
raw-previous/first edges separate.  It replays both edges exactly, and uses
exact substitution in the free equation module instead of expanding every
product of nested multipliers.  Every multiplier, selected row, and denominator
leaf is still emitted.

Modes:

- `generic`: reviewed center chart `D(U H B3)`;
- `h-zero`: raw `H=0` fraction-field factor-discovery chart;
- `b3-param`: raw birational `B3=0` fraction-field factor-discovery chart.

Every mode asserts exact old P12 base, beta-tail, N13, N13 multiplier,
nonzero-row count, multiplier-term count, and original-row source replay.
It also emits the complete N13 dependency DAG and every denominator leaf.

On an AWS host with the pinned TD6 environment:

```bash
sha256sum -c SOURCE.sha256
sha256sum -c V60_SOURCE.sha256
chmod +x run_v60.sh
TD6_PREFLIGHT_ONLY=1 TD6_OUTPUT_DIR=/tmp/v60-preflight ./run_v60.sh generic
TD6_PREFLIGHT_ONLY=1 TD6_OUTPUT_DIR=/tmp/v60-preflight ./run_v60.sh h-zero
TD6_PREFLIGHT_ONLY=1 TD6_OUTPUT_DIR=/tmp/v60-preflight ./run_v60.sh b3-param
TD6_OUTPUT_DIR=/path/to/output ./run_v60.sh generic
# or h-zero / b3-param
```

Success markers end in `FULL-SOURCE-GLUE-EDGE-DAG-V60 PASS` or
`FULL-SOURCE-GLUE-RAW-EDGE-DAG-V60 PASS`.  A raw PASS is only a source
identity over the selected raw fraction field.  Every emitted factor stratum
remains charged.  No whole raw stratum, fixed-A3 family, TD6, SP-2, or JC2
claim follows without the complete constructible cover.
