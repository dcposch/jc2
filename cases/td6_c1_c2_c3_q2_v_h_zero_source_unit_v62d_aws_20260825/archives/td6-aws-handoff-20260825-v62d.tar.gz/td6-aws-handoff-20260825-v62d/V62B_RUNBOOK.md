# V62B rational-edge previous-stage incompatibility

Exact scope: the fixed source-typed A3 q2-beta rational edge
`V=0, H=C-3U^2=0`, over `Q(U)`.  V62 observed rank 37 at the
previous/pole stage and two nonzero dependent residuals.  V62B forms their
exact polynomial Bezout combination, lifts every selected reduced previous
row through the original first rows, and replays a unit from original
post-transport rows.

The producer emits every source-certificate coefficient denominator.  It
claims only the complement of those factors; the separate `U=0` theorem is
not imported.  It does not use P12 or N13 and makes no full-A3, TD6, SP-2,
or JC2 claim.

Preflight:

```bash
TD6_PREFLIGHT_ONLY=1 ./run_v62b.sh v-h-zero
```

Full run:

```bash
TD6_OUTPUT_DIR=/absolute/output ./run_v62b.sh v-h-zero
```
