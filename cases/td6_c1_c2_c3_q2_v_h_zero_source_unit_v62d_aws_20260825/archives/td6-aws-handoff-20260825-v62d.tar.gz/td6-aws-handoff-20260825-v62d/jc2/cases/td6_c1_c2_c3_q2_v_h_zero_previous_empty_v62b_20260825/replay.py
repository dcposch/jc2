#!/usr/bin/env python3
"""Exact original-row incompatibility on the rational center edge V=H=0.

V62 discovered that the previous/pole stage has rank 37, not 38, and that
two dependent equations have nonzero right hand sides.  This successor does
not force the generic rank.  It forms the exact Bezout combination of those
dependencies, lifts every selected reduced previous row through the original
first rows, and replays a unit from the post-transport original source rows.

The conclusion is deliberately localized by every denominator appearing in
the source certificate.  No P12, N13, whole-A3, TD6, SP-2, or JC2 conclusion
is imported.
"""

from hashlib import sha256
import importlib.util
import os
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
PARENT_PATH = (
    HERE.parent
    / "td6_c1_c2_c3_q2_full_source_glue_rational_edge_dag_v62_20260825"
    / "replay.py"
)
PARENT_SHA256 = "1c888f0589fccbce12ae6870767928285ff83bbfbf8e1f7b19889a01ac1a9218"
assert sha256(PARENT_PATH.read_bytes()).hexdigest() == PARENT_SHA256

STRATUM_ARGUMENTS = [
    argument.split("=", 1)[1]
    for argument in sys.argv[1:]
    if argument.startswith("--stratum=")
]
assert STRATUM_ARGUMENTS == ["v-h-zero"]

spec = importlib.util.spec_from_file_location("td6_v62_parent", PARENT_PATH)
v62 = importlib.util.module_from_spec(spec)
assert spec.loader is not None
sys.modules[spec.name] = v62
spec.loader.exec_module(v62)

n, g, qd, nr = v62.n, v62.g, v62.qd, v62.nr
BetaPoly = v62.BetaPoly


def accumulate_scalar(target, index, value):
    value = BetaPoly.coerce(value)
    old = target.get(index, BetaPoly())
    new = old + value
    if new:
        target[index] = new
    else:
        target.pop(index, None)


def accumulate_polynomial(target, index, polynomial, scale=1):
    value = g.add(target[index], polynomial, scale)
    target[index] = value


def main():
    outdir = Path(os.environ.get("TD6_OUTPUT_DIR", ".")).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    print("producer=TD6-A3-Q2-V-H-ZERO-PREVIOUS-EMPTY-V62B")
    print(f"parent_v62_sha256={PARENT_SHA256}")
    print("beta_parameter_name=beta")
    print("q_beta=t+beta*t^2+t^25")
    print("raw_center_stratum=V=H=0_over_Q(U)")
    print("scope=post_transport_original_rows_on_function_field_of_rational_edge")
    print("generic_rank38_assumption_used=false")
    print("current_stage_used=false")
    print("P12_used=false")
    print("N13_used=false")
    print("raw_factor_cover_not_assumed=true", flush=True)

    bands132, pole_f132, pole_g132 = v62.build_transport_and_rows()
    n.configure_qd(direct_qprime=True)
    first_rows = qd.pack(
        "X-2",
        qd.first_band_polynomials(
            bands132[("f", 1)], bands132[("g", 1)]
        ),
    )
    first_pivots, forms94, free94, _, first_dependent = (
        v62.parameterize_with_pivots(132, first_rows, "first_v62b")
    )
    assert len(first_pivots) == 38
    assert len(free94) == 94
    assert not first_dependent
    map132_to_94 = {variable: index for index, variable in enumerate(free94)}
    map94_to_132 = {index: variable for index, variable in enumerate(free94)}

    bands94 = {
        key: n.compose(forms, forms94) for key, forms in bands132.items()
    }
    pole_f94 = n.compose(pole_f132, forms94)
    pole_g94 = n.compose(pole_g132, forms94)
    previous_rows = qd.pack(
        "X-1",
        qd.compile_previous(
            bands94[("f", 1)], bands94[("f", 2)],
            bands94[("g", 1)], bands94[("g", 2)],
        ),
    )
    previous_rows += qd.pack(
        "P1", qd.compile_pole_previous(pole_f94, pole_g94)
    )
    previous_pivots, _, _, previous_dependent = n.solve_stage(
        94, previous_rows, "previous_pole_v62b"
    )
    assert len(previous_pivots) == 37
    assert len(previous_dependent) == 2
    bad = [record for record in previous_dependent if record[2]]
    assert len(bad) == 2
    assert [record[1] for record in bad] == [("X-1", 11), ("X-1", 13)]
    print("previous_pole_actual_rank_accepted=37")
    print("previous_pole_nonzero_dependency_keys=[('X-1', 11), ('X-1', 13)]")

    residuals, gcd, bezout = n.polynomial_ideal_gcd(
        [record[2] for record in bad]
    )
    assert residuals == [record[2] for record in bad]
    bezout_replay = BetaPoly()
    for residual, weight in zip(residuals, bezout):
        bezout_replay += residual * weight
    assert bezout_replay == gcd
    assert gcd.degree == 0 and gcd
    print(f"previous_pole_compatibility_gcd_degree={gcd.degree}")
    print(f"previous_pole_compatibility_gcd_sha256={n.digest(gcd)}")
    print(f"previous_pole_compatibility_bezout_sha256={n.digest(tuple(bezout))}")
    print("previous_pole_reduced_bezout_exact=true", flush=True)

    # First combine the two exact reduced dependencies.  solve_stage records
    # sum combination_i * row_i = 0 and sum combination_i * rhs_i = residual,
    # hence the same combination of source polynomials row_i-rhs_i is
    # -residual.
    combined_reduced_weights = {}
    for (_, _, _, combination), outer_weight in zip(bad, bezout):
        for row_index, inner_weight in combination.items():
            accumulate_scalar(
                combined_reduced_weights,
                row_index,
                outer_weight * inner_weight,
            )
    reduced_replay = {}
    for row_index, weight in sorted(combined_reduced_weights.items()):
        reduced_replay = v62.add_scaled_product(
            reduced_replay,
            v62.scalar_polynomial(weight),
            v62.row_polynomial(previous_rows[row_index]),
        )
    assert reduced_replay == v62.scalar_polynomial(-gcd)
    normalizer = -gcd.inverse()
    normalized_weights = {
        row_index: weight * normalizer
        for row_index, weight in combined_reduced_weights.items()
        if weight * normalizer
    }
    normalized_reduced_replay = {}
    for row_index, weight in sorted(normalized_weights.items()):
        normalized_reduced_replay = v62.add_scaled_product(
            normalized_reduced_replay,
            v62.scalar_polynomial(weight),
            v62.row_polynomial(previous_rows[row_index]),
        )
    unit_polynomial = v62.scalar_polynomial(BetaPoly(1))
    assert normalized_reduced_replay == unit_polynomial

    # Rebuild every selected previous equation before the first-stage
    # substitution.  No linear packer touches these raw polynomials.
    raw_previous_rows = v62.source_records(
        "X-1",
        qd.compile_previous(
            bands132[("f", 1)], bands132[("f", 2)],
            bands132[("g", 1)], bands132[("g", 2)],
        ),
    )
    raw_previous_rows += v62.source_records(
        "P1", qd.compile_pole_previous(pole_f132, pole_g132)
    )
    raw_previous_index = {
        record[0]: index for index, record in enumerate(raw_previous_rows)
    }
    assert len(raw_previous_index) == len(raw_previous_rows)
    previous_reduced = {
        record[0]: v62.row_polynomial(record) for record in previous_rows
    }

    previous_first_relations = {}

    def lift_previous_key(key):
        if key in previous_first_relations:
            return previous_first_relations[key]
        raw_record = raw_previous_rows[raw_previous_index[key]]
        raw_polynomial = v62.row_polynomial(raw_record)
        remainder132, quotients = g.divide_polynomial(
            raw_polynomial, first_pivots
        )
        relation = g.lift_relations(quotients, first_pivots, len(first_rows))
        remainder94 = v62.remap_polynomial(remainder132, map132_to_94)
        assert g.clean(remainder94) == g.clean(previous_reduced[key])
        replay = v62.source_replay((relation,), (first_rows,))
        target = g.add(
            raw_polynomial,
            v62.remap_polynomial(remainder94, map94_to_132),
            -1,
        )
        assert replay == g.clean(target)
        previous_first_relations[key] = relation
        return relation

    first_multipliers = [{} for _ in first_rows]
    previous_multipliers = [{} for _ in raw_previous_rows]
    selected_contributions = []
    selected_keys = []
    for reduced_index, weight in sorted(normalized_weights.items()):
        key = previous_rows[reduced_index][0]
        selected_keys.append(key)
        raw_index = raw_previous_index[key]
        scalar = v62.scalar_polynomial(weight)
        accumulate_polynomial(previous_multipliers, raw_index, scalar)
        relation = lift_previous_key(key)
        edge_first = [{} for _ in first_rows]
        edge_previous = [{} for _ in raw_previous_rows]
        accumulate_polynomial(edge_previous, raw_index, scalar)
        for first_index, multiplier in enumerate(relation):
            if multiplier:
                accumulate_polynomial(
                    first_multipliers, first_index, multiplier, -weight
                )
                accumulate_polynomial(
                    edge_first, first_index, multiplier, -weight
                )
        contribution = v62.source_replay(
            (edge_first, edge_previous),
            (first_rows, raw_previous_rows),
        )
        assert contribution == g.scale_polynomial(
            previous_reduced[key], weight
        )
        if contribution:
            selected_contributions.append((key, contribution))

    full_source_replay = v62.source_replay(
        (first_multipliers, previous_multipliers),
        (first_rows, raw_previous_rows),
    )
    assert full_source_replay == unit_polynomial
    assert selected_contributions
    omitted_key, omitted_contribution = selected_contributions[0]
    assert g.add(full_source_replay, omitted_contribution, -1) != unit_polynomial
    wrong_sign_replay = v62.source_replay(
        (
            [g.scale_polynomial(value, -1) for value in first_multipliers],
            previous_multipliers,
        ),
        (first_rows, raw_previous_rows),
    )
    assert wrong_sign_replay != unit_polynomial

    selected_raw_degrees = [
        v62.total_degree(v62.row_polynomial(raw_previous_rows[index]))
        for index, multiplier in enumerate(previous_multipliers)
        if multiplier
    ]
    assert selected_raw_degrees
    print(f"source_selected_previous_key_count={len(set(selected_keys))}")
    print(f"source_selected_previous_keys={sorted(set(selected_keys))}")
    print(f"source_selected_previous_max_degree={max(selected_raw_degrees)}")
    print(f"source_first_multiplier_nonzero_count={sum(bool(x) for x in first_multipliers)}")
    print(f"source_previous_multiplier_nonzero_count={sum(bool(x) for x in previous_multipliers)}")
    print("arbitrary_degree_original_rows_preserved=true")
    print("previous_rows_lifted_through_original_first_rows=true")
    print("full_original_row_unit_certificate_exact=true")
    print(f"one_selected_source_edge_omission_key={omitted_key}")
    print("one_selected_source_edge_omission_negative_control=true")
    print("first_edge_wrong_sign_negative_control=true", flush=True)

    certificate = (
        ("schema", "TD6-A3-Q2-V-H-ZERO-PREVIOUS-EMPTY-SOURCE-v1"),
        ("parent_v62_sha256", PARENT_SHA256),
        ("reduced_bad_keys", tuple(record[1] for record in bad)),
        ("reduced_residuals", tuple(residuals)),
        ("reduced_bezout", tuple(bezout)),
        ("reduced_gcd", gcd),
        ("normalized_reduced_weights", normalized_weights),
        ("first_keys", tuple(record[0] for record in first_rows)),
        ("first_multipliers", tuple(first_multipliers)),
        ("raw_previous_keys", tuple(record[0] for record in raw_previous_rows)),
        ("raw_previous_multipliers", tuple(previous_multipliers)),
        ("target", full_source_replay),
    )
    certificate_text = repr(g.canonical(certificate)) + "\n"
    certificate_path = outdir / "PREVIOUS_INCOMPATIBILITY_SOURCE_CERTIFICATE.txt"
    certificate_path.write_text(certificate_text)
    print(f"source_certificate_path={certificate_path}")
    print(f"source_certificate_sha256={sha256(certificate_text.encode()).hexdigest()}")

    denominator_inputs = (
        ("normalizer", (normalizer,)),
        ("reduced_bezout", bezout),
        ("reduced_weights", normalized_weights.values()),
        ("first_multipliers", v62.relation_values(first_multipliers)),
        ("selected_first_rows", v62.selected_row_values(first_multipliers, first_rows)),
        ("previous_multipliers", v62.relation_values(previous_multipliers)),
        ("selected_raw_previous_rows", v62.selected_row_values(previous_multipliers, raw_previous_rows)),
    )
    ledger = v62.leaf_denominator_ledger(denominator_inputs)
    leaf_factors = sorted({
        factor
        for _, factors, _ in ledger.values()
        for factor, _ in factors
    })
    ledger_lines = [
        "denominator\tmultiplicity\tfirst_label\tfactorization",
        *(
            f"{denominator}\t{multiplicity}\t{label}\t{factorization}"
            for denominator, (label, factorization, multiplicity)
            in sorted(ledger.items())
        ),
    ]
    ledger_text = "\n".join(ledger_lines) + "\n"
    ledger_path = outdir / "SOURCE_UNIT_DENOMINATORS.tsv"
    ledger_path.write_text(ledger_text)
    print(f"source_denominator_ledger_path={ledger_path}")
    print(f"source_denominator_ledger_sha256={sha256(ledger_text.encode()).hexdigest()}")
    print(f"source_denominator_factor_set={leaf_factors}")
    print("source_denominator_all_factors_emitted=true")
    print("source_denominator_support_kind=coefficient_leaf_union")
    print("function_field_rational_edge_empty=true")
    print("raw_denominator_factor_strata_still_charged=true")
    print("whole_V_H_zero_edge_empty=false")
    print("full_A3_beta_family_killed=false")
    print("whole_TD6_killed=false")
    print("SP2_killed=false")
    print("JC2_resolved=false")
    print("TD6-A3-Q2-V-H-ZERO-PREVIOUS-EMPTY-V62B PASS")


if __name__ == "__main__":
    if os.environ.get("TD6_PREFLIGHT_ONLY") == "1":
        print("producer=TD6-A3-Q2-V-H-ZERO-PREVIOUS-EMPTY-V62B")
        print(f"parent_v62_sha256={PARENT_SHA256}")
        print("preflight_stratum=v-h-zero")
        print("recursive_import_and_source_pin_preflight=true")
        print("TD6-A3-Q2-V-H-ZERO-PREVIOUS-EMPTY-V62B PREFLIGHT PASS")
    else:
        main()
