#!/usr/bin/env python3
"""Exact rational-line proof-DAG composition of staged N13 with genuine P12.

The frozen V45 rational-line certificate reduces the genuine P12 against the
post-transport first rows on the selected raw chart and gives

    first_source + M*N13 = P12 - (-k/50).

The frozen V34/V47 producer computes N13 through first, previous/pole, and
current echelon stages, but its compact report does not compose those stages
back to the post-transport source rows.  This producer performs that missing
composition.  It uses exact sparse polynomial division by every normalized
affine pivot, replays each lifted row, and finally substitutes the resulting
source expression for N13 into the matching V45 identity.

V48 correctly reached the staged N13 identity but then used the linear-row
packer on the genuinely quadratic pre-first previous/current source rows.
V60 retains V59's dependency-closed exact reductions, but it does not expand
either nested source linear combination.  Instead it checks every edge
of a proof DAG.  Each current row in the N13 left-null support is reduced
through previous and first original rows with an exact replay.  The genuine
P12 row is deliberately reduced only through the first stage, exactly as in
V45: reducing it through the previous stage is mathematically unnecessary
and was the V57/V58 latency bottleneck.  The small staged left-null relation
is checked directly, while the frozen canonical V45 objects are pinned
and compared exactly.  Transitivity in the free module of equations gives the
same source identity without a potentially nonterminating normal-form
expansion.  This is a proof representation change, not an interpolation or
probabilistic shortcut.

Concretely, a current source row is replayed as first-row multiples plus
reduced previous-row multiples plus its 56-variable remainder.  Every reduced
previous row used by that edge is independently replayed as raw previous-row
and first-row multiples.  Exact substitution in the free equation module is
the certificate; nested polynomial multipliers are intentionally not expanded.

Scope is deliberately strict: the rational center line ``V=H=0`` is rebuilt
from source.  Every denominator factor remains charged; the separate direct
``U=0`` certificate is not silently imported as a whole-line conclusion.
"""

from hashlib import sha256
import importlib.util
import os
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
PARENT_PATH = (
    HERE.parent
    / "td6_c1_c2_c3_q2_full_p12_n13_unit_raw_rational_canonical_20260825"
    / "replay.py"
)
PARENT_SHA256 = "7e1370834460e2bc3123631825f04cb04a0b457a14449985635f3d0af86f8dd1"
STRATUM_ARGUMENTS = [
    argument.split("=", 1)[1]
    for argument in sys.argv[1:]
    if argument.startswith("--stratum=")
]
assert len(STRATUM_ARGUMENTS) == 1
STRATUM = STRATUM_ARGUMENTS[0]
assert STRATUM == "v-h-zero"
V45_STDOUT_PATH = HERE / "V45_V_H_ZERO.stdout"
V45_STDOUT_SHA256 = "61bb5fedba625711115ed7665a6ed23f37a54b0cff44356ecac0be717668ed4e"
assert sha256(PARENT_PATH.read_bytes()).hexdigest() == PARENT_SHA256
assert sha256(V45_STDOUT_PATH.read_bytes()).hexdigest() == V45_STDOUT_SHA256
V45_STDOUT = V45_STDOUT_PATH.read_text()
EXPECTED_P12 = (
    1465,
    "4a2ac92972cc64596cbc23829b35d40c11efbd72387d473aed0c7cd3544fe28d",
    "termwise_source_denominator_factor=(1, [(U, 3)])",
    1528,
)
for marker in (
    f"raw_P12_base_sha256={EXPECTED_P12[1]}",
    "full_beta_first_original_row_replay=true",
    "P12_N13_polynomial_unit_identity_exact=true",
    "combined_unit_residual_is_minus_k_over_50=true",
    EXPECTED_P12[2],
    "every_emitted_raw_denominator_divisor_still_charged=true",
    "TD6-A3-Q2-FULL-P12-N13-UNIT-RATIONAL-RAW-CANONICAL PASS",
):
    assert marker in V45_STDOUT, marker
spec = importlib.util.spec_from_file_location("td6_v48_p12_parent", PARENT_PATH)
g = importlib.util.module_from_spec(spec)
assert spec.loader is not None
sys.modules[spec.name] = g
spec.loader.exec_module(g)

assert sys.argv[1:] == [f"--stratum={STRATUM}"]
n, r, tri, b = g.n, g.r, g.tri, g.b
Rat3, E3, BetaPoly = g.Rat3, g.E3, g.BetaPoly
C, V, U, H, B3 = g.C, g.V, g.U, g.H, g.B3
qd, nr = g.qd, g.nr


def row_polynomial(record):
    if len(record) == 2:
        return record[1]
    _, row, rhs = record
    return n.source_polynomial(row, rhs)


def source_records(family, polynomials):
    """Keep arbitrary-degree original equations, including exact zero rows."""
    return [
        ((family, degree), g.clean(polynomial))
        for degree, polynomial in enumerate(polynomials)
    ]


def total_degree(polynomial):
    return max((len(monomial) for monomial in polynomial), default=-1)


def remap_polynomial(polynomial, variable_map):
    """Rename variables through an injective integer map."""
    out = {}
    for monomial, coefficient in polynomial.items():
        mapped = tuple(sorted(variable_map[variable] for variable in monomial))
        value = out.get(mapped, BetaPoly()) + coefficient
        if value:
            out[mapped] = value
        else:
            out.pop(mapped, None)
    return out


def scalar_polynomial(value):
    value = BetaPoly.coerce(value)
    return {(): value} if value else {}


def add_scaled_product(target, left, right, scale=1):
    return g.add(target, g.multiply(left, right), scale)


def add_multiplier(target, index, polynomial, scale=1):
    value = g.add(target[index], polynomial, scale)
    target[index] = value


def source_replay(multiplier_families, row_families):
    replay = {}
    for multipliers, rows in zip(multiplier_families, row_families):
        assert len(multipliers) == len(rows)
        for multiplier, row in zip(multipliers, rows):
            if multiplier:
                replay = add_scaled_product(replay, multiplier, row_polynomial(row))
    return g.clean(replay)


def parameterize_with_pivots(nvariables, rows, stage):
    pivots, _, factors, dependent = n.solve_stage(nvariables, rows, stage)
    assert all(not rhs for _, _, rhs, _ in dependent), (stage, dependent)
    free = [variable for variable in range(nvariables) if variable not in pivots]
    parameter_of = {variable: index for index, variable in enumerate(free)}
    forms = [None] * nvariables
    for variable in range(nvariables - 1, -1, -1):
        if variable in parameter_of:
            forms[variable] = (
                BetaPoly(), {parameter_of[variable]: BetaPoly(1)}
            )
            continue
        row, rhs, _ = pivots[variable]
        form = (rhs, {})
        for other, coefficient in row.items():
            if other == variable:
                continue
            assert other > variable and forms[other] is not None
            form = nr.add_affine(form, forms[other], -coefficient)
        forms[variable] = form
    for key, row, rhs in rows:
        got = (BetaPoly(), {})
        for variable, coefficient in row.items():
            got = nr.add_affine(got, forms[variable], coefficient)
        assert got == (BetaPoly.coerce(rhs), {}), (stage, key, got, rhs)
    print(f"{stage}_affine_parameterization_replay=true", flush=True)
    return pivots, forms, free, factors, dependent


def factor_strings(polynomial):
    if not polynomial or polynomial.total_degree() == 0:
        return []
    unit, factors = polynomial.factor()
    assert unit
    return sorted((str(factor), exponent) for factor, exponent in factors)


def write_denominator(outdir, label, polynomial):
    text = str(polynomial) + "\n"
    factor_text = "\n".join(
        f"{exponent}\t{factor}" for factor, exponent in factor_strings(polynomial)
    ) + "\n"
    polynomial_path = outdir / f"{label}.txt"
    factors_path = outdir / f"{label}.factors.txt"
    polynomial_path.write_text(text)
    factors_path.write_text(factor_text)
    print(f"{label}_path={polynomial_path}")
    print(f"{label}_sha256={sha256(text.encode()).hexdigest()}")
    print(f"{label}_summary={tri.polynomial_summary(polynomial)}")
    print(f"{label}_factor_count={len(factor_strings(polynomial))}")
    print(f"{label}_factors_sha256={sha256(factor_text.encode()).hexdigest()}")


def beta_values(polynomial_families):
    for family in polynomial_families:
        for polynomial in family:
            yield from polynomial.values()


def termwise_values(multiplier_families, row_families):
    slots = 0
    values = []
    for multipliers, rows in zip(multiplier_families, row_families):
        for multiplier, row in zip(multipliers, rows):
            source = row_polynomial(row)
            for left in multiplier.values():
                for right in source.values():
                    values.append(left * right)
                    slots += 1
    return values, slots


def denominators_divide_beta(value, common):
    value = BetaPoly.coerce(value)
    for coefficient in value.coefficients:
        for coordinate in tri.e3_rat3_coordinates(coefficient):
            if common % coordinate.denominator:
                return False
    return True


def coordinate_denominators(values):
    """Yield every exact center-ring denominator at a proof-DAG leaf."""
    for value in values:
        value = BetaPoly.coerce(value)
        for coefficient in value.coefficients:
            for coordinate in tri.e3_rat3_coordinates(coefficient):
                yield coordinate.denominator


def relation_values(relations):
    for relation in relations:
        yield from relation.values()


def selected_row_values(relations, rows):
    for relation, row in zip(relations, rows):
        if relation:
            yield from row_polynomial(row).values()


def leaf_denominator_ledger(named_values):
    """Emit exact raw-stratum denominator support without assuming a cover."""
    ledger = {}
    for label, values in named_values:
        for denominator in coordinate_denominators(values):
            key = str(denominator)
            if key not in ledger:
                ledger[key] = [label, factor_strings(denominator), 0]
            ledger[key][2] += 1
    return ledger


def build_transport_and_rows():
    center_c, center_v, center_u, center_label = tri.center_coordinates()
    assert STRATUM == n.STRATUM
    assert not center_v and not (center_c - 3*center_u**2)
    print(f"source_center={center_label}")
    print(f"raw_center_stratum={STRATUM}")
    r.fb.CENTER = (center_c, center_v, center_u)
    r.fb._X_POWER_CACHE.clear()
    nf, rows_f = r.fb.build_transport(
        15, 60, 3, {15: r.b.Q(1)},
        r.fb.F1_F_PATTERN, r.fb.POLE_F_PATTERN,
    )
    ng, rows_g = r.fb.build_transport(
        25, 100, 5, {1: r.b.Q(1), 25: r.b.Q(1)},
        r.fb.F1_G_PATTERN, r.fb.POLE_G_PATTERN,
    )
    transport = [(('f',) + key, row, rhs) for key, row, rhs in rows_f]
    transport += [
        (
            ('g',) + key,
            {nf + variable: coefficient for variable, coefficient in row.items()},
            rhs,
        )
        for key, row, rhs in rows_g
    ]
    ordered = [row for row in transport if row[0][1] != 'X'] + [
        row for row in transport if row[0][1] == 'X'
    ]
    transport_pivots, records, events, _ = tri.factor_transport(ordered)
    pivot_rhs_dual, compatibility = b.propagate_beta(ordered, records)
    assert not compatibility and len(transport_pivots) == 3470
    free = [
        variable for variable in range(nf + ng)
        if variable not in transport_pivots
    ]
    assert len(free) == 132
    free_parameter = {variable: index for index, variable in enumerate(free)}

    def restrict(row):
        return n.convert_form(b.restrict_row_beta(
            row, transport_pivots, pivot_rhs_dual, free_parameter
        ))

    bands132 = {}
    for owner, imax, jmax, offset in (
        ('f', 15, 60, 0), ('g', 25, 100, nf)
    ):
        for exponent in (1, 2, 3):
            forms = []
            for degree in range(16 if owner == 'f' else 26):
                row = {
                    offset + variable: coefficient
                    for variable, coefficient in r.fb.x_chart_coefficient(
                        imax, jmax, exponent, degree
                    ).items()
                }
                forms.append(restrict(row))
            bands132[(owner, exponent)] = forms

    pole_f132 = []
    for degree in range(61):
        row = {
            variable: Rat3.coerce(coefficient)
            for variable, coefficient in nr.pole_coefficient(
                15, 60, -2, degree
            ).items()
        }
        pole_f132.append(restrict(row))
    pole_g132 = []
    for degree in range(101):
        row = {
            nf + variable: Rat3.coerce(coefficient)
            for variable, coefficient in nr.pole_coefficient(
                25, 100, -4, degree
            ).items()
        }
        pole_g132.append(restrict(row))
    print(f"transport_rank={len(transport_pivots)}/{nf+ng}")
    print(f"transport_event_count={len(events)}")
    print("transport_matrix_beta_independent=true")
    print("transport_rhs_beta_affine_exact=true")
    print("transport_x_and_pole_sections_exact=true", flush=True)
    return bands132, pole_f132, pole_g132


def main():
    outdir = Path(os.environ.get("TD6_OUTPUT_DIR", ".")).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    print("producer=TD6-A3-Q2-FULL-SOURCE-GLUE-RATIONAL-EDGE-DAG-V62")
    print("V48_failure_class=linear_packer_rejected_genuine_quadratic_source_rows")
    print("arbitrary_degree_original_rows_preserved=true")
    print("dependency_closed_proof_DAG=true")
    print("final_global_polynomial_expansion_used=false")
    print("full_unused_row_audit_deferred_to_V50=true")
    print("beta_parameter_name=beta")
    print("q_beta=t+beta*t^2+t^25")
    print("q_beta_prime=1+2*beta*t+25*t^24")
    print("scope=post_transport_132_variable_raw_stratum_source_rows")
    print(f"transport_chart=fraction_field_of_{STRATUM}")
    print("multivariate_gcd_used_as_bezout=false")
    print("raw_factor_cover_not_assumed=true")
    print(f"parent_sha256={PARENT_SHA256}", flush=True)
    print(f"V45_rational_canonical_stdout_sha256={V45_STDOUT_SHA256}")
    print("V45_rational_P12_source_dependency_markers_verified=true", flush=True)

    bands132, pole_f132, pole_g132 = build_transport_and_rows()
    n.configure_qd(direct_qprime=True)
    first_rows = qd.pack(
        'X-2', qd.first_band_polynomials(
            bands132[('f', 1)], bands132[('g', 1)]
        )
    )
    first_pivots, forms94, free94, first_factors, first_dependent = (
        parameterize_with_pivots(132, first_rows, "first_v50")
    )
    assert len(first_pivots) == 38 and len(free94) == 94
    map132_to_94 = {variable: index for index, variable in enumerate(free94)}
    map94_to_132 = {index: variable for index, variable in enumerate(free94)}

    bands94 = {key: n.compose(forms, forms94) for key, forms in bands132.items()}
    pole_f94 = n.compose(pole_f132, forms94)
    pole_g94 = n.compose(pole_g132, forms94)
    previous_rows = qd.pack(
        'X-1', qd.compile_previous(
            bands94[('f', 1)], bands94[('f', 2)],
            bands94[('g', 1)], bands94[('g', 2)],
        )
    )
    previous_rows += qd.pack(
        'P1', qd.compile_pole_previous(pole_f94, pole_g94)
    )
    previous_pivots, forms56, free56, previous_factors, previous_dependent = (
        parameterize_with_pivots(94, previous_rows, "previous_pole_v50")
    )
    assert len(previous_pivots) == 38 and len(free56) == 56
    map94_to_56 = {variable: index for index, variable in enumerate(free56)}
    map56_to_94 = {index: variable for index, variable in enumerate(free56)}
    map56_to_132 = {
        index: free94[variable] for index, variable in enumerate(free56)
    }

    bands56 = {key: n.compose(forms, forms56) for key, forms in bands94.items()}
    current_rows = qd.pack('X0', qd.compile_current(
        *[bands56[('f', exponent)] for exponent in (1, 2, 3)],
        *[bands56[('g', exponent)] for exponent in (1, 2, 3)],
    ))
    current_pivots, _, current_factors, current_dependent = n.solve_stage(
        56, current_rows, "current_v50"
    )
    assert len(current_pivots) == 25
    n13_records = [
        record for record in current_dependent
        if record[1] == ('X0', 13) and record[2]
    ]
    assert len(n13_records) == 1
    _, _, n13, n13_weights = n13_records[0]
    S = E3(qd.uniform.S_FIELD)
    k = E3(252) - 342*S + 144*S**2 - 36*S**3
    expected_n13 = BetaPoly([0, k/25])
    assert n13 == expected_n13 and k * k.inverse() == E3(1)
    print(f"N13_equals_k_beta_over_25={str(n13 == expected_n13).lower()}")
    print(f"N13_left_null_support={len(n13_weights)}")
    print(f"N13_left_null_sha256={n.digest(tuple(sorted(n13_weights.items())))}")
    print(f"k_inverse_sha256={n.digest(k.inverse())}", flush=True)

    raw_previous_rows = source_records(
        'X-1', qd.compile_previous(
            bands132[('f', 1)], bands132[('f', 2)],
            bands132[('g', 1)], bands132[('g', 2)],
        )
    )
    raw_previous_rows += source_records(
        'P1', qd.compile_pole_previous(pole_f132, pole_g132)
    )
    raw_previous_index = {
        record[0]: index for index, record in enumerate(raw_previous_rows)
    }
    assert len(raw_previous_index) == len(raw_previous_rows)
    previous_reduced = {
        record[0]: row_polynomial(record) for record in previous_rows
    }
    assert set(previous_reduced) <= set(raw_previous_index)

    previous_first_relations_by_key = {}

    def lift_previous_key(key):
        if key in previous_first_relations_by_key:
            return previous_first_relations_by_key[key]
        raw_record = raw_previous_rows[raw_previous_index[key]]
        raw_polynomial = row_polynomial(raw_record)
        remainder132, quotients = g.divide_polynomial(raw_polynomial, first_pivots)
        relation = g.lift_relations(quotients, first_pivots, len(first_rows))
        remainder94 = remap_polynomial(remainder132, map132_to_94)
        expected = previous_reduced.get(key, {})
        assert g.clean(remainder94) == g.clean(expected), (
            "previous exact source reduction", key,
            g.clean(remainder94), g.clean(expected),
        )
        replay = source_replay((relation,), (first_rows,))
        target = g.add(raw_polynomial, remap_polynomial(remainder94, map94_to_132), -1)
        assert replay == g.clean(target)
        previous_first_relations_by_key[key] = relation
        return relation

    quadratic_previous = [
        record for record in raw_previous_rows
        if total_degree(row_polynomial(record)) == 2
    ]
    assert quadratic_previous
    quadratic_key = quadratic_previous[0][0]
    quadratic_relation = lift_previous_key(quadratic_key)
    quadratic_raw = row_polynomial(quadratic_previous[0])
    quadratic_remainder, _ = g.divide_polynomial(quadratic_raw, first_pivots)
    assert source_replay((quadratic_relation,), (first_rows,)) == g.clean(
        g.add(quadratic_raw, quadratic_remainder, -1)
    )
    print(f"previous_raw_row_count_available={len(raw_previous_rows)}")
    print(f"previous_raw_quadratic_row_count={len(quadratic_previous)}")
    print(f"quadratic_source_positive_control_key={quadratic_key}")
    print("quadratic_source_positive_control_exact=true")
    print("dependency_selected_previous_rows_reduced_exactly=true", flush=True)

    raw_current_rows = source_records('X0', qd.compile_current(
        *[bands132[('f', exponent)] for exponent in (1, 2, 3)],
        *[bands132[('g', exponent)] for exponent in (1, 2, 3)],
    ))
    raw_current_index = {
        record[0]: index for index, record in enumerate(raw_current_rows)
    }
    assert len(raw_current_index) == len(raw_current_rows)
    current_reduced = {
        record[0]: row_polynomial(record) for record in current_rows
    }
    assert set(current_reduced) <= set(raw_current_index)
    current_stage_index = {
        record[0]: index for index, record in enumerate(current_rows)
    }

    current_lift_cache = {}

    def lift_current_key(key):
        if key in current_lift_cache:
            return current_lift_cache[key]
        raw_polynomial = row_polynomial(raw_current_rows[raw_current_index[key]])
        remainder132, first_quotients = g.divide_polynomial(
            raw_polynomial, first_pivots
        )
        first_only_relation = g.lift_relations(
            first_quotients, first_pivots, len(first_rows)
        )
        remainder94 = remap_polynomial(remainder132, map132_to_94)
        remainder94_after, previous_quotients = g.divide_polynomial(
            remainder94, previous_pivots
        )
        previous_relation94 = g.lift_relations(
            previous_quotients, previous_pivots, len(previous_rows)
        )
        remainder56 = remap_polynomial(remainder94_after, map94_to_56)
        expected = current_reduced.get(key, {})
        assert g.clean(remainder56) == g.clean(expected), (
            "current exact source reduction", key,
            g.clean(remainder56), g.clean(expected),
        )

        first_replay = source_replay((first_only_relation,), (first_rows,))
        embedded94_in_132 = remap_polynomial(remainder94, map94_to_132)
        assert first_replay == g.clean(
            g.add(raw_polynomial, embedded94_in_132, -1)
        )
        previous_replay = source_replay(
            (previous_relation94,), (previous_rows,)
        )
        embedded56_in_94 = remap_polynomial(remainder56, map56_to_94)
        assert previous_replay == g.clean(
            g.add(remainder94, embedded56_in_94, -1)
        )
        for previous_index, polynomial in enumerate(previous_relation94):
            if not polynomial:
                continue
            previous_key = previous_rows[previous_index][0]
            lift_previous_key(previous_key)
        record = (
            raw_polynomial, remainder94, remainder56,
            first_only_relation, previous_relation94,
        )
        current_lift_cache[key] = record
        return record

    def lift_current(row_index):
        return lift_current_key(current_rows[row_index][0])

    # Only N13-support rows need the full current -> previous -> first lift.
    # P12's reviewed V44 identity is a direct first-stage certificate.
    required_current = sorted(set(n13_weights))
    for row_index in required_current:
        lift_current(row_index)
    print(f"current_rows_source_lifted={len(required_current)}")
    print(f"current_rows_source_lifted_indices={required_current}")
    print(
        f"previous_rows_source_lifted={len(previous_first_relations_by_key)}"
    )
    print(
        "previous_rows_source_lifted_keys="
        f"{sorted(previous_first_relations_by_key)}"
    )
    print("dependency_closed_original_rows_reduced_exactly=true")
    print("current_through_previous_and_first_source_replay=true", flush=True)

    # The staged left-null row is tiny.  Check it directly in the reduced
    # 56-variable module, then cite the already replayed lift of every row in
    # its support.  This proves the same transitive source identity as V53's
    # giant expansion.
    staged_n13_left = {}
    staged_without_one = {}
    omitted_index = min(n13_weights)
    dag_lines = [
        "schema=TD6-A3-Q2-N13-RAW-PROOF-DAG-v2",
        f"raw_center_stratum={STRATUM}",
        f"parent_source_sha256={PARENT_SHA256}",
        f"v45_rational_stdout_sha256={V45_STDOUT_SHA256}",
    ]
    denominator_inputs = []
    for row_index, weight in sorted(n13_weights.items()):
        key = current_rows[row_index][0]
        (
            raw_polynomial, remainder94, remainder56,
            first_only_relation, previous_relation94,
        ) = lift_current(row_index)
        reduced = current_reduced[key]
        assert g.clean(remainder56) == g.clean(reduced)
        staged_n13_left = g.add(staged_n13_left, reduced, weight)
        if row_index != omitted_index:
            staged_without_one = g.add(staged_without_one, reduced, weight)
        dag_lines.extend((
            f"current_row_index={row_index}",
            f"current_row_key={key}",
            f"weight_sha256={g.canonical_digest(weight)}",
            f"raw_current_sha256={g.canonical_digest(raw_polynomial)}",
            f"remainder94_sha256={g.canonical_digest(remainder94)}",
            f"remainder56_sha256={g.canonical_digest(remainder56)}",
            f"first_only_relation_sha256={g.canonical_digest(first_only_relation)}",
            f"previous_reduced_relation_sha256={g.canonical_digest(previous_relation94)}",
            f"first_only_nonzero_rows={sum(bool(value) for value in first_only_relation)}",
            f"previous_reduced_nonzero_rows={sum(bool(value) for value in previous_relation94)}",
        ))
        denominator_inputs.extend((
            (f"current_{row_index}_weight", (weight,)),
            (f"current_{row_index}_first_only_multipliers", relation_values(first_only_relation)),
            (f"current_{row_index}_first_rows", selected_row_values(first_only_relation, first_rows)),
            (f"current_{row_index}_previous_reduced_multipliers", relation_values(previous_relation94)),
            (f"current_{row_index}_previous_reduced_rows", selected_row_values(previous_relation94, previous_rows)),
            (f"current_{row_index}_raw_row", raw_polynomial.values()),
            (f"current_{row_index}_reduced_row", reduced.values()),
        ))

    for previous_key, relation in sorted(previous_first_relations_by_key.items()):
        raw_previous = row_polynomial(
            raw_previous_rows[raw_previous_index[previous_key]]
        )
        reduced_previous = previous_reduced[previous_key]
        dag_lines.extend((
            f"previous_edge_key={previous_key}",
            f"previous_edge_relation_sha256={g.canonical_digest(relation)}",
            f"previous_edge_raw_sha256={g.canonical_digest(raw_previous)}",
            f"previous_edge_reduced_sha256={g.canonical_digest(reduced_previous)}",
            f"previous_edge_nonzero_first_rows={sum(bool(value) for value in relation)}",
        ))
        denominator_inputs.extend((
            (f"previous_{previous_key}_first_multipliers", relation_values(relation)),
            (f"previous_{previous_key}_first_rows", selected_row_values(relation, first_rows)),
            (f"previous_{previous_key}_raw_row", raw_previous.values()),
            (f"previous_{previous_key}_reduced_row", reduced_previous.values()),
        ))

    assert staged_n13_left == {(): -n13}
    assert staged_without_one != {(): -n13}
    dag_lines.extend((
        f"staged_left_sha256={g.canonical_digest(staged_n13_left)}",
        f"staged_target_sha256={g.canonical_digest({(): -n13})}",
        f"omitted_row_index={omitted_index}",
        "each_current_edge_original_row_replay=true",
        "each_selected_previous_edge_original_row_replay=true",
        "staged_left_null_relation_exact=true",
        "proof_rule=exact_edge_substitution_in_free_equation_module",
    ))
    print("N13_staged_left_null_relation_exact=true")
    print("N13_each_dependency_edge_original_row_replay=true")
    print("N13_nested_multiplier_expansion_used=false")
    print("N13_one_required_edge_omission_negative_control=true")
    print("N13_full_first_previous_current_source_identity_exact_by_DAG=true", flush=True)

    # Recompute V44's genuine raw P12 first-stage source certificate directly.
    # This avoids the redundant previous-stage reduction of row 12 while
    # retaining an exact original-row replay and exact equality with all
    # comparable V44 objects.
    p12_key = ('X0', 12)
    p12_raw = row_polynomial(raw_current_rows[raw_current_index[p12_key]])
    p12_remainder132, p12_first_quotients = g.divide_polynomial(
        p12_raw, first_pivots
    )
    p12_first_relation = g.lift_relations(
        p12_first_quotients, first_pivots, len(first_rows)
    )
    p12_first_source = source_replay((p12_first_relation,), (first_rows,))
    assert p12_first_source == g.clean(
        g.add(p12_raw, p12_remainder132, -1)
    )
    raw_base = g.projection(p12_raw, 0)
    assert len(raw_base) == EXPECTED_P12[0]
    assert g.polynomial_digest(raw_base) == EXPECTED_P12[1]
    unit = -k/50
    assert len(p12_remainder132) == 3
    assert g.projection(p12_remainder132, 0) == {(): unit}
    tail132 = g.beta_tail(p12_remainder132, unit)
    assert len(tail132) == 2
    assert n.digest(tail132) == (
        "0639f8cdff06649312811c4995f3c4a9ea087b8ff60236ebb9353da532afb531"
    )
    n13_multiplier = g.scale_polynomial(tail132, E3(25)/k)
    assert n13_multiplier
    assert n.digest(n13) == (
        "8cf947c9ba6cd70388827bb7db564d0675d94eee621bc54efc2b791aff88b26f"
    )
    assert n.digest(n13_multiplier) == (
        "aef2b851a14ef65063f60ce1e199e0257c9d5c1a1865950cc7315f0d458a99d6"
    )
    assert sum(bool(relation) for relation in p12_first_relation) == 28
    assert sum(len(relation) for relation in p12_first_relation) == EXPECTED_P12[3]
    assert g.scale_polynomial(n13_multiplier, n13) == g.scale_polynomial(
        tail132, BetaPoly.beta()
    )
    assert g.scale_polynomial(n13_multiplier, BetaPoly()) != g.scale_polynomial(
        tail132, BetaPoly.beta()
    )
    p12_termwise_denominator = U**3
    p12_termwise_inverse = BetaPoly(E3(Rat3(1, p12_termwise_denominator)))
    denominator_inputs.extend((
        ("N13_scalar", (n13,)),
        ("P12_unit", (unit,)),
        ("P12_raw", p12_raw.values()),
        ("P12_first_remainder", p12_remainder132.values()),
        ("P12_first_multipliers", relation_values(p12_first_relation)),
        ("P12_first_rows", selected_row_values(p12_first_relation, first_rows)),
        ("P12_beta_tail", tail132.values()),
        ("N13_multiplier", n13_multiplier.values()),
        ("V45_P12_termwise_clear", (p12_termwise_inverse,)),
    ))
    dag_lines.extend((
        f"raw_P12_base_sha256={g.polynomial_digest(raw_base)}",
        f"P12_first_remainder_sha256={g.canonical_digest(p12_remainder132)}",
        f"P12_first_relation_sha256={g.canonical_digest(p12_first_relation)}",
        f"P12_first_source_sha256={g.canonical_digest(p12_first_source)}",
        f"P12_beta_tail_sha256={n.digest(tail132)}",
        f"N13_multiplier_sha256={n.digest(n13_multiplier)}",
        f"unit_sha256={g.canonical_digest(unit)}",
        "P12_source_edge=V45_RATIONAL_CANONICAL.stdout",
        "P12_first_original_row_replay=true",
        "P12_old_tail_and_multiplier_objects_exactly_equal=true",
        "P12_minus_multiplier_times_N13_equals_minus_k_over_50=true",
    ))
    print(f"genuine_P12_term_count_control={EXPECTED_P12[0]}")
    print("P12_first_original_row_replay=true")
    print("P12_first_nonzero_rows=28")
    print(f"P12_first_multiplier_terms={EXPECTED_P12[3]}")
    print("P12_old_tail_and_multiplier_objects_exactly_equal=true")
    print("P12_previous_stage_reduction_required=false")
    print("V45_full_beta_first_original_row_replay_pinned=true")
    print("P12_N13_scalar_glue_exact=true")
    print("P12_without_N13_negative_control=true")
    print("combined_unit_residual_is_minus_k_over_50=true", flush=True)

    ledger = leaf_denominator_ledger(denominator_inputs)
    leaf_factors = sorted({
        factor
        for _, factors, _ in ledger.values()
        for factor, _ in factors
    })
    dag_lines.extend((
        f"v45_termwise_denominator={p12_termwise_denominator}",
        "factored_clear_scalar=V45_termwise_denominator*product(leaf_denominator^multiplicity)",
        "factored_clear_scalar_expansion_required=false",
        f"raw_leaf_factor_set={leaf_factors}",
    ))
    ledger_lines = [
        "denominator\tmultiplicity\tfirst_label\tfactorization",
        *(
            f"{denominator}\t{multiplicity}\t{label}\t{factorization}"
            for denominator, (label, factorization, multiplicity)
            in sorted(ledger.items())
        ),
    ]
    ledger_text = "\n".join(ledger_lines) + "\n"
    ledger_path = outdir / "DAG_LEAF_DENOMINATORS.tsv"
    ledger_path.write_text(ledger_text)
    dag_text = "\n".join(dag_lines) + "\n"
    dag_path = outdir / "N13_PROOF_DAG.txt"
    dag_path.write_text(dag_text)
    print(f"DAG_leaf_denominator_count={len(ledger)}")
    print(f"DAG_leaf_denominator_ledger_path={ledger_path}")
    print(f"DAG_leaf_denominator_ledger_sha256={sha256(ledger_text.encode()).hexdigest()}")
    print(f"N13_proof_DAG_path={dag_path}")
    print(f"N13_proof_DAG_sha256={sha256(dag_text.encode()).hexdigest()}")
    print(f"DAG_leaf_denominator_factor_set={leaf_factors}")
    print("DAG_leaf_denominator_all_factors_emitted=true")
    print("DAG_factored_clearing_certificate_explicit=true")
    print("V45_termwise_clearing_dependency_exact=true")
    print("raw_stratum_fraction_field_source_identity_exact=true")
    print("raw_denominator_factor_strata_still_charged=true")
    print("whole_raw_stratum_killed=false")
    print("full_A3_beta_family_killed=false")
    print("whole_TD6_killed=false")
    print("SP2_killed=false")
    print("JC2_resolved=false")
    print("zero_weight_original_rows_not_needed_by_dependency_DAG=true")
    print("full_unused_previous_current_row_audit_complete=false")
    print("V55_V56_full_row_audit_is_independent_cross_check=true")
    print("TD6-A3-Q2-FULL-SOURCE-GLUE-RATIONAL-EDGE-DAG-V62 PASS")


if __name__ == "__main__":
    if os.environ.get("TD6_PREFLIGHT_ONLY") == "1":
        print("producer=TD6-A3-Q2-FULL-SOURCE-GLUE-RATIONAL-EDGE-DAG-V62")
        print(f"preflight_stratum={STRATUM}")
        print(f"parent_sha256={PARENT_SHA256}")
        print(f"V45_rational_canonical_stdout_sha256={V45_STDOUT_SHA256}")
        print("recursive_import_and_pinned_evidence_preflight=true")
        print("fast_DAG_skips_previous_stage_for_genuine_P12=true")
        print("nested_previous_first_multiplier_expansion_used=false")
        print("TD6-A3-Q2-FULL-SOURCE-GLUE-RATIONAL-EDGE-DAG-V62 PREFLIGHT PASS")
    else:
        main()
