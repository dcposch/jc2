#!/usr/bin/env python3
"""One-division original-row unit witness on V=H=0.

This is an independent representation of V62B's previous-stage
incompatibility.  The two reduced dependencies are first combined by their
exact E(Q(U))[beta] Bezout weights.  Their matching *raw* previous equations
are then combined before any nonlinear reduction, and that single polynomial
is divided by the original first pivots.  A remainder equal to 1 gives a
direct original-row unit certificate without lifting the selected previous
rows one at a time.
"""

from hashlib import sha256
import importlib.util
import os
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
PARENT_PATH = (
    HERE.parent
    / "td6_c1_c2_c3_q2_full_source_glue_rational_edge_dag_v62_20260825"
    / "replay.py"
)
PARENT_SHA256 = "1c888f0589fccbce12ae6870767928285ff83bbfbf8e1f7b19889a01ac1a9218"
assert sha256(PARENT_PATH.read_bytes()).hexdigest() == PARENT_SHA256
assert [
    argument for argument in sys.argv[1:] if argument.startswith("--stratum=")
] == ["--stratum=v-h-zero"]

spec = importlib.util.spec_from_file_location("td6_v62_parent_for_v62d", PARENT_PATH)
v62 = importlib.util.module_from_spec(spec)
assert spec.loader is not None
sys.modules[spec.name] = v62
spec.loader.exec_module(v62)

n, g, qd = v62.n, v62.g, v62.qd
BetaPoly = v62.BetaPoly


def add_scalar(target, index, value):
    value = BetaPoly.coerce(value)
    updated = target.get(index, BetaPoly()) + value
    if updated:
        target[index] = updated
    else:
        target.pop(index, None)


def pivot_values(pivots):
    """Every coefficient in a normalized pivot and its source ancestry."""
    for pivot in sorted(pivots):
        row, rhs, combination = pivots[pivot]
        yield from row.values()
        yield rhs
        yield from combination.values()


def pivot_lead_values(factors):
    for _, _, _, lead in factors:
        yield lead


def main():
    outdir = Path(os.environ.get("TD6_OUTPUT_DIR", ".")).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    print("producer=TD6-A3-Q2-V-H-ZERO-COMBINED-EMPTY-V62D")
    print(f"parent_v62_sha256={PARENT_SHA256}")
    print("raw_center_stratum=V=H=0_over_Q(U)")
    print("scope=post_transport_original_rows_on_function_field_of_rational_edge")
    print("representation=bezout_then_one_direct_original_polynomial_division")
    print("all_first_previous_pivot_coefficients_ledgered=true")
    print("individual_previous_edge_lifts_used=false")
    print("current_stage_used=false")
    print("P12_used=false")
    print("N13_used=false")
    print("raw_factor_cover_not_assumed=true", flush=True)

    bands132, pole_f132, pole_g132 = v62.build_transport_and_rows()
    n.configure_qd(direct_qprime=True)
    first_rows = qd.pack(
        "X-2",
        qd.first_band_polynomials(
            bands132[("f", 1)], bands132[("g", 1)]
        ),
    )
    first_pivots, forms94, free94, first_factors, first_dependent = (
        v62.parameterize_with_pivots(132, first_rows, "first_v62d")
    )
    assert len(first_pivots) == 38 and len(free94) == 94
    assert not first_dependent

    bands94 = {
        key: n.compose(forms, forms94) for key, forms in bands132.items()
    }
    pole_f94 = n.compose(pole_f132, forms94)
    pole_g94 = n.compose(pole_g132, forms94)
    previous_rows = qd.pack(
        "X-1",
        qd.compile_previous(
            bands94[("f", 1)], bands94[("f", 2)],
            bands94[("g", 1)], bands94[("g", 2)],
        ),
    )
    previous_rows += qd.pack(
        "P1", qd.compile_pole_previous(pole_f94, pole_g94)
    )
    previous_pivots, _, previous_factors, previous_dependent = n.solve_stage(
        94, previous_rows, "previous_pole_v62d"
    )
    assert len(previous_pivots) == 37
    bad = [record for record in previous_dependent if record[2]]
    assert len(previous_dependent) == 2 and len(bad) == 2
    assert [record[1] for record in bad] == [("X-1", 11), ("X-1", 13)]

    residuals, gcd, bezout = n.polynomial_ideal_gcd(
        [record[2] for record in bad]
    )
    check = BetaPoly()
    for residual, weight in zip(residuals, bezout):
        check += residual * weight
    assert check == gcd and gcd.degree == 0 and gcd
    combined = {}
    for (_, _, _, combination), outer_weight in zip(bad, bezout):
        for row_index, inner_weight in combination.items():
            add_scalar(combined, row_index, outer_weight * inner_weight)
    normalizer = -gcd.inverse()
    combined = {
        row_index: weight * normalizer
        for row_index, weight in combined.items()
        if weight * normalizer
    }

    reduced_replay = {}
    for row_index, weight in sorted(combined.items()):
        reduced_replay = v62.add_scaled_product(
            reduced_replay,
            v62.scalar_polynomial(weight),
            v62.row_polynomial(previous_rows[row_index]),
        )
    unit_polynomial = v62.scalar_polynomial(BetaPoly(1))
    assert reduced_replay == unit_polynomial
    print("previous_pole_actual_rank_accepted=37")
    print("previous_pole_nonzero_dependency_keys=[('X-1', 11), ('X-1', 13)]")
    print(f"previous_pole_compatibility_gcd_sha256={n.digest(gcd)}")
    print(f"previous_pole_compatibility_bezout_sha256={n.digest(tuple(bezout))}")
    print("previous_pole_reduced_bezout_exact=true", flush=True)

    raw_previous_rows = v62.source_records(
        "X-1",
        qd.compile_previous(
            bands132[("f", 1)], bands132[("f", 2)],
            bands132[("g", 1)], bands132[("g", 2)],
        ),
    )
    raw_previous_rows += v62.source_records(
        "P1", qd.compile_pole_previous(pole_f132, pole_g132)
    )
    raw_previous_index = {
        record[0]: index for index, record in enumerate(raw_previous_rows)
    }
    assert len(raw_previous_index) == len(raw_previous_rows)

    previous_multipliers = [{} for _ in raw_previous_rows]
    raw_combined = {}
    selected_keys = []
    for reduced_index, weight in sorted(combined.items()):
        key = previous_rows[reduced_index][0]
        selected_keys.append(key)
        raw_index = raw_previous_index[key]
        scalar = v62.scalar_polynomial(weight)
        previous_multipliers[raw_index] = g.add(
            previous_multipliers[raw_index], scalar
        )
        raw_combined = v62.add_scaled_product(
            raw_combined,
            scalar,
            v62.row_polynomial(raw_previous_rows[raw_index]),
        )

    remainder132, quotients = g.divide_polynomial(raw_combined, first_pivots)
    assert remainder132 == unit_polynomial
    first_relation = g.lift_relations(quotients, first_pivots, len(first_rows))
    first_source = v62.source_replay((first_relation,), (first_rows,))
    assert first_source == g.clean(g.add(raw_combined, unit_polynomial, -1))
    first_multipliers = [
        g.scale_polynomial(multiplier, -1) for multiplier in first_relation
    ]
    full_source = v62.source_replay(
        (first_multipliers, previous_multipliers),
        (first_rows, raw_previous_rows),
    )
    assert full_source == unit_polynomial

    nonzero_first = [index for index, value in enumerate(first_multipliers) if value]
    nonzero_previous = [
        index for index, value in enumerate(previous_multipliers) if value
    ]
    assert nonzero_first and nonzero_previous
    omitted_first = list(first_multipliers)
    omitted_first[nonzero_first[0]] = {}
    assert v62.source_replay(
        (omitted_first, previous_multipliers),
        (first_rows, raw_previous_rows),
    ) != unit_polynomial
    omitted_previous = list(previous_multipliers)
    omitted_previous[nonzero_previous[0]] = {}
    assert v62.source_replay(
        (first_multipliers, omitted_previous),
        (first_rows, raw_previous_rows),
    ) != unit_polynomial

    selected_degrees = [
        v62.total_degree(v62.row_polynomial(raw_previous_rows[index]))
        for index in nonzero_previous
    ]
    print(f"source_selected_previous_key_count={len(set(selected_keys))}")
    print(f"source_selected_previous_keys={sorted(set(selected_keys))}")
    print(f"source_selected_previous_max_degree={max(selected_degrees)}")
    print(f"source_first_multiplier_nonzero_count={len(nonzero_first)}")
    print(f"source_previous_multiplier_nonzero_count={len(nonzero_previous)}")
    print("combined_raw_previous_polynomial_divided_once=true")
    print("combined_remainder_is_exact_unit=true")
    print("arbitrary_degree_original_rows_preserved=true")
    print("full_original_row_unit_certificate_exact=true")
    print("one_first_source_edge_omission_negative_control=true")
    print("one_previous_source_edge_omission_negative_control=true", flush=True)

    certificate = (
        ("schema", "TD6-A3-Q2-V-H-ZERO-COMBINED-EMPTY-SOURCE-v1"),
        ("parent_v62_sha256", PARENT_SHA256),
        ("bad_keys", tuple(record[1] for record in bad)),
        ("residuals", tuple(residuals)),
        ("bezout", tuple(bezout)),
        ("gcd", gcd),
        ("normalized_reduced_weights", combined),
        ("first_pivot_digest", n.digest(first_factors)),
        ("previous_pivot_digest", n.digest(previous_factors)),
        ("first_keys", tuple(record[0] for record in first_rows)),
        ("first_multipliers", tuple(first_multipliers)),
        ("raw_previous_keys", tuple(record[0] for record in raw_previous_rows)),
        ("raw_previous_multipliers", tuple(previous_multipliers)),
        ("target", full_source),
    )
    certificate_text = repr(g.canonical(certificate)) + "\n"
    certificate_path = outdir / "COMBINED_PREVIOUS_SOURCE_UNIT.txt"
    certificate_path.write_text(certificate_text)
    print(f"source_certificate_path={certificate_path}")
    print(f"source_certificate_sha256={sha256(certificate_text.encode()).hexdigest()}")

    denominator_inputs = (
        ("normalizer", (normalizer,)),
        ("reduced_bezout", bezout),
        ("reduced_weights", combined.values()),
        ("first_multipliers", v62.relation_values(first_multipliers)),
        ("selected_first_rows", v62.selected_row_values(first_multipliers, first_rows)),
        ("previous_multipliers", v62.relation_values(previous_multipliers)),
        ("selected_raw_previous_rows", v62.selected_row_values(previous_multipliers, raw_previous_rows)),
    )
    ledger = v62.leaf_denominator_ledger(denominator_inputs)
    leaf_factors = sorted({
        factor
        for _, factors, _ in ledger.values()
        for factor, _ in factors
    })
    ledger_lines = [
        "denominator\tmultiplicity\tfirst_label\tfactorization",
        *(
            f"{denominator}\t{multiplicity}\t{label}\t{factorization}"
            for denominator, (label, factorization, multiplicity)
            in sorted(ledger.items())
        ),
    ]
    ledger_text = "\n".join(ledger_lines) + "\n"
    ledger_path = outdir / "COMBINED_SOURCE_UNIT_DENOMINATORS.tsv"
    ledger_path.write_text(ledger_text)
    print(f"source_denominator_ledger_path={ledger_path}")
    print(f"source_denominator_ledger_sha256={sha256(ledger_text.encode()).hexdigest()}")
    print(f"source_denominator_factor_set={leaf_factors}")
    print("source_denominator_all_factors_emitted=true")
    print("source_denominator_support_kind=coefficient_leaf_union")

    pivot_denominator_inputs = (
        ("first_normalized_pivots", pivot_values(first_pivots)),
        ("first_pre_normalization_leads", pivot_lead_values(first_factors)),
        ("previous_normalized_pivots", pivot_values(previous_pivots)),
        ("previous_pre_normalization_leads", pivot_lead_values(previous_factors)),
        ("previous_dependency_residuals", residuals),
        ("previous_dependency_bezout", bezout),
    )
    pivot_ledger = v62.leaf_denominator_ledger(pivot_denominator_inputs)
    pivot_factors = sorted({
        factor
        for _, factors, _ in pivot_ledger.values()
        for factor, _ in factors
    })
    pivot_ledger_lines = [
        "denominator\tmultiplicity\tfirst_label\tfactorization",
        *(
            f"{denominator}\t{multiplicity}\t{label}\t{factorization}"
            for denominator, (label, factorization, multiplicity)
            in sorted(pivot_ledger.items())
        ),
    ]
    pivot_ledger_text = "\n".join(pivot_ledger_lines) + "\n"
    pivot_ledger_path = outdir / "FIRST_PREVIOUS_PIVOT_DENOMINATORS.tsv"
    pivot_ledger_path.write_text(pivot_ledger_text)
    print(f"pivot_denominator_ledger_path={pivot_ledger_path}")
    print(f"pivot_denominator_ledger_sha256={sha256(pivot_ledger_text.encode()).hexdigest()}")
    print(f"pivot_denominator_factor_set={pivot_factors}")
    print("pivot_denominator_all_factors_emitted=true")
    print(
        "complete_localization_factor_set="
        f"{sorted(set(leaf_factors) | set(pivot_factors))}"
    )
    print("function_field_rational_edge_empty=true")
    print("raw_denominator_factor_strata_still_charged=true")
    print("whole_V_H_zero_edge_empty=false")
    print("full_A3_beta_family_killed=false")
    print("whole_TD6_killed=false")
    print("SP2_killed=false")
    print("JC2_resolved=false")
    print("TD6-A3-Q2-V-H-ZERO-COMBINED-EMPTY-V62D PASS")


if __name__ == "__main__":
    if os.environ.get("TD6_PREFLIGHT_ONLY") == "1":
        print("producer=TD6-A3-Q2-V-H-ZERO-COMBINED-EMPTY-V62D")
        print(f"parent_v62_sha256={PARENT_SHA256}")
        print("preflight_stratum=v-h-zero")
        print("recursive_import_and_source_pin_preflight=true")
        print("TD6-A3-Q2-V-H-ZERO-COMBINED-EMPTY-V62D PREFLIGHT PASS")
    else:
        main()
