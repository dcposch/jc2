# V62D proof-grade rational-edge source unit

V62D repeats V62C's one-division source-unit construction on
`V=H=0` over `Q(U)` and adds a complete first/previous pivot denominator
ledger.  It serializes the exact original-row multipliers, requires a direct
unit remainder and full source replay, and preserves independent first- and
previous-edge omission controls.  Every source-certificate and pivot factor
remains charged; no whole edge is claimed inside this run.

```bash
TD6_PREFLIGHT_ONLY=1 ./run_v62d.sh v-h-zero
TD6_OUTPUT_DIR=/absolute/output ./run_v62d.sh v-h-zero
```
