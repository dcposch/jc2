#!/usr/bin/env bash
set -euo pipefail

mode="${1:-}"
case "$mode" in
  generic|h-zero|b3-param) ;;
  *) echo "usage: $0 {generic|h-zero|b3-param}" >&2; exit 64 ;;
esac

root_dir="$(cd "$(dirname "$0")" && pwd)"
cd "$root_dir"
python_bin="${TD6_PYTHON:-/home/ubuntu/venvs/td6/bin/python}"
export PYTHONHASHSEED=0

if [[ "$mode" == generic ]]; then
  if [[ "${TD6_PREFLIGHT_ONLY:-0}" == 1 ]]; then
    exec "$python_bin" \
      jc2/cases/td6_c1_c2_c3_q2_full_source_glue_edge_dag_v60_20260825/replay.py
  fi
  : "${TD6_OUTPUT_DIR:?set TD6_OUTPUT_DIR}"
  exec "$python_bin" \
    jc2/cases/td6_c1_c2_c3_q2_full_source_glue_edge_dag_v60_20260825/replay.py
fi

: "${TD6_OUTPUT_DIR:?set TD6_OUTPUT_DIR}"
exec "$python_bin" \
  jc2/cases/td6_c1_c2_c3_q2_full_source_glue_raw_edge_dag_v60_20260825/replay.py \
  --stratum="$mode"
