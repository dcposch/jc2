# TD6 V58 raw-stratum proof-DAG source-glue replay

V58 composes the complete staged N13 ancestry into the reviewed V44 genuine
P12 identity on exactly one raw center chart.  Supported modes are `h-zero`
and `b3-param`.  Each mode rebuilds transport, first, previous/pole, and
current original rows, verifies every dependency edge, and emits all leaf
denominator factors.

This is a discriminator, not a divisor closure: every emitted factor stratum
remains charged.  Terminal PASS proves a unit source identity only over the
fraction field of the selected raw chart.

On an AWS host with the pinned TD6 environment:

```bash
sha256sum -c SOURCE.sha256
sha256sum -c V57_SOURCE.sha256
sha256sum -c V58_SOURCE.sha256
mkdir -p "$TD6_OUTPUT_DIR"
TD6_PREFLIGHT_ONLY=1 ./run_v58.sh h-zero
TD6_PREFLIGHT_ONLY=1 ./run_v58.sh b3-param
./run_v58.sh h-zero
# or
./run_v58.sh b3-param
```

The success marker is
`TD6-A3-Q2-FULL-SOURCE-GLUE-RAW-DAG-V58 PASS`.  Do not infer whole-`H=0`,
whole-`B3=0`, fixed-A3, TD6, SP-2, or JC2 from a PASS.
