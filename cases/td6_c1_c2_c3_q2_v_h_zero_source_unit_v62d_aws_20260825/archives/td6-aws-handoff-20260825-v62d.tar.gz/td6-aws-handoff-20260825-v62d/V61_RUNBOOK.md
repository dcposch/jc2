# TD6 V61 generic factor-emitting source DAG

V61 is the fail-closed generic companion to V60.  It uses the same exact
edge-only N13 proof DAG and direct-first genuine P12 replay, but it never
aborts merely because a source-lift denominator has a factor outside
`U,H,B3`.  It writes every leaf denominator, factorization, multiplicity,
provenance label, and allowed-factor Boolean before classifying the scope.

`generic_open_localization_repaired=true` is printed only if every leaf
denominator radical is supported on `U H B3`.  Otherwise terminal PASS means
only that the exact fraction-field source identity and a complete new-factor
ledger were emitted.  Each new factor remains a charged raw stratum.

AWS replay:

```bash
sha256sum -c SOURCE.sha256
sha256sum -c V61_SOURCE.sha256
chmod +x run_v61.sh
TD6_PREFLIGHT_ONLY=1 TD6_OUTPUT_DIR=/tmp/v61-preflight ./run_v61.sh
TD6_OUTPUT_DIR=/path/to/output ./run_v61.sh
```

No fixed-A3, TD6, SP-2, landing, or JC2 conclusion follows from terminal PASS
unless the printed generic-open Boolean is true and the raw divisor atlas is
separately complete.
