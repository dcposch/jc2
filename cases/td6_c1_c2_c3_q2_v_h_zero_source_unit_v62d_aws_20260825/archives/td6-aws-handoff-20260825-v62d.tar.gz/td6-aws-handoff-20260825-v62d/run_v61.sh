#!/usr/bin/env bash
set -euo pipefail

mode="${1:-generic}"
if [[ "$mode" != generic ]]; then
  echo "usage: $0 [generic]" >&2
  exit 64
fi

root_dir="$(cd "$(dirname "$0")" && pwd)"
cd "$root_dir"
: "${TD6_OUTPUT_DIR:?set TD6_OUTPUT_DIR}"
python_bin="${TD6_PYTHON:-/home/ubuntu/venvs/td6/bin/python}"
export PYTHONHASHSEED=0
exec "$python_bin" \
  jc2/cases/td6_c1_c2_c3_q2_full_source_glue_factor_dag_v61_20260825/replay.py
