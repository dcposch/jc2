#!/usr/bin/env bash
set -euo pipefail

mode="${1:-}"
case "$mode" in
  h-zero|b3-param) ;;
  *) echo "usage: $0 {h-zero|b3-param}" >&2; exit 64 ;;
esac

: "${TD6_OUTPUT_DIR:?set TD6_OUTPUT_DIR}"
python_bin="${TD6_PYTHON:-python3}"
export PYTHONHASHSEED=0
exec "$python_bin" \
  jc2/cases/td6_c1_c2_c3_q2_full_source_glue_raw_dag_v58_20260825/replay.py \
  --stratum="$mode"
