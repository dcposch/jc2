#!/usr/bin/env bash
set -euo pipefail

mode="${1:-}"
case "$mode" in
  v-h-zero) ;;
  *) echo "usage: $0 v-h-zero" >&2; exit 64 ;;
esac

root_dir="$(cd "$(dirname "$0")" && pwd)"
cd "$root_dir"
python_bin="${TD6_PYTHON:-/home/ubuntu/venvs/td6/bin/python}"
export PYTHONHASHSEED=0
if [[ "${TD6_PREFLIGHT_ONLY:-0}" != 1 ]]; then
  : "${TD6_OUTPUT_DIR:?set TD6_OUTPUT_DIR}"
fi
exec "$python_bin" \
  jc2/cases/td6_c1_c2_c3_q2_v_h_zero_combined_empty_v62c_20260825/replay.py \
  --stratum="$mode"
