# V62 rational-line edge-DAG source replay

Exact scope: the fixed source-typed A3 q2-beta line
`V=0, H=C-3U^2=0`, over `Q(U)`.  This successor lifts the singleton N13
dependency through original current, previous/pole, and first rows and
recomputes the genuine P12 direct-first certificate.  It emits every leaf
denominator; it does not import the separate `U=0` theorem or claim a whole
line unless that final composition is made outside this run.

Preflight:

```bash
TD6_PREFLIGHT_ONLY=1 ./run_v62.sh v-h-zero
```

Full run:

```bash
TD6_OUTPUT_DIR=/absolute/output ./run_v62.sh v-h-zero
```

Required controls: arbitrary-degree rows retained, exact quadratic previous
row positive control, current row 13 singleton source ancestry, wrong/omitted
edge negative, genuine P12 direct-first replay, byte-pinned V45 rational
certificate, and exact denominator ledger.

