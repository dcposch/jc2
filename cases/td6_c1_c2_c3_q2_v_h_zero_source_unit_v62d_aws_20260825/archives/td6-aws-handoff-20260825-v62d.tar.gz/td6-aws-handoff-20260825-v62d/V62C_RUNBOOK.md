# V62C combined rational-edge source unit

Exact scope: `V=0, H=C-3U^2=0` over `Q(U)`.  This independent
representation combines the two exact previous-stage dependencies first,
then divides their single raw original-row polynomial by the original first
pivots.  The exact remainder must be `1`.  Every coefficient denominator is
emitted and remains charged; no P12/N13 or global claim is used.

```bash
TD6_PREFLIGHT_ONLY=1 ./run_v62c.sh v-h-zero
TD6_OUTPUT_DIR=/absolute/output ./run_v62c.sh v-h-zero
```
