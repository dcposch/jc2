# V38 reverse-first independent genuine-P12 mirror

Run only on AWS from the extracted payload root.  Verify every inherited
manifest plus `V38_SOURCE.sha256`, then execute:

```sh
/usr/bin/time -v timeout 28800 \
  /home/ubuntu/venvs/td6/bin/python \
  jc2/cases/td6_c1_c2_c3_q2_full_p12_n13_unit_reverse_20260825/replay.py \
  > v38-reverse.stdout 2> v38-reverse.stderr
```

This is an independent row-schedule mirror of V37.  It reverses the full
original first-band row order before exact polynomial-beta elimination,
then separately recomputes the genuine 2,893-term P12 relation and the
staged-N13 unit combination.  Its pivot/source-multiplier fingerprint should
differ from V37 while the beta-zero P12 digest, `N13=(k/25)*beta`, final
`-k/50` unit residual, denominator radical bound, and terminal PASS agree.

The same strict scope applies: the P12 relation is fully lifted to original
first rows, while N13 retains the separately replayed staged V34 ancestry.
Only `D(U*H*B3)` is covered; raw center divisors and all global claims remain
excluded.
