#!/usr/bin/env python3
"""Exact generic TD6 center gate for (c1,c2,c3)=(C,V,U).

The entire matrix-changing transport, first affine band, and genuine P12 are
rebuilt over Q(C,V,U).  This is a generic-open producer only: every printed
pivot/denominator divisor remains a raw specialization obligation.
"""

from fractions import Fraction
from hashlib import sha256
import importlib.util
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
SOURCE = HERE / "replay.py"
SOURCE_SHA256 = "56df638aaa3ae02cf437a32258a920a8a66afb2781c089e30b1774a5b38e65db"
assert sha256(SOURCE.read_bytes()).hexdigest() == SOURCE_SHA256
spec = importlib.util.spec_from_file_location("td6_c1_c2_c3_source", SOURCE)
r = importlib.util.module_from_spec(spec)
assert spec.loader is not None
sys.modules[spec.name] = r
spec.loader.exec_module(r)

flint = r.t.flint
CTX = flint.fmpq_mpoly_ctx.get(["C", "V", "U"], ordering="lex")
C, V, U = CTX.gens()
ZERO, ONE = CTX.constant(0), CTX.constant(1)


def polynomial(value):
    if isinstance(value, flint.fmpq_mpoly):
        assert value.context() == CTX
        return value
    if isinstance(value, Fraction):
        return CTX.constant(flint.fmpq(value.numerator, value.denominator))
    if isinstance(value, flint.fmpq):
        return CTX.constant(value)
    return CTX.constant(value)


class Rat3:
    """Reduced exact rational function in Q(C,V,U)."""

    __slots__ = ("numerator", "denominator")
    inverse_count = 0

    def __init__(self, numerator=0, denominator=1, reduced=False):
        if isinstance(numerator, Rat3) and denominator == 1:
            self.numerator = numerator.numerator
            self.denominator = numerator.denominator
            return
        numerator, denominator = polynomial(numerator), polynomial(denominator)
        if not denominator:
            raise ZeroDivisionError
        if not numerator:
            self.numerator, self.denominator = ZERO, ONE
            return
        if denominator.total_degree() == 0:
            scalar = denominator.leading_coefficient()
            self.numerator, self.denominator = numerator / scalar, ONE
            return
        if not reduced:
            common = numerator.gcd(denominator)
            if common.total_degree() > 0:
                numerator, denominator = numerator // common, denominator // common
        scalar = denominator.leading_coefficient()
        self.numerator = numerator / scalar
        self.denominator = denominator / scalar

    @staticmethod
    def coerce(value):
        return value if isinstance(value, Rat3) else Rat3(value)

    def __add__(self, other):
        other = Rat3.coerce(other)
        if self.denominator == ONE and other.denominator == ONE:
            return Rat3(self.numerator + other.numerator, reduced=True)
        return Rat3(
            self.numerator * other.denominator
            + other.numerator * self.denominator,
            self.denominator * other.denominator,
        )

    __radd__ = __add__

    def __neg__(self):
        return Rat3(-self.numerator, self.denominator, reduced=True)

    def __sub__(self, other):
        return self + (-Rat3.coerce(other))

    def __rsub__(self, other):
        return Rat3.coerce(other) - self

    def __mul__(self, other):
        other = Rat3.coerce(other)
        if not self or not other:
            return Rat3()
        if self.denominator == ONE and other.denominator == ONE:
            return Rat3(self.numerator * other.numerator, reduced=True)
        left_common = self.numerator.gcd(other.denominator)
        right_common = other.numerator.gcd(self.denominator)
        return Rat3(
            (self.numerator // left_common) * (other.numerator // right_common),
            (self.denominator // right_common) * (other.denominator // left_common),
            reduced=True,
        )

    __rmul__ = __mul__

    def inverse(self):
        if not self.numerator:
            raise ZeroDivisionError
        Rat3.inverse_count += 1
        return Rat3(self.denominator, self.numerator, reduced=True)

    def __truediv__(self, other):
        return self * Rat3.coerce(other).inverse()

    def __rtruediv__(self, other):
        return Rat3.coerce(other) / self

    def __pow__(self, exponent):
        if exponent < 0:
            return self.inverse() ** (-exponent)
        out, base = Rat3(1), self
        while exponent:
            if exponent & 1:
                out *= base
            base *= base
            exponent //= 2
        return out

    def __bool__(self):
        return bool(self.numerator)

    def __eq__(self, other):
        other = Rat3.coerce(other)
        return (
            self.numerator == other.numerator
            and self.denominator == other.denominator
        )

    def __repr__(self):
        return f"Rat3(({self.numerator})/({self.denominator}))"


def factor_transport(rows):
    pivots, records, events = {}, [], []
    determinant = Rat3(1)
    for row_index, (key, original_row, _) in enumerate(rows):
        row = {variable: Rat3(value) for variable, value in original_row.items()}
        factors = []
        while row:
            pivot = min(row)
            if pivot not in pivots:
                break
            multiplier = row[pivot]
            factors.append((pivot, multiplier))
            for variable, coefficient in pivots[pivot].items():
                value = row.get(variable, Rat3()) - multiplier * coefficient
                if value:
                    row[variable] = value
                else:
                    row.pop(variable, None)
        if not row:
            records.append((key, "dependent", None, None, factors))
            continue
        pivot = min(row)
        lead = row[pivot]
        determinant *= lead
        if lead.numerator.total_degree() or lead.denominator.total_degree():
            events.append((row_index, key, pivot, lead.numerator, lead.denominator))
        inverse = lead.inverse()
        pivots[pivot] = {
            variable: coefficient * inverse
            for variable, coefficient in row.items()
        }
        records.append((key, "pivot", pivot, lead, factors))
        if row_index % 250 == 0:
            print(
                f"trivariate_transport rows={row_index};pivots={len(pivots)};"
                f"events={len(events)}",
                flush=True,
            )
    return pivots, records, events, determinant


class RTShim:
    Rat = Rat3

    @staticmethod
    def rational(value):
        return r.cp.rt.rational(value)


class CPShim:
    rt = RTShim
    qd = r.cp.qd
    K = r.cp.K
    E = r.cp.E
    Frac = r.cp.Frac
    fast_evec = r.cp.fast_evec


FIELD = r.cp.fast_efield.EFieldFactory(CPShim)
EField = r.cp.fast_efield.EField


class E3:
    __slots__ = ("value",)

    def __init__(self, value=0):
        if isinstance(value, E3):
            self.value = value.value
        elif isinstance(value, EField):
            assert value.factory is FIELD
            self.value = value
        elif isinstance(value, Rat3):
            self.value = FIELD.scalar(value)
        else:
            self.value = FIELD.from_e(r.cp.E(value))

    @staticmethod
    def coerce(value):
        return value if isinstance(value, E3) else E3(value)

    def __add__(self, other):
        return E3(self.value + E3.coerce(other).value)

    __radd__ = __add__

    def __neg__(self):
        return E3(-self.value)

    def __sub__(self, other):
        return self + (-E3.coerce(other))

    def __rsub__(self, other):
        return E3.coerce(other) - self

    def __mul__(self, other):
        return E3(self.value * E3.coerce(other).value)

    __rmul__ = __mul__

    def inverse(self):
        result = E3(self.value.inverse())
        assert self * result == E3(1)
        return result

    def __truediv__(self, other):
        return self * E3.coerce(other).inverse()

    def __rtruediv__(self, other):
        return E3.coerce(other) / self

    def __pow__(self, exponent):
        return E3(self.value**exponent)

    def __bool__(self):
        return bool(self.value)

    def __eq__(self, other):
        return self.value == E3.coerce(other).value


def configure():
    r.t.CTX = CTX
    r.t.C, r.t.U = C, U
    r.t.ZERO, r.t.ONE = ZERO, ONE
    r.t.Rat2 = Rat3
    r.t.factor = factor_transport
    r.b.FIELD = FIELD
    r.b.EField = EField
    r.b.E2 = E3
    r.E2 = E3
    r.REVERSE_PIVOTS = False
    r.SPARSE_PIVOTS = False
    r.B_LOCAL_PIVOTS = False
    r.b.REVERSE_PIVOTS = False
    r.b.SPARSE_PIVOTS = False
    r.b.B_LOCAL_PIVOTS = False


def exact_source_replay(polynomial, remainder, relations, first_rows):
    source_identity = {}
    for relation, (_, row, rhs) in zip(relations, first_rows):
        source_identity = r.add(
            source_identity,
            r.multiply(relation, r.source_polynomial(row, rhs)),
        )
    source_target = r.add(polynomial, remainder, E3(-1))
    assert r.clean(source_identity) == r.clean(source_target)
    assert r.clean(source_identity) != r.clean(r.add(source_target, {(): E3(1)}))


def main():
    configure()
    r.fb.CENTER = (Rat3(C), Rat3(V), Rat3(U))
    r.fb._X_POWER_CACHE.clear()
    nf, rows_f = r.fb.build_transport(
        15, 60, 3, {15: r.b.Q(1)}, r.fb.F1_F_PATTERN, r.fb.POLE_F_PATTERN
    )
    ng, rows_g = r.fb.build_transport(
        25, 100, 5, {1: r.b.Q(1), 25: r.b.Q(1)},
        r.fb.F1_G_PATTERN, r.fb.POLE_G_PATTERN,
    )
    rows = [(('f',) + key, row, rhs) for key, row, rhs in rows_f]
    rows += [
        (
            ('g',) + key,
            {nf + variable: coefficient for variable, coefficient in row.items()},
            rhs,
        )
        for key, row, rhs in rows_g
    ]
    ordered = [row for row in rows if row[0][1] != 'X'] + [
        row for row in rows if row[0][1] == 'X'
    ]
    transport_pivots, records, events, transport_determinant = r.t.factor(ordered)
    pivot_rhs, compatibility = r.t.propagate(ordered, records)
    assert not compatibility and len(transport_pivots) == 3470
    free = [
        variable for variable in range(nf + ng)
        if variable not in transport_pivots
    ]
    free_parameter = {variable: index for index, variable in enumerate(free)}
    assert len(free) == 132
    print("TD6 trivariate transport PASS", flush=True)
    print("transport_rank=3470/3602")
    print(f"transport_event_count={len(events)}")
    for index, (row_index, key, pivot, numerator, denominator) in enumerate(events):
        print(
            f"transport_event[{index}]={row_index},{key},{pivot};"
            f"num=({numerator});den=({denominator})"
        )
    print(f"transport_minor_num=({transport_determinant.numerator})")
    print(f"transport_minor_den=({transport_determinant.denominator})")
    print(f"transport_minor_num_factor={transport_determinant.numerator.factor()}")
    print(f"transport_minor_den_factor={transport_determinant.denominator.factor()}")

    bands = {}
    for owner, imax, jmax, offset in (
        ('f', 15, 60, 0), ('g', 25, 100, nf)
    ):
        for exponent in (1, 2, 3):
            forms = []
            for degree in range(16 if owner == 'f' else 26):
                row = {
                    offset + variable: coefficient
                    for variable, coefficient in r.fb.x_chart_coefficient(
                        imax, jmax, exponent, degree
                    ).items()
                }
                forms.append(r.b.restrict_row(
                    row, transport_pivots, pivot_rhs, free_parameter
                ))
            bands[(owner, exponent)] = forms

    r.qd.Dual = E3
    r.qd.Q_PRIME = {0: E3(1), 24: E3(25)}
    first_rows = r.qd.pack(
        'X-2', r.qd.first_band_polynomials(
            bands[('f', 1)], bands[('g', 1)]
        )
    )
    first_pivots, first_factors, incompatibilities = r.solve_cert(first_rows)
    assert not incompatibilities
    print(f"first_rank={len(first_pivots)}/132")
    print(f"first_incompatibility_count={len(incompatibilities)}")
    first_determinant = Rat3(1)
    for _, _, _, lead in first_factors:
        coordinate = r.scalar_coordinate(lead)
        assert coordinate is not None
        first_determinant *= coordinate
    print(f"first_minor_num=({first_determinant.numerator})")
    print(f"first_minor_den=({first_determinant.denominator})")
    print(f"first_minor_num_factor={first_determinant.numerator.factor()}")
    print(f"first_minor_den_factor={first_determinant.denominator.factor()}")

    raw = r.qd.compile_current(
        *[bands[('f', exponent)] for exponent in (1, 2, 3)],
        *[bands[('g', exponent)] for exponent in (1, 2, 3)],
    )[12]
    polynomial_value = {
        monomial: E3.coerce(coefficient)
        for monomial, coefficient in raw.items() if coefficient
    }
    assert max(map(len, polynomial_value)) == 2
    print("TD6 trivariate genuine P12 PASS", flush=True)
    remainder, quotients = r.divide(polynomial_value, first_pivots)
    relations = r.lift_relations(quotients, first_pivots, len(first_rows))
    exact_source_replay(polynomial_value, remainder, relations, first_rows)
    S = E3(r.qd.uniform.S_FIELD)
    k = E3(252) - 342*S + 144*S**2 - 36*S**3
    expected = -k / 50
    expected_remainder = remainder == {(): expected}
    constant_unit = False
    if set(remainder) == {()} and remainder[()]:
        inverse = remainder[()].inverse()
        assert remainder[()] * inverse == E3(1)
        constant_unit = True
        print(f"remainder_inverse_sha256={r.scalar_digest(inverse)}")

    relations_denominator = r.denominator_lcm(r.polynomial_values(relations))
    raw_denominator = r.denominator_lcm(polynomial_value.values())
    first_denominator = r.denominator_lcm(
        coefficient
        for _, row, rhs in first_rows
        for coefficient in list(row.values()) + [rhs]
    )
    termwise_denominator = relations_denominator * first_denominator
    termwise_denominator /= termwise_denominator.leading_coefficient()
    source_nonzero_rows = sum(bool(relation) for relation in relations)
    source_multiplier_terms = sum(len(relation) for relation in relations)
    print(f"raw_terms={len(polynomial_value)}")
    print(f"raw_sha256={r.polynomial_digest(polynomial_value)}")
    print(f"remainder_terms={len(remainder)}")
    print(f"remainder_degree={max(map(len, remainder), default=-1)}")
    print(f"remainder_sha256={r.polynomial_digest(remainder)}")
    print(f"expected_sha256={r.scalar_digest(expected)}")
    print(f"remainder_is_expected_constant={str(expected_remainder).lower()}")
    print(f"remainder_is_constant_unit={str(constant_unit).lower()}")
    print(f"source_nonzero_rows={source_nonzero_rows}")
    print(f"source_multiplier_terms={source_multiplier_terms}")
    print("source_relation_original_row_replay=true")
    print("source_relation_plus_one_negative_control=true")
    print(f"raw_denominator=({raw_denominator})")
    print(f"raw_denominator_factor={raw_denominator.factor()}")
    print(f"first_denominator=({first_denominator})")
    print(f"first_denominator_factor={first_denominator.factor()}")
    print(f"relation_denominator=({relations_denominator})")
    print(f"relation_denominator_factor={relations_denominator.factor()}")
    print(f"termwise_denominator=({termwise_denominator})")
    print(f"termwise_denominator_factor={termwise_denominator.factor()}")
    print(f"Rat3_inverse_count={Rat3.inverse_count}")
    print(f"generic_open_killed={str(constant_unit).lower()}")
    print("full_three_center_family_killed=false")
    print("SP2_killed=false")
    print("JC2_resolved=false")
    print("TD6-C1-C2-C3-TRIVARIATE-GENERIC PASS")


if __name__ == '__main__':
    main()
