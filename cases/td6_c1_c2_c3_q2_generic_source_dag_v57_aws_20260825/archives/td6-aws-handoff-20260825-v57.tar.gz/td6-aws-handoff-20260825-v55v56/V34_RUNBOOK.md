# V34 clean generic q2 N13 AWS replay

Run only on AWS from the extracted payload root.  Verify all manifests:

```sh
sha256sum -c SOURCE.sha256
sha256sum -c V31_SOURCE.sha256
sha256sum -c V33_SOURCE.sha256
sha256sum -c V34_SOURCE.sha256
```

Primary and omission-control runs:

```sh
python3 jc2/cases/td6_c1_c2_c3_q2_n13_v34_20260825/replay.py
python3 jc2/cases/td6_c1_c2_c3_q2_n13_v34_20260825/replay.py --omit-direct-qprime
```

V34 preserves the full polynomial-beta source calculation and all original
row replays.  It adds the exact gcd/Bezout certificate of every current
compatibility, uses the supported E3-coordinate accessor, and allows the
omission control to report its genuine dependency count.  A generic PASS
does not cover U=0, H=0, B3=0, or any emitted denominator divisor.
