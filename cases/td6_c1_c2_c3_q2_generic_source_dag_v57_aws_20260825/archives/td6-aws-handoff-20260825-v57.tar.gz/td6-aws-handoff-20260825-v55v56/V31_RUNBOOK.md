# V31 generic-center q2 N13 AWS runbook

Run only on AWS, from the extracted payload root.

First verify both manifests:

```sh
shasum -a 256 -c SOURCE.sha256
shasum -a 256 -c V31_SOURCE.sha256
```

Primary exact polynomial run:

```sh
python3 jc2/cases/td6_c1_c2_c3_q2_n13_20260825/replay.py \
  > n13-generic.stdout 2> n13-generic.stderr
```

Independent omission control (may run concurrently on another AWS core):

```sh
python3 jc2/cases/td6_c1_c2_c3_q2_n13_20260825/replay.py \
  --omit-direct-qprime \
  > n13-omit-qprime.stdout 2> n13-omit-qprime.stderr
```

The primary run eliminates over `E(C,V,U)[beta]`, accepts only
beta-independent unit pivots, and replays the transport, first,
previous/pole, and current rows with exact left-null ancestry.  The target is
the `X0,t13` compatibility.  A generic PASS requires the exact polynomial
identity `N13=(k/25)*beta`, but it still kills only the printed generic center
open.  Every denominator factor is a raw rebuild obligation.

The omission run must not be used as mathematics.  It is a negative control
for the direct `2*beta*t` contribution to `q'`; its output must differ at a
source-visible compatibility or fail an explicit expected comparison.

No result licenses A3-times-beta, TD6, SP-2, landing, or JC2 until the raw
`U=0`, `H=0`, and `B3=0` strata (and every newly exposed factor) are rebuilt
in the full beta family.
