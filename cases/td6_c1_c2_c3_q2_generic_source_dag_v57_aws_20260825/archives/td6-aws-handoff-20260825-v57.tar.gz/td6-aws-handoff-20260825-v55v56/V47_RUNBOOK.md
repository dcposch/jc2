# V47 canonical staged N13 replay

Run only on AWS after verifying the inherited V43 closure and
`V47_SOURCE.sha256`.  Use a fixed hash seed and a per-job memory cap:

```sh
PYTHONHASHSEED=0 systemd-run --user --scope -p MemoryMax=4G \
  /usr/bin/time -v timeout 1800 \
  /home/ubuntu/venvs/td6/bin/python \
  jc2/cases/td6_c1_c2_c3_q2_n13_compact_canonical_20260825/replay.py \
  > v47.stdout 2> v47.stderr
```

Run independently on r6d and Box03.  Promotion requires both rc0 and
byte-identical mathematical stdout.  The exact transport, first,
previous/pole, and current source replay is unchanged from V41.  V47 changes
only the digest serializer: every E3 value is represented by its 18 exact
rational coordinates before hashing.

Expected terminal marker: `TD6-A3-Q2-N13-RAW PASS`.  This is a portable
source-lift certificate for `N13=(k/25)beta` on the generic fraction field;
all emitted denominator divisors remain charged.

