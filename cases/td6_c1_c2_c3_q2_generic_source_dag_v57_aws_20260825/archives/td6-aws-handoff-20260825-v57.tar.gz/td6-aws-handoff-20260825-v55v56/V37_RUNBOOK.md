# V37 genuine-P12 / staged-N13 unit-syzygy AWS replay

Run only on AWS from the extracted payload root.  Verify the complete
inherited source closure and the V37 additions before starting:

```sh
sha256sum -c SOURCE.sha256
sha256sum -c V31_SOURCE.sha256
sha256sum -c V33_SOURCE.sha256
sha256sum -c V34_SOURCE.sha256
sha256sum -c V37_SOURCE.sha256
```

Primary exact replay:

```sh
/usr/bin/time -v timeout 28800 \
  /home/ubuntu/venvs/td6/bin/python \
  jc2/cases/td6_c1_c2_c3_q2_full_p12_n13_unit_20260825/replay.py \
  > v37.stdout 2> v37.stderr
```

The only success marker is:

```text
TD6-A3-Q2-FULL-P12-N13-UNIT PASS
```

The producer rebuilds the beta-dependent transport restriction and first
band over `E(C,V,U)[beta]`, accepting only beta-independent first-band
pivots.  It then compiles the actual 2,893-term P12 source polynomial before
the later current echelon, reduces it exactly, and lifts the quotient to the
original first rows.  It asserts the frozen beta-zero P12 digest and proves

```text
P12 - sum(first-row multipliers) = -k/50 + beta*T,
N13 = (k/25)*beta,
```

so adding `(25/k)*T` times the separately replayed staged N13 relation gives
the beta-independent unit residual `-k/50`, without dividing by beta.  The
source-visible omission control proves N13 is essential to the combination.

Source-lift scope is strict.  P12 is lifted through the full original first
rows in this file.  N13 is imported as the exact staged V34 compatibility,
whose transport/first/previous/current stages and left-null ancestry are
replayed separately; V37 does not claim a single flattened transport-to-
current source relation.  Promotion therefore requires a clean V34 primary
run with matching `N13=(k/25)*beta` as a dependency.

Every raw, first-row, relation, termwise-product, and N13-multiplier
denominator is audited.  A PASS kills only the common localization
`D(U*H*B3)` of the fixed source-typed `(C,V,U,beta)` family.  The raw
`U=0`, `H=0`, and `B3=0` strata remain charged until rebuilt exactly; no
whole-A3, whole-TD6, SP-2, landing, or JC2 claim is licensed.
