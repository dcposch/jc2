# V33 raw-stratum q2 N13 AWS runbook

Run only on AWS from the extracted payload root.  Verify the inherited and
V33 manifests before starting:

```sh
sha256sum -c SOURCE.sha256
sha256sum -c V31_SOURCE.sha256
sha256sum -c V33_SOURCE.sha256
```

Independent exact raw rebuilds:

```sh
python3 jc2/cases/td6_c1_c2_c3_q2_n13_raw_20260825/replay.py --stratum=u-zero
python3 jc2/cases/td6_c1_c2_c3_q2_n13_raw_20260825/replay.py --stratum=h-zero
python3 jc2/cases/td6_c1_c2_c3_q2_n13_raw_20260825/replay.py --stratum=b3-param
```

Each run rebuilds transport, first, previous/pole, and current original rows
over the indicated center fraction field with a genuine polynomial `beta`.
It accepts only beta-independent pivots, replays exact row ancestry, and
emits a monic compatibility gcd with a multi-Bezout certificate whenever a
stage becomes inconsistent.  A degree-zero gcd proves emptiness only on the
printed raw fraction field; every certificate denominator remains a raw
sub-stratum obligation.

The B3 chart includes the inherited executable birational coverage audit.
Its omitted `w=0`, `t=0`, and `t=2` loci must be covered by the existing raw
atlas or rebuilt separately.  No V33 output alone licenses a global A3-beta,
TD6, SP-2, landing, or JC2 claim.
