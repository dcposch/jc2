# TD6 V57 proof-DAG source-glue replay

Run only on an AWS host with the pinned campaign Python environment:

```bash
TD6_OUTPUT_DIR="$RUN_DIR/artifacts" ./run_v57.sh \
  > "$RUN_DIR/v57.stdout" 2> "$RUN_DIR/v57.stderr"
```

The replay preserves V53's exact arbitrary-degree row reductions but avoids
expanding the final global source polynomial.  It verifies each required
current-to-previous/first source edge, the staged N13 left-null relation, the
byte-pinned V43 P12 source dependency, the exact scalar glue, and every leaf
denominator prime.  Terminal success is
`TD6-A3-Q2-FULL-SOURCE-GLUE-DAG-V57 PASS`.

This is scoped to the post-transport fixed A3 chart `D(U*H*B3)`.  The raw
`U=0`, `H=0`, and `B3=0` strata remain separate, and no full-A3, whole-TD6,
SP-2, or JC2 conclusion is licensed.
