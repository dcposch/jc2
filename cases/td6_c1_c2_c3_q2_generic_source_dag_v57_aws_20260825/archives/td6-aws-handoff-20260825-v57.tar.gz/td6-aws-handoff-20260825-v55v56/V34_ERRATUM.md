# V31 post-math sentinel erratum

The immutable V31 primary run reached and asserted
`N13_equals_reviewed_k_beta_over_25=true`, then exited `rc=1` because the
optional coordinate-degree reporter accessed the obsolete attribute
`EField.coordinates`.  The correct public accessor is
`tri.e3_rat3_coordinates`.

The immutable V31 omission run emitted all current compatibilities and then
exited `rc=1` because its harness required one `X0,t13` dependent row.  The
omission changes the echelon and correctly leaves zero such rows.  V34
asserts and reports the actual count instead of imposing the primary-row
cardinality on the negative control.

Neither V31 `rc=1` run is promoted.  Its output is retained only as
post-math corroboration and provenance for the V34 corrections.
