# V66 repaired B3 source DAG

V66 applies the reviewed V64 ancestry/control repair to the exact birational
`B3=0` chart.  It pins the matching V44 B3 source objects, distinguishes the
N13 previous edge from the independent quadratic control, replays genuine
P12 directly through original first rows, and emits every coefficient-leaf
and pinned P12 termwise denominator factor.  Each factor remains a separate
raw-stratum obligation.

```bash
TD6_PREFLIGHT_ONLY=1 ./run_v66.sh
TD6_OUTPUT_DIR=/absolute/output ./run_v66.sh
```

No whole-B3, full-A3, TD6, SP-2, landing, or JC2 claim is made.
