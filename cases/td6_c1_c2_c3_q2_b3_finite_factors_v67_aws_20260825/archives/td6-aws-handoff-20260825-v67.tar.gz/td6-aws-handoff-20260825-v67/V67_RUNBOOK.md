# V67 repaired source DAG on the two finite B3 chart factors

V67 reuses the hash-pinned exact curve-field implementation already present
in V65 and applies the repaired full N13/P12 source DAG to `t=1/2` and
`t^2-4t+2=0`.  It retains direct q-prime, emits every denominator/norm factor,
and supplies a separate direct-qprime omission control.

```bash
TD6_PREFLIGHT_ONLY=1 ./run_v67.sh b3half
TD6_PREFLIGHT_ONLY=1 ./run_v67.sh b3tq
TD6_OUTPUT_DIR=/absolute/output ./run_v67.sh b3half
TD6_OUTPUT_DIR=/absolute/output ./run_v67.sh b3tq
TD6_OUTPUT_DIR=/absolute/output ./run_v67.sh b3half omit-direct-qprime
TD6_OUTPUT_DIR=/absolute/output ./run_v67.sh b3tq omit-direct-qprime
```

No whole-factor statement follows until every emitted `w`-denominator factor
is rebuilt.  No whole-B3, fixed-A3, TD6, SP-2, landing, or JC2 claim is made.
