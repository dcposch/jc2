#!/usr/bin/env bash
set -euo pipefail

component="${1:-}"
control="${2:-}"
case "$component" in
  b3half|b3tq) ;;
  *) echo "usage: $0 {b3half|b3tq} [omit-direct-qprime]" >&2; exit 64 ;;
esac
case "$control" in
  "") extra=() ;;
  omit-direct-qprime) extra=(--omit-direct-qprime) ;;
  *) echo "usage: $0 {b3half|b3tq} [omit-direct-qprime]" >&2; exit 64 ;;
esac

root_dir="$(cd "$(dirname "$0")" && pwd)"
cd "$root_dir"
python_bin="${TD6_PYTHON:-/home/ubuntu/venvs/td6/bin/python}"
export PYTHONHASHSEED=0
if [[ "${TD6_PREFLIGHT_ONLY:-0}" != 1 ]]; then
  : "${TD6_OUTPUT_DIR:?set TD6_OUTPUT_DIR}"
fi
exec "$python_bin" \
  jc2/cases/td6_c1_c2_c3_q2_b3_factor_source_dag_repaired_v67_20260825/replay.py \
  --component="$component" "${extra[@]}"
