# V64 repair replay for the H=0 source DAG

This is a nonmutating successor to V60 after hostile review
`c99895806fbf7cbae8baea451856a86949c0b4049185dc5d0227425938a5d89e`.
The arithmetic path is unchanged.  The custody and controls are repaired:

- N13 current row 13 uses exactly previous edge `('X-1',14)`;
- `('X-1',0)` is separately labeled as the arbitrary-degree quadratic
  positive control, not an N13 ancestor;
- the row-14 previous edge receives its own omission negative control;
- the singleton-current-row omission control is named narrowly;
- genuine P12 live counts `2885/28/1640` and the live no-N13 object
  inequality are asserted;
- `k` is explicitly checked as a frozen residue-field unit with no center
  denominator factor;
- the 16-line support is labeled a leaf-coefficient radical plus the pinned
  V44 P12 termwise clear.

Exact scope remains only `H=0,D(U*V*P3*QH)`.  The run does not claim that
QH is essential, nor a whole-H/fixed-A3/TD6/SP-2/landing/JC2 theorem.

```bash
TD6_PREFLIGHT_ONLY=1 ./run_v64.sh
TD6_OUTPUT_DIR=/absolute/output ./run_v64.sh
```

