# V54B reverse fraction-free first-stage denominator diagnostic

V52 stopped exactly because six reverse-scheduled first-stage rows have no
beta-independent unit pivot after unit closure.  V54 preserves that closure,
then performs deterministic fraction-free elimination of those rows.  Every
nonunit pivot polynomial, center-coefficient denominator, and original-row
combination is emitted and replayed exactly.

The immutable V54 attempt reached the first exact pivot and then failed only
because its reporter passed a raw FLINT multivariate denominator to the
canonical E3 serializer.  V54B hashes the stable FLINT string instead and also
allows a later fraction-free combination to recover a beta-unit pivot.

V54B deliberately stops after this first-stage diagnostic.  It is not a full
V50 source identity, does not invert the recorded pivot product, and licenses
no open-cover, family, TD6, SP-2, or JC2 inference.

Run only on AWS after verifying `SOURCE.sha256` and `V54_SOURCE.sha256`:

```sh
mkdir -p v54-artifacts
TD6_OUTPUT_DIR="$PWD/v54b-artifacts" ./run_v54b.sh \
  > v54b.stdout 2> v54b.stderr
```

Expected terminal marker:
`TD6-A3-Q2-REVERSE-DENOMINATOR-V54B PASS`.

Any nonzero dependent residual is retained as an exact original-row
compatibility certificate.  The product of nonunit pivots defines only this
one reverse chart.  Comparing it with another chart requires explicit
localized saturation/Bezout data, never a multivariate gcd print.
