#!/usr/bin/env python3
"""Canonical reverse-order first-stage denominator diagnostic after V54B.

V52 proved that its reverse/deferred schedule cannot finish using only
beta-independent unit pivots.  This successor preserves that unit closure,
then performs deterministic fraction-free elimination on every unresolved
row.  It records every nonunit pivot polynomial, its source-row ancestry,
and the center-ring denominators of all coefficients.  It deliberately stops
after the first stage: this is an independent chart/denominator diagnostic,
not a full V50 source identity or a cover claim.  V54C replaces V54B's
object-address-contaminated ``repr(BetaPoly)`` artifact writer with the exact
canonical E(C,V,U)[beta] serializer already used by the N13 parent.
"""

from hashlib import sha256
import importlib.util
import os
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
V52_PATH = (
    HERE.parent
    / "td6_c1_c2_c3_q2_full_source_glue_reverse_unit_v52_20260825"
    / "replay.py"
)
V52_SHA256 = "ad09a4c3252ce848053c22882ad53ed092271839b32ed986265e78895de5e9fe"
assert sha256(V52_PATH.read_bytes()).hexdigest() == V52_SHA256
spec = importlib.util.spec_from_file_location("td6_v54_v52_parent", V52_PATH)
u = importlib.util.module_from_spec(spec)
assert spec.loader is not None
sys.modules[spec.name] = u
spec.loader.exec_module(u)

assert sys.argv[1:] == []
v, n, BetaPoly = u.v, u.n, u.BetaPoly


class DiagnosticComplete(Exception):
    pass


def raw_polynomial_digest(value):
    """Stable FLINT polynomial reporter outside the canonical E3 serializer."""
    return sha256((str(value) + "\n").encode()).hexdigest()


def canonical_beta_text(value):
    """Portable exact BetaPoly text; reject Python object-address repr."""
    text = repr(n.canonical(BetaPoly.coerce(value))) + "\n"
    assert "object at 0x" not in text
    return text


def scaled_difference(left, left_scale, right, right_scale):
    out = {}
    for variable, coefficient in left.items():
        n.add_to_row(out, variable, left_scale * coefficient)
    for variable, coefficient in right.items():
        n.add_to_row(out, variable, -right_scale * coefficient)
    return out


def scaled_combination(left, left_scale, right, right_scale):
    out = {}
    for index, coefficient in left.items():
        value = left_scale * coefficient
        if value:
            out[index] = value
    for index, coefficient in right.items():
        value = out.get(index, BetaPoly()) - right_scale * coefficient
        if value:
            out[index] = value
        else:
            out.pop(index, None)
    return out


def fraction_free_reduce(record, pivot_records):
    row_index, key, row, rhs, combination = record
    row, combination = dict(row), dict(combination)
    for pivot_variable, pivot_row, pivot_rhs, pivot_combination, lead in pivot_records:
        coefficient = row.get(pivot_variable, BetaPoly())
        if not coefficient:
            continue
        row = scaled_difference(row, lead, pivot_row, coefficient)
        rhs = lead * rhs - coefficient * pivot_rhs
        combination = scaled_combination(
            combination, lead, pivot_combination, coefficient
        )
    return row_index, key, row, rhs, combination


def unit_closure(rows, stage):
    source = [
        (
            key,
            {variable: BetaPoly.coerce(value) for variable, value in row.items()},
            BetaPoly.coerce(rhs),
        )
        for key, row, rhs in rows
    ]
    pending = [
        (index, source[index][0], source[index][1], source[index][2],
         {index: BetaPoly(1)})
        for index in range(len(source) - 1, -1, -1)
    ]
    pivots, order, factors, dependent = {}, [], [], []
    passes = 0
    while pending:
        passes += 1
        next_pending = []
        new_pivots = 0
        for row_index, key, row, rhs, combination in pending:
            row, rhs, combination = u.reduce_record(
                row, rhs, combination, pivots, order
            )
            u.replay_combination(source, row, rhs, combination)
            if not row:
                dependent.append((row_index, key, rhs, combination))
                continue
            candidates = [
                variable for variable, coefficient in row.items()
                if coefficient and coefficient.degree == 0
            ]
            if not candidates:
                next_pending.append((row_index, key, row, rhs, combination))
                continue
            pivot = max(candidates)
            lead = row[pivot]
            inverse = lead.inverse()
            normalized_row = {
                variable: coefficient * inverse
                for variable, coefficient in row.items()
            }
            normalized_rhs = rhs * inverse
            normalized_combination = {
                index: coefficient * inverse
                for index, coefficient in combination.items()
            }
            pivots[pivot] = (
                normalized_row, normalized_rhs, normalized_combination
            )
            order.append(pivot)
            factors.append((row_index, key, pivot, lead))
            new_pivots += 1
        pending = next_pending
        if pending and not new_pivots:
            break
    print(f"{stage}_unit_rank={len(pivots)}")
    print(f"{stage}_unit_dependent_count={len(dependent)}")
    print(f"{stage}_unit_passes={passes}")
    print(f"{stage}_unresolved_nonunit_count={len(pending)}")
    print(f"{stage}_unit_pivot_digest={n.digest(tuple(factors))}")
    for ordinal, (row_index, key, row, rhs, combination) in enumerate(pending):
        print(f"{stage}_unresolved[{ordinal}]_row={row_index}")
        print(f"{stage}_unresolved[{ordinal}]_key={key}")
        print(f"{stage}_unresolved[{ordinal}]_row_sha256={n.digest(tuple(sorted(row.items())))}")
        print(f"{stage}_unresolved[{ordinal}]_rhs_sha256={n.digest(rhs)}")
        print(f"{stage}_unresolved[{ordinal}]_source_count={len(combination)}")
        print(
            f"{stage}_unresolved[{ordinal}]_source_sha256="
            f"{n.digest(tuple(sorted(combination.items())))}"
        )
    print(f"{stage}_unresolved_original_row_replay=true", flush=True)
    return source, pending, dependent, len(pivots)


def diagnostic_parameterize(nvariables, rows, stage):
    assert stage == "first_v50"
    outdir = Path(os.environ.get("TD6_OUTPUT_DIR", ".")).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    source, pending, dependent, unit_rank = unit_closure(rows, stage)
    assert len(pending) == 6

    pivot_records = []
    coefficient_denominators = []
    records = list(pending)
    while records:
        reduced, surviving = [], []
        for record in records:
            record = fraction_free_reduce(record, pivot_records)
            row_index, key, row, rhs, combination = record
            u.replay_combination(source, row, rhs, combination)
            if row:
                surviving.append(record)
            else:
                dependent.append((row_index, key, rhs, combination))
        if not surviving:
            break

        choices = []
        for position, (row_index, key, row, rhs, combination) in enumerate(surviving):
            for variable, coefficient in row.items():
                choices.append(
                    (coefficient.degree, -variable, row_index, position, variable)
                )
        _, _, _, chosen_position, pivot_variable = min(choices)
        row_index, key, row, rhs, combination = surviving.pop(chosen_position)
        lead = row[pivot_variable]
        assert lead
        ordinal = len(pivot_records)
        pivot_records.append(
            (pivot_variable, row, rhs, combination, lead)
        )
        coefficient_denominator = n.denominator_lcm_beta(
            list(row.values()) + [rhs] + list(combination.values())
        )
        coefficient_denominators.append(coefficient_denominator)
        print(f"{stage}_nonunit[{ordinal}]_row={row_index}")
        print(f"{stage}_nonunit[{ordinal}]_key={key}")
        print(f"{stage}_nonunit[{ordinal}]_pivot_variable={pivot_variable}")
        print(f"{stage}_nonunit[{ordinal}]_pivot_degree={lead.degree}")
        print(
            f"{stage}_nonunit[{ordinal}]_pivot_is_beta_unit="
            f"{str(lead.degree == 0).lower()}"
        )
        print(f"{stage}_nonunit[{ordinal}]_pivot_sha256={n.digest(lead)}")
        print(f"{stage}_nonunit[{ordinal}]_row_sha256={n.digest(tuple(sorted(row.items())))}")
        print(f"{stage}_nonunit[{ordinal}]_rhs_sha256={n.digest(rhs)}")
        print(f"{stage}_nonunit[{ordinal}]_source_count={len(combination)}")
        print(
            f"{stage}_nonunit[{ordinal}]_source_sha256="
            f"{n.digest(tuple(sorted(combination.items())))}"
        )
        print(
            f"{stage}_nonunit[{ordinal}]_coefficient_denominator_sha256="
            f"{raw_polynomial_digest(coefficient_denominator)}"
        )
        print(
            f"{stage}_nonunit[{ordinal}]_coefficient_denominator="
            f"({coefficient_denominator})"
        )
        print(f"{stage}_nonunit[{ordinal}]_original_row_replay=true", flush=True)
        records = surviving

    expected_denominators = [
        n.U**4 * n.H,
        n.U**4 * n.H,
        n.U**5,
        n.U**4 * n.H**2,
        n.U**3 * n.H**4,
        n.H**8,
    ]
    assert coefficient_denominators == expected_denominators

    all_leads = [record[4] for record in pivot_records]
    pivot_product = BetaPoly(1)
    for lead in all_leads:
        pivot_product *= lead
    coefficient_denominator = n.denominator_lcm_beta(all_leads)
    pivot_text = "".join(
        f"{index}\t{record[0]}\t{canonical_beta_text(record[4])}"
        for index, record in enumerate(pivot_records)
    )
    product_text = canonical_beta_text(pivot_product)
    assert "object at 0x" not in pivot_text
    (outdir / "REVERSE_FIRST_NONUNIT_PIVOTS.tsv").write_text(pivot_text)
    (outdir / "REVERSE_FIRST_PIVOT_PRODUCT.txt").write_text(product_text)
    assert (outdir / "REVERSE_FIRST_NONUNIT_PIVOTS.tsv").read_text() == pivot_text
    assert (outdir / "REVERSE_FIRST_PIVOT_PRODUCT.txt").read_text() == product_text
    print(f"{stage}_fraction_free_nonunit_count={len(pivot_records)}")
    print(f"{stage}_fraction_field_rank={unit_rank + len(pivot_records)}/{nvariables}")
    print(f"{stage}_fraction_free_dependent_count={len(dependent)}")
    print(f"{stage}_pivot_product_degree={pivot_product.degree}")
    print(f"{stage}_pivot_product_sha256={n.digest(pivot_product)}")
    print(
        f"{stage}_pivot_product_file_sha256="
        f"{sha256(product_text.encode()).hexdigest()}"
    )
    print(
        f"{stage}_nonunit_pivots_file_sha256="
        f"{sha256(pivot_text.encode()).hexdigest()}"
    )
    print(f"{stage}_coefficient_denominator=({coefficient_denominator})")
    print(
        f"{stage}_coefficient_denominator_sha256="
        f"{raw_polynomial_digest(coefficient_denominator)}"
    )
    print(f"{stage}_fraction_free_original_row_replay=true")
    assert coefficient_denominator == n.U * n.H**8
    print(f"{stage}_center_denominator_support_exact_U_H=true")
    print(f"{stage}_canonical_artifacts_address_free=true")
    bad = [record for record in dependent if record[2]]
    print(f"{stage}_fraction_free_nonzero_dependency_count={len(bad)}")
    if bad:
        n.emit_stage_incompatibilities(dependent, stage + "_fraction_free")
    print("reverse_chart_product_nonvanishing_required=true")
    print("reverse_chart_coverage_inference=false")
    print("full_V50_source_identity_replayed=false")
    print("full_A3_beta_family_killed=false")
    print("whole_TD6_killed=false")
    print("SP2_killed=false")
    print("JC2_resolved=false", flush=True)
    raise DiagnosticComplete


def main():
    v.parameterize_with_pivots = diagnostic_parameterize
    print("producer=TD6-A3-Q2-REVERSE-DENOMINATOR-V54C")
    print("successor_of=V54B-object-address-artifact-failure")
    print("independent_post_transport_row_order=reverse_deferred_fraction_free")
    print("nonunit_pivots_recorded_not_inverted=true")
    print(f"V52_source_sha256={V52_SHA256}", flush=True)
    try:
        v.main()
    except DiagnosticComplete:
        print("TD6-A3-Q2-REVERSE-DENOMINATOR-V54C PASS")
        return
    raise AssertionError("V54B diagnostic stop was not reached")


if __name__ == "__main__":
    main()
