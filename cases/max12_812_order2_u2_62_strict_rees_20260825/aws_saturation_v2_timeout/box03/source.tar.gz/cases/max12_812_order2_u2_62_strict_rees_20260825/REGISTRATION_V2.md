# Registration: V2 `j!=0`-localized strict-Rees gate

Status: source-frozen, AWS-only, awaiting exact V2 emission and saturation.

V2 imports the frozen exact-tail compiler, requires the frozen client
erratum, preserves all seven tail polynomials byte-for-byte, and changes
only the Singular interior saturation from `tau,rho` to `tau,rho,j`.
The Shioda/Hall all-zero-lower-load optimization is explicitly absent.

Compilation uses a 128-GiB cap and 7,200-second timeout.  Saturation uses
the existing AWS-only runners (256 GiB on r6d, 192 GiB on Box03) and a
14,400-second timeout.  Each launch records host, remote directory, PID,
input hash, engine version, and UTC start before the payload.

No V1 endpoint is consumed.  A V2 unit endpoint would exclude strict tail
arcs for this fixed source only; either outcome leaves both Taylor families
and rational-section descent open.
