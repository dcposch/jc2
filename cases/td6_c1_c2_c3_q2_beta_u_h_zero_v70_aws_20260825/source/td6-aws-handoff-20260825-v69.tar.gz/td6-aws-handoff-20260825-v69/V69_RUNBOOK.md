# V69 canonical U=0 digest custody repair

V69 changes only digest serialization in a copy of the V33 raw N13 producer.
V33 hashed `repr(E3)` even though `E3` had no `__repr__`, so several printed
hashes included process-specific object addresses. V69 recursively serializes
each E3 value as its 18 exact Rat3 coordinates, and each Rat3 numerator and
denominator as sorted monomial/coefficient tuples.

Run only on AWS after verifying both source manifests:

```sh
sha256sum -c SOURCE.sha256
sha256sum -c V69_SOURCE.sha256
./run_v69.sh
./run_v69.sh --omit-direct-qprime
```

Promotion requires byte-identical mathematical stdout across two hosts,
unchanged non-digest V33 markers, and a negative direct-q-prime omission
control. This is a reporter/custody repair only; it does not broaden the
fixed-A3 q2-beta `U=0` theorem or any TD6/SP-2/JC2 scope.
