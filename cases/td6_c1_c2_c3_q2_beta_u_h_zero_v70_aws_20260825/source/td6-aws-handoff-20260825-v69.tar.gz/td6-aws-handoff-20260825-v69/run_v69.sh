#!/usr/bin/env bash
set -euo pipefail

root_dir="$(cd "$(dirname "$0")" && pwd)"
cd "$root_dir"
python_bin="${TD6_PYTHON:-/home/ubuntu/venvs/td6/bin/python}"
export PYTHONHASHSEED=0
exec "$python_bin" \
  jc2/cases/td6_c1_c2_c3_q2_n13_raw_canonical_v69_20260825/replay.py \
  --stratum=u-zero "$@"
