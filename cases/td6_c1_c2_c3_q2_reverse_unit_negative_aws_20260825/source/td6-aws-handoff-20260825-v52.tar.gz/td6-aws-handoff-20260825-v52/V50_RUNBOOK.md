# V50 arbitrary-degree staged-N13 / genuine-P12 source composition

Run only on AWS after verifying `V50_SOURCE.sha256`.  V48 is retained as a
negative harness control: it stopped when its linear packer correctly rejected
genuinely quadratic pre-first source equations.  V50 keeps those equations as
arbitrary-degree sparse polynomials, checks every raw previous/current row by
exact division and source replay, and includes an explicit quadratic-row
positive control.  The producer imports the
canonical V43 compiler by pinned SHA, reconstructs the full first,
previous/pole, and current ancestry of `N13`, and substitutes it into the
genuine-P12 identity.  It writes the exact common coefficient and termwise
denominators into the run directory.

```sh
mkdir -p v50-artifacts
TD6_OUTPUT_DIR="$PWD/v50-artifacts" PYTHONHASHSEED=0 \
  systemd-run --user --scope -p MemoryMax=12G \
  /usr/bin/time -v timeout 7200 \
  /home/ubuntu/venvs/td6/bin/python \
  jc2/cases/td6_c1_c2_c3_q2_full_source_glue_v50_20260825/replay.py \
  > v50.stdout 2> v50.stderr
```

Expected terminal marker:
`TD6-A3-Q2-FULL-SOURCE-GLUE-V50 PASS`.

Interpretation is fail-closed.  The post-transport generic open is repaired
only if both emitted denominator-radical checks are `true`.  Any other factor
remains charged.  The script never treats multivariate gcd one as comaximal;
any future two-order glue must replay
`a*d1+b*d2=(U*H*B3)^N` (or an equivalent finite principal-open cover).
