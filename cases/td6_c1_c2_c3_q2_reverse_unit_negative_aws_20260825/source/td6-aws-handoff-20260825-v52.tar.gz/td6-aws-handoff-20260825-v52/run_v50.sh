#!/usr/bin/env bash
set -euo pipefail

: "${TD6_OUTPUT_DIR:?set TD6_OUTPUT_DIR to the immutable run artifact directory}"
mkdir -p "$TD6_OUTPUT_DIR"
export PYTHONHASHSEED=0

exec systemd-run --user --scope -p MemoryMax=12G \
  /usr/bin/time -v timeout 7200 \
  /home/ubuntu/venvs/td6/bin/python \
  jc2/cases/td6_c1_c2_c3_q2_full_source_glue_v50_20260825/replay.py
