#!/usr/bin/env python3
"""Independent unit-pivot source replay for the V50 full ancestry.

Rows are scheduled in reverse.  At each pass this wrapper selects the largest
available variable having a beta-independent coefficient, deferring rows whose
current leading coefficients are beta-dependent.  This avoids localizing at
beta while producing a pivot basis genuinely different from V50's forward
smallest-variable basis.  All affine and nonlinear source identities are then
replayed by V50 unchanged.
"""

from hashlib import sha256
import importlib.util
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
V50_PATH = (
    HERE.parent / "td6_c1_c2_c3_q2_full_source_glue_v50_20260825" / "replay.py"
)
V50_SHA256 = "203567dbf0fea333d17d197d81b82e6e6f864c4181d4604275c7db5d53bd8be1"
assert sha256(V50_PATH.read_bytes()).hexdigest() == V50_SHA256
spec = importlib.util.spec_from_file_location("td6_v52_source_parent", V50_PATH)
v = importlib.util.module_from_spec(spec)
assert spec.loader is not None
sys.modules[spec.name] = v
spec.loader.exec_module(v)

assert sys.argv[1:] == []
n, g, nr, BetaPoly = v.n, v.g, v.nr, v.BetaPoly
PIVOT_ORDERS = {}


def reduce_record(row, rhs, combination, pivots, order):
    row, combination = dict(row), dict(combination)
    for pivot in order:
        factor = row.get(pivot, BetaPoly())
        if not factor:
            continue
        old_row, old_rhs, old_combination = pivots[pivot]
        for variable, coefficient in old_row.items():
            n.add_to_row(row, variable, -factor * coefficient)
        rhs -= factor * old_rhs
        for old_index, coefficient in old_combination.items():
            value = combination.get(old_index, BetaPoly()) - factor * coefficient
            if value:
                combination[old_index] = value
            else:
                combination.pop(old_index, None)
    return row, rhs, combination


def replay_combination(source, row, rhs, combination):
    got_row, got_rhs = {}, BetaPoly()
    for source_index, weight in combination.items():
        _, source_row, source_rhs = source[source_index]
        for variable, coefficient in source_row.items():
            n.add_to_row(got_row, variable, weight * coefficient)
        got_rhs += weight * source_rhs
    assert got_row == row and got_rhs == rhs


def reverse_unit_solve_stage(nvariables, rows, stage):
    """Reverse-row GE over K[beta], allowing only K-unit pivots."""
    source = [
        (
            key,
            {variable: BetaPoly.coerce(value) for variable, value in row.items()},
            BetaPoly.coerce(rhs),
        )
        for key, row, rhs in rows
    ]
    target = None
    schedule = list(range(len(source) - 1, -1, -1))
    if stage.startswith("current"):
        target_indices = [
            index for index, (key, _, _) in enumerate(source)
            if key == ("X0", 13)
        ]
        assert len(target_indices) == 1
        target = target_indices[0]
        schedule.remove(target)

    pending = [
        (index, source[index][0], source[index][1], source[index][2], {index: BetaPoly(1)})
        for index in schedule
    ]
    pivots, order, factors, dependent = {}, [], [], []
    passes = 0
    while pending:
        passes += 1
        next_pending = []
        new_pivots = 0
        for row_index, key, row, rhs, combination in pending:
            row, rhs, combination = reduce_record(
                row, rhs, combination, pivots, order
            )
            replay_combination(source, row, rhs, combination)
            if not row:
                dependent.append((row_index, key, rhs, combination))
                continue
            candidates = [
                variable for variable, coefficient in row.items()
                if coefficient and coefficient.degree == 0
            ]
            if not candidates:
                next_pending.append((row_index, key, row, rhs, combination))
                continue
            pivot = max(candidates)
            lead = row[pivot]
            inverse = lead.inverse()
            normalized_row = {
                variable: coefficient * inverse
                for variable, coefficient in row.items()
            }
            normalized_rhs = rhs * inverse
            normalized_combination = {
                index: coefficient * inverse
                for index, coefficient in combination.items()
            }
            pivots[pivot] = (
                normalized_row, normalized_rhs, normalized_combination
            )
            order.append(pivot)
            factors.append((row_index, key, pivot, lead))
            new_pivots += 1
        pending = next_pending
        if pending and not new_pivots:
            for row_index, key, row, rhs, _ in pending:
                print(f"{stage}_unresolved_nonunit_row={row_index}")
                print(f"{stage}_unresolved_nonunit_key={key}")
                print(f"{stage}_unresolved_nonunit_rhs_degree={rhs.degree}")
                print(
                    f"{stage}_unresolved_nonunit_coefficient_degrees="
                    f"{sorted((variable, value.degree) for variable, value in row.items())}",
                    flush=True,
                )
            raise AssertionError("reverse unit-pivot cover incomplete")

    if target is not None:
        key, row, rhs = source[target]
        row, rhs, combination = reduce_record(
            row, rhs, {target: BetaPoly(1)}, pivots, order
        )
        replay_combination(source, row, rhs, combination)
        assert not row, (stage, key, row)
        dependent.append((target, key, rhs, combination))

    for pivot, (row, rhs, combination) in pivots.items():
        replay_combination(source, row, rhs, combination)
        assert row[pivot] == BetaPoly(1)
    PIVOT_ORDERS[id(pivots)] = tuple(order)
    print(f"{stage}_rank={len(pivots)}/{nvariables}")
    print(f"{stage}_dependent_count={len(dependent)}")
    print(f"{stage}_all_pivots_beta_independent=true")
    print(f"{stage}_pivot_digest={n.digest(tuple(factors))}")
    print(f"{stage}_original_row_replay=true")
    print(f"{stage}_row_order=reverse_deferred")
    print(f"{stage}_variable_priority=descending_unit")
    print(f"{stage}_unit_pivot_passes={passes}")
    if target is not None:
        print(f"{stage}_target_X0_t13_forced_dependent=true")
    return pivots, order, factors, dependent


def independent_parameterize(nvariables, rows, stage):
    pivots, order, factors, dependent = reverse_unit_solve_stage(
        nvariables, rows, stage
    )
    assert all(not rhs for _, _, rhs, _ in dependent), (stage, dependent)
    free = [variable for variable in range(nvariables) if variable not in pivots]
    parameter_of = {variable: index for index, variable in enumerate(free)}
    forms = [None] * nvariables
    for variable in free:
        forms[variable] = (
            BetaPoly(), {parameter_of[variable]: BetaPoly(1)}
        )
    for variable in reversed(order):
        row, rhs, _ = pivots[variable]
        form = (rhs, {})
        for other, coefficient in row.items():
            if other == variable:
                continue
            assert forms[other] is not None, (stage, variable, other, order)
            form = nr.add_affine(form, forms[other], -coefficient)
        forms[variable] = form
    assert all(form is not None for form in forms)
    for key, row, rhs in rows:
        got = (BetaPoly(), {})
        for variable, coefficient in row.items():
            got = nr.add_affine(got, forms[variable], coefficient)
        assert got == (BetaPoly.coerce(rhs), {}), (stage, key, got, rhs)
    print(f"{stage}_affine_parameterization_replay=true", flush=True)
    return pivots, forms, free, factors, dependent


def independent_divide(polynomial, pivots):
    """Reduce in pivot-insertion order and replay every quotient exactly."""
    order = PIVOT_ORDERS[id(pivots)]
    remainder, quotients = dict(polynomial), {}
    normalized = {
        pivot: n.source_polynomial(row, rhs)
        for pivot, (row, rhs, _) in pivots.items()
    }
    for pivot in order:
        quotient = {}
        while True:
            targets = sorted(
                monomial for monomial, coefficient in remainder.items()
                if coefficient and pivot in monomial
            )
            if not targets:
                break
            monomial = targets[0]
            coefficient = remainder[monomial]
            reduced = list(monomial)
            reduced.remove(pivot)
            multiplier = {tuple(reduced): coefficient}
            quotient = g.add(quotient, multiplier)
            remainder = g.add(
                remainder, g.multiply(multiplier, normalized[pivot]), -1
            )
        if quotient:
            quotients[pivot] = quotient
    replay = dict(remainder)
    for pivot, quotient in quotients.items():
        replay = g.add(replay, g.multiply(quotient, normalized[pivot]))
    assert g.clean(replay) == g.clean(polynomial)
    return g.clean(remainder), quotients


def main():
    n.solve_stage = reverse_unit_solve_stage
    v.parameterize_with_pivots = independent_parameterize
    g.divide_polynomial = independent_divide
    print("producer=TD6-A3-Q2-FULL-SOURCE-GLUE-V52-REVERSE-UNIT")
    print("independent_post_transport_row_order=reverse_deferred")
    print("independent_post_transport_variable_priority=descending_unit")
    print("beta_pivot_localization_used=false")
    print(f"V50_source_sha256={V50_SHA256}", flush=True)
    v.main()
    print("TD6-A3-Q2-FULL-SOURCE-GLUE-V52-REVERSE-UNIT PASS")


if __name__ == "__main__":
    main()
