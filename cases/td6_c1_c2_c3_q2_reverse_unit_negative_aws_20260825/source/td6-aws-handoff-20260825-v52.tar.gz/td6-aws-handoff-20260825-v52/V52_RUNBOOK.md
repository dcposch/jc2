# V52 independent reverse/deferred unit-pivot source replay

V52 is an independent-order successor to V50.  It consumes the exact same
arbitrary-degree original rows but reverses the row schedule and chooses the
largest available beta-independent pivot, deferring beta-leading rows rather
than localizing at beta.  Its affine solver uses reverse pivot-insertion order
and its nonlinear divider uses pivot-insertion order; both replay every source
combination exactly.

Run only on AWS after verifying `SOURCE.sha256` and `V52_SOURCE.sha256`:

```sh
mkdir -p v52-artifacts
TD6_OUTPUT_DIR="$PWD/v52-artifacts" ./run_v52.sh \
  > v52.stdout 2> v52.stderr
```

Expected terminal marker:
`TD6-A3-Q2-FULL-SOURCE-GLUE-V52-REVERSE-UNIT PASS`.

Any unresolved row having only beta-dependent coefficients is a fail-closed
nonunit-pivot diagnostic.  It must not be inverted and must not be read as an
open-cover certificate.  If V50 and V52 leave distinct denominators, their
multivariate gcd is insufficient: coverage requires an explicit checked
`a*d1+b*d2=(U*H*B3)^N` or an equivalent finite principal-open cover.
